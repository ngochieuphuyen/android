package javax.annotation.meta;

public enum When {
    ALWAYS,
    UNKNOWN,
    MAYBE,
    NEVER
}
