package com.p006a.p007a.p009b;

import java.math.BigDecimal;

/* renamed from: com.a.a.b.a */
public final class Location {
    private BigDecimal f255a;
    private BigDecimal f256b;

    public Location(double d, double d2) {
        this.f255a = new BigDecimal(d);
        this.f256b = new BigDecimal(d2);
    }

    public final BigDecimal m803a() {
        return this.f255a;
    }

    public final BigDecimal m804b() {
        return this.f256b;
    }
}
