package com.p006a.p007a;

import com.p006a.p007a.p008a.SolarEventCalculator;
import com.p006a.p007a.p009b.Location;
import java.util.Calendar;

/* renamed from: com.a.a.a */
public final class SunriseSunsetCalculator {
    private SolarEventCalculator f254a;

    public SunriseSunsetCalculator(Location location, String str) {
        this.f254a = new SolarEventCalculator(location, str);
    }

    public final String m799a(Calendar calendar) {
        return this.f254a.m795a(Zenith.f257a, calendar);
    }

    public final Calendar m800b(Calendar calendar) {
        return this.f254a.m796b(Zenith.f257a, calendar);
    }

    public final String m801c(Calendar calendar) {
        return this.f254a.m797c(Zenith.f257a, calendar);
    }

    public final Calendar m802d(Calendar calendar) {
        return this.f254a.m798d(Zenith.f257a, calendar);
    }
}
