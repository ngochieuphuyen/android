package com.p006a.p007a.p008a;

import com.p006a.p007a.Zenith;
import com.p006a.p007a.p009b.Location;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.TimeZone;

/* renamed from: com.a.a.a.a */
public final class SolarEventCalculator {
    private final Location f252a;
    private final TimeZone f253b;

    public SolarEventCalculator(Location location, String str) {
        this.f252a = location;
        this.f253b = TimeZone.getTimeZone(str);
    }

    public final String m795a(Zenith zenith, Calendar calendar) {
        return SolarEventCalculator.m786a(m788a(zenith, calendar, true));
    }

    public final Calendar m796b(Zenith zenith, Calendar calendar) {
        return SolarEventCalculator.m790a(m788a(zenith, calendar, true), calendar);
    }

    public final String m797c(Zenith zenith, Calendar calendar) {
        return SolarEventCalculator.m786a(m788a(zenith, calendar, false));
    }

    public final Calendar m798d(Zenith zenith, Calendar calendar) {
        return SolarEventCalculator.m790a(m788a(zenith, calendar, false), calendar);
    }

    private BigDecimal m788a(Zenith zenith, Calendar calendar, boolean z) {
        calendar.setTimeZone(this.f253b);
        int i = 18;
        if (Boolean.valueOf(z).booleanValue()) {
            i = 6;
        }
        BigDecimal d = SolarEventCalculator.m794d(new BigDecimal(calendar.get(6)).add(SolarEventCalculator.m792b(BigDecimal.valueOf((long) i).subtract(m787a()), BigDecimal.valueOf(24))));
        BigDecimal d2 = SolarEventCalculator.m794d(m789a(new BigDecimal("0.9856"), d).subtract(new BigDecimal("3.289")));
        d2 = d2.add(m789a(new BigDecimal(Math.sin(m793c(d2).doubleValue())), new BigDecimal("1.916"))).add(m789a(new BigDecimal(Math.sin(m789a(m793c(d2), BigDecimal.valueOf(2)).doubleValue())), new BigDecimal("0.020")).add(new BigDecimal("282.634")));
        if (d2.doubleValue() > 360.0d) {
            d2 = d2.subtract(BigDecimal.valueOf(360));
        }
        BigDecimal d3 = SolarEventCalculator.m794d(d2);
        d2 = SolarEventCalculator.m794d(BigDecimal.valueOf(Math.sin(m793c(d3).doubleValue())).multiply(new BigDecimal("0.39782")));
        BigDecimal d4 = SolarEventCalculator.m794d(BigDecimal.valueOf(Math.cos(BigDecimal.valueOf(Math.asin(d2.doubleValue())).doubleValue())));
        d2 = SolarEventCalculator.m794d(SolarEventCalculator.m792b(BigDecimal.valueOf(Math.cos(m793c(zenith.m805a()).doubleValue())).subtract(d2.multiply(BigDecimal.valueOf(Math.sin(m793c(this.f252a.m803a()).doubleValue())))), d4.multiply(BigDecimal.valueOf(Math.cos(m793c(this.f252a.m803a()).doubleValue())))));
        if (d2.doubleValue() < -1.0d || d2.doubleValue() > 1.0d) {
            return null;
        }
        Boolean valueOf = Boolean.valueOf(z);
        d2 = m791b(SolarEventCalculator.m794d(BigDecimal.valueOf(Math.acos(d2.doubleValue()))));
        if (valueOf.booleanValue()) {
            d2 = BigDecimal.valueOf(360).subtract(d2);
        }
        d4 = SolarEventCalculator.m792b(d2, BigDecimal.valueOf(15));
        d2 = SolarEventCalculator.m794d(m791b(new BigDecimal(Math.atan(m793c(m789a(m791b(new BigDecimal(Math.tan(m793c(d3).doubleValue()))), new BigDecimal("0.91764"))).doubleValue()))));
        if (d2.doubleValue() < 0.0d) {
            d2 = d2.add(BigDecimal.valueOf(360));
        } else if (d2.doubleValue() > 360.0d) {
            d2 = d2.subtract(BigDecimal.valueOf(360));
        }
        BigDecimal valueOf2 = BigDecimal.valueOf(90);
        d2 = SolarEventCalculator.m792b(d2.add(d3.divide(valueOf2, 0, RoundingMode.FLOOR).multiply(valueOf2).subtract(d2.divide(valueOf2, 0, RoundingMode.FLOOR).multiply(valueOf2))), BigDecimal.valueOf(15));
        d2 = d4.add(d2).subtract(d.multiply(new BigDecimal("0.06571"))).subtract(new BigDecimal("6.622"));
        if (d2.doubleValue() < 0.0d) {
            d2 = d2.add(BigDecimal.valueOf(24));
        } else if (d2.doubleValue() > 24.0d) {
            d2 = d2.subtract(BigDecimal.valueOf(24));
        }
        d2 = SolarEventCalculator.m794d(d2).subtract(m787a()).add(new BigDecimal(calendar.get(15) / 3600000).setScale(0, RoundingMode.HALF_EVEN));
        if (this.f253b.inDaylightTime(calendar.getTime())) {
            d2 = d2.add(BigDecimal.ONE);
        }
        if (d2.doubleValue() > 24.0d) {
            return d2.subtract(BigDecimal.valueOf(24));
        }
        return d2;
    }

    private BigDecimal m787a() {
        return SolarEventCalculator.m792b(this.f252a.m804b(), BigDecimal.valueOf(15));
    }

    private static String m786a(BigDecimal bigDecimal) {
        int i = 0;
        if (bigDecimal == null) {
            return "99:99";
        }
        if (bigDecimal.compareTo(BigDecimal.ZERO) == -1) {
            bigDecimal = bigDecimal.add(BigDecimal.valueOf(24.0d));
        }
        String[] split = bigDecimal.toPlainString().split("\\.");
        int parseInt = Integer.parseInt(split[0]);
        BigDecimal scale = new BigDecimal("0." + split[1]).multiply(BigDecimal.valueOf(60)).setScale(0, RoundingMode.HALF_EVEN);
        if (scale.intValue() == 60) {
            scale = BigDecimal.ZERO;
            parseInt++;
        }
        if (parseInt != 24) {
            i = parseInt;
        }
        return new StringBuilder(String.valueOf(i < 10 ? "0" + String.valueOf(i) : String.valueOf(i))).append(":").append(scale.intValue() < 10 ? "0" + scale.toPlainString() : scale.toPlainString()).toString();
    }

    private static Calendar m790a(BigDecimal bigDecimal, Calendar calendar) {
        if (bigDecimal == null) {
            return null;
        }
        Calendar calendar2 = (Calendar) calendar.clone();
        if (bigDecimal.compareTo(BigDecimal.ZERO) == -1) {
            bigDecimal = bigDecimal.add(BigDecimal.valueOf(24.0d));
            calendar2.add(11, -24);
        }
        String[] split = bigDecimal.toPlainString().split("\\.");
        int parseInt = Integer.parseInt(split[0]);
        BigDecimal scale = new BigDecimal("0." + split[1]).multiply(BigDecimal.valueOf(60)).setScale(0, RoundingMode.HALF_EVEN);
        if (scale.intValue() == 60) {
            scale = BigDecimal.ZERO;
            parseInt++;
        }
        if (parseInt == 24) {
            parseInt = 0;
        }
        calendar2.set(11, parseInt);
        calendar2.set(12, scale.intValue());
        calendar2.set(13, 0);
        calendar2.set(14, 0);
        calendar2.setTimeZone(calendar.getTimeZone());
        return calendar2;
    }

    private BigDecimal m791b(BigDecimal bigDecimal) {
        return m789a(bigDecimal, new BigDecimal(57.29577951308232d));
    }

    private BigDecimal m793c(BigDecimal bigDecimal) {
        return m789a(bigDecimal, BigDecimal.valueOf(0.017453292519943295d));
    }

    private BigDecimal m789a(BigDecimal bigDecimal, BigDecimal bigDecimal2) {
        return SolarEventCalculator.m794d(bigDecimal.multiply(bigDecimal2));
    }

    private static BigDecimal m792b(BigDecimal bigDecimal, BigDecimal bigDecimal2) {
        return bigDecimal.divide(bigDecimal2, 4, RoundingMode.HALF_EVEN);
    }

    private static BigDecimal m794d(BigDecimal bigDecimal) {
        return bigDecimal.setScale(4, RoundingMode.HALF_EVEN);
    }
}
