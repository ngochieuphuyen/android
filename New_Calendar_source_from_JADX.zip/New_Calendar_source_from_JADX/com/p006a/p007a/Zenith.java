package com.p006a.p007a;

import java.math.BigDecimal;

/* renamed from: com.a.a.b */
public final class Zenith {
    public static final Zenith f257a;
    private final BigDecimal f258b;

    static {
        Zenith zenith = new Zenith(108.0d);
        zenith = new Zenith(102.0d);
        zenith = new Zenith(96.0d);
        f257a = new Zenith(90.8333d);
    }

    private Zenith(double d) {
        this.f258b = BigDecimal.valueOf(d);
    }

    public final BigDecimal m805a() {
        return this.f258b;
    }
}
