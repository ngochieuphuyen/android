package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class UserMetadata implements SafeParcelable {
    public static final Creator<UserMetadata> CREATOR;
    final int f666a;
    final String f667b;
    final String f668c;
    final String f669d;
    final boolean f670e;
    final String f671f;

    static {
        CREATOR = new C0247n();
    }

    UserMetadata(int i, String str, String str2, String str3, boolean z, String str4) {
        this.f666a = i;
        this.f667b = str;
        this.f668c = str2;
        this.f669d = str3;
        this.f670e = z;
        this.f671f = str4;
    }

    public UserMetadata(String str, String str2, String str3, boolean z, String str4) {
        this(1, str, str2, str3, z, str4);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format("Permission ID: '%s', Display Name: '%s', Picture URL: '%s', Authenticated User: %b, Email: '%s'", new Object[]{this.f667b, this.f668c, this.f669d, Boolean.valueOf(this.f670e), this.f671f});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0247n.m1361a(this, parcel);
    }
}
