package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.m */
public final class C0228m implements Creator<StorageStats> {
    static void m1305a(StorageStats storageStats, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, storageStats.f660a);
        Security.m61a(parcel, 2, storageStats.f661b);
        Security.m61a(parcel, 3, storageStats.f662c);
        Security.m61a(parcel, 4, storageStats.f663d);
        Security.m61a(parcel, 5, storageStats.f664e);
        Security.m118c(parcel, 6, storageStats.f665f);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        long j = 0;
        int G = Security.m12G(parcel);
        long j2 = 0;
        long j3 = 0;
        long j4 = 0;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    j4 = Security.m139i(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    j3 = Security.m139i(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    j2 = Security.m139i(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    j = Security.m139i(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new StorageStats(i2, j4, j3, j2, j, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new StorageStats[i];
    }
}
