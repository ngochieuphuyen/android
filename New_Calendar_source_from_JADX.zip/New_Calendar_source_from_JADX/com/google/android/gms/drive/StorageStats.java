package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class StorageStats implements SafeParcelable {
    public static final Creator<StorageStats> CREATOR;
    final int f660a;
    final long f661b;
    final long f662c;
    final long f663d;
    final long f664e;
    final int f665f;

    static {
        CREATOR = new C0228m();
    }

    StorageStats(int i, long j, long j2, long j3, long j4, int i2) {
        this.f660a = i;
        this.f661b = j;
        this.f662c = j2;
        this.f663d = j3;
        this.f664e = j4;
        this.f665f = i2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0228m.m1305a(this, parcel);
    }
}
