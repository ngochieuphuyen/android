package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class DrivePreferences implements SafeParcelable {
    public static final Creator<DrivePreferences> CREATOR;
    final int f655a;
    final boolean f656b;

    static {
        CREATOR = new C0226k();
    }

    DrivePreferences(int i, boolean z) {
        this.f655a = i;
        this.f656b = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0226k.m1303a(this, parcel);
    }
}
