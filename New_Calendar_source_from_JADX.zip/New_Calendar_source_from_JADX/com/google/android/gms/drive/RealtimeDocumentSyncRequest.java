package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class RealtimeDocumentSyncRequest implements SafeParcelable {
    public static final Creator<RealtimeDocumentSyncRequest> CREATOR;
    final int f657a;
    final List<String> f658b;
    final List<String> f659c;

    static {
        CREATOR = new C0227l();
    }

    RealtimeDocumentSyncRequest(int i, List<String> list, List<String> list2) {
        this.f657a = i;
        this.f658b = (List) LunarUtil.m182a((Object) list);
        this.f659c = (List) LunarUtil.m182a((Object) list2);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0227l.m1304a(this, parcel);
    }
}
