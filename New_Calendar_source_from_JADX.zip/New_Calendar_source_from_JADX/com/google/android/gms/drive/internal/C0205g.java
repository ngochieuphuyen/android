package com.google.android.gms.drive.internal;

import android.support.v4.app.NotificationCompat;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.internal.kN;
import com.google.android.gms.internal.kO;
import com.google.android.gms.internal.kQ;
import com.google.android.gms.internal.kV;
import com.google.android.gms.wallet.LineItem.Role;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

/* renamed from: com.google.android.gms.drive.internal.g */
public final class C0205g extends kQ<C0205g> {
    public int f810a;
    public String f811b;
    public long f812c;
    public long f813d;

    public C0205g() {
        this.f810a = 1;
        this.f811b = "";
        this.f812c = -1;
        this.f813d = -1;
        this.i = null;
        this.j = -1;
    }

    protected final int m1280a() {
        return (((super.m1275a() + kO.m3676b(1, this.f810a)) + kO.m3678b(2, this.f811b)) + kO.m3683d(3, this.f812c)) + kO.m3683d(4, this.f813d);
    }

    public final /* synthetic */ kV m1281a(kN kNVar) {
        while (true) {
            int a = kNVar.m3654a();
            switch (a) {
                case Role.REGULAR /*0*/:
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    this.f810a = kNVar.m3658b();
                    continue;
                case C0015R.styleable.ActionBar_itemPadding /*18*/:
                    this.f811b = kNVar.m3662d();
                    continue;
                case 24:
                    this.f812c = kNVar.m3664e();
                    continue;
                case NotificationCompat.FLAG_NO_CLEAR /*32*/:
                    this.f813d = kNVar.m3664e();
                    continue;
                default:
                    if (!m1277a(kNVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void m1282a(kO kOVar) {
        kOVar.m3686a(1, this.f810a);
        kOVar.m3689a(2, this.f811b);
        kOVar.m3694b(3, this.f812c);
        kOVar.m3694b(4, this.f813d);
        super.m1276a(kOVar);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0205g)) {
            return false;
        }
        C0205g c0205g = (C0205g) obj;
        if (this.f810a != c0205g.f810a) {
            return false;
        }
        if (this.f811b == null) {
            if (c0205g.f811b != null) {
                return false;
            }
        } else if (!this.f811b.equals(c0205g.f811b)) {
            return false;
        }
        return (this.f812c == c0205g.f812c && this.f813d == c0205g.f813d) ? m1278a((kQ) c0205g) : false;
    }

    public final int hashCode() {
        return (((((((this.f811b == null ? 0 : this.f811b.hashCode()) + ((this.f810a + 527) * 31)) * 31) + ((int) (this.f812c ^ (this.f812c >>> 32)))) * 31) + ((int) (this.f813d ^ (this.f813d >>> 32)))) * 31) + m1279c();
    }
}
