package com.google.android.gms.drive.internal;

import com.google.android.gms.drive.C0173c;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

/* renamed from: com.google.android.gms.drive.internal.M */
public final class C0195M extends C0173c {
    private final MetadataBundle f750a;

    public C0195M(MetadataBundle metadataBundle) {
        this.f750a = metadataBundle;
    }

    public final /* synthetic */ Object freeze() {
        return new C0195M(MetadataBundle.m1322a(this.f750a));
    }

    public final boolean isDataValid() {
        return this.f750a != null;
    }

    public final String toString() {
        return "Metadata [mImpl=" + this.f750a + "]";
    }
}
