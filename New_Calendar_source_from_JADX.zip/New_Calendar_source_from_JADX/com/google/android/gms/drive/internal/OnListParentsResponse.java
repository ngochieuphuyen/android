package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.C0182i;

public class OnListParentsResponse extends C0182i implements SafeParcelable {
    public static final Creator<OnListParentsResponse> CREATOR;
    final int f770a;
    final DataHolder f771b;

    static {
        CREATOR = new C0213o();
    }

    OnListParentsResponse(int i, DataHolder dataHolder) {
        this.f770a = i;
        this.f771b = dataHolder;
    }

    protected final void m1208a(Parcel parcel, int i) {
        C0213o.m1290a(this, parcel, i);
    }

    public int describeContents() {
        return 0;
    }
}
