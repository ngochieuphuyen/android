package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.CompletionEvent;

public class OnEventResponse implements SafeParcelable {
    public static final Creator<OnEventResponse> CREATOR;
    final int f763a;
    final int f764b;
    final ChangeEvent f765c;
    final CompletionEvent f766d;

    static {
        CREATOR = new C0211m();
    }

    OnEventResponse(int i, int i2, ChangeEvent changeEvent, CompletionEvent completionEvent) {
        this.f763a = i;
        this.f764b = i2;
        this.f765c = changeEvent;
        this.f766d = completionEvent;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0211m.m1288a(this, parcel, i);
    }
}
