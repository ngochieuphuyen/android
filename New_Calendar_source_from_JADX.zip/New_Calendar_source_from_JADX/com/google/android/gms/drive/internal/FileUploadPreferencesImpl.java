package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.FileUploadPreferences;
import com.google.code.yadview.EventResource;

public final class FileUploadPreferencesImpl implements SafeParcelable, FileUploadPreferences {
    public static final Creator<FileUploadPreferencesImpl> CREATOR;
    final int f736a;
    int f737b;
    int f738c;
    boolean f739d;

    static {
        CREATOR = new C0200b();
    }

    FileUploadPreferencesImpl(int i, int i2, int i3, boolean z) {
        this.f736a = i;
        this.f737b = i2;
        this.f738c = i3;
        this.f739d = z;
    }

    private static boolean m1197a(int i) {
        switch (i) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                return true;
            default:
                return false;
        }
    }

    private static boolean m1198b(int i) {
        switch (i) {
            case FileUploadPreferences.BATTERY_USAGE_UNRESTRICTED /*256*/:
            case FileUploadPreferences.BATTERY_USAGE_CHARGING_ONLY /*257*/:
                return true;
            default:
                return false;
        }
    }

    public final int describeContents() {
        return 0;
    }

    public final int getBatteryUsagePreference() {
        return !m1198b(this.f738c) ? 0 : this.f738c;
    }

    public final int getNetworkTypePreference() {
        return !m1197a(this.f737b) ? 0 : this.f737b;
    }

    public final boolean isRoamingAllowed() {
        return this.f739d;
    }

    public final void setBatteryUsagePreference(int i) {
        if (m1198b(i)) {
            this.f738c = i;
            return;
        }
        throw new IllegalArgumentException("Invalid battery usage preference value.");
    }

    public final void setNetworkTypePreference(int i) {
        if (m1197a(i)) {
            this.f737b = i;
            return;
        }
        throw new IllegalArgumentException("Invalid data connection preference value.");
    }

    public final void setRoamingAllowed(boolean z) {
        this.f739d = z;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0200b.m1263a(this, parcel);
    }
}
