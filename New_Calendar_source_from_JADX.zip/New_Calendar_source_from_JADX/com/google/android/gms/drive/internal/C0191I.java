package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.games.request.GameRequest;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.drive.internal.I */
public final class C0191I implements Creator<CreateContentsRequest> {
    static void m1201a(CreateContentsRequest createContentsRequest, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, createContentsRequest.f713a);
        Security.m118c(parcel, 2, createContentsRequest.f714b);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        int i = 0;
        int i2 = DriveFile.MODE_WRITE_ONLY;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CreateContentsRequest(i, i2);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CreateContentsRequest[i];
    }
}
