package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class LoadRealtimeRequest implements SafeParcelable {
    public static final Creator<LoadRealtimeRequest> CREATOR;
    final int f747a;
    final DriveId f748b;
    final boolean f749c;

    static {
        CREATOR = new C0204f();
    }

    LoadRealtimeRequest(int i, DriveId driveId, boolean z) {
        this.f747a = i;
        this.f748b = driveId;
        this.f749c = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0204f.m1267a(this, parcel, i);
    }
}
