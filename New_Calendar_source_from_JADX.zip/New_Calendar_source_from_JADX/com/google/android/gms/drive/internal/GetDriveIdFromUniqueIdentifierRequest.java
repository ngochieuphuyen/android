package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class GetDriveIdFromUniqueIdentifierRequest implements SafeParcelable {
    public static final Creator<GetDriveIdFromUniqueIdentifierRequest> CREATOR;
    final int f740a;
    final String f741b;
    final boolean f742c;

    static {
        CREATOR = new C0201c();
    }

    GetDriveIdFromUniqueIdentifierRequest(int i, String str, boolean z) {
        this.f740a = i;
        this.f741b = str;
        this.f742c = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0201c.m1264a(this, parcel);
    }
}
