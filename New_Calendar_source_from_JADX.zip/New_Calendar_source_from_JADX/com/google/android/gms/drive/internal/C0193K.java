package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.internal.K */
public final class C0193K implements Creator<CreateFileRequest> {
    static void m1203a(CreateFileRequest createFileRequest, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, createFileRequest.f721a);
        Security.m65a(parcel, 2, createFileRequest.f722b, i, false);
        Security.m65a(parcel, 3, createFileRequest.f723c, i, false);
        Security.m65a(parcel, 4, createFileRequest.f724d, i, false);
        Security.m67a(parcel, 5, createFileRequest.f725e, false);
        Security.m73a(parcel, 6, createFileRequest.f726f);
        Security.m69a(parcel, 7, createFileRequest.f727g, false);
        Security.m118c(parcel, 8, createFileRequest.f728h);
        Security.m118c(parcel, 9, createFileRequest.f729i);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        String str = null;
        int G = Security.m12G(parcel);
        int i2 = 0;
        boolean z = false;
        Integer num = null;
        Contents contents = null;
        MetadataBundle metadataBundle = null;
        DriveId driveId = null;
        int i3 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    driveId = (DriveId) Security.m47a(parcel, readInt, DriveId.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    metadataBundle = (MetadataBundle) Security.m47a(parcel, readInt, MetadataBundle.CREATOR);
                    break;
                case Error.BAD_CARD /*4*/:
                    contents = (Contents) Security.m47a(parcel, readInt, Contents.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    num = Security.m138h(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CreateFileRequest(i3, driveId, metadataBundle, contents, num, z, str, i2, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CreateFileRequest[i];
    }
}
