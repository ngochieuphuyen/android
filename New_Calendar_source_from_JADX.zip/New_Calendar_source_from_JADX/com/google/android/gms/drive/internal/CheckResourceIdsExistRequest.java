package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class CheckResourceIdsExistRequest implements SafeParcelable {
    public static final Creator<CheckResourceIdsExistRequest> CREATOR;
    private final int f701a;
    private final List<String> f702b;

    static {
        CREATOR = new C0188F();
    }

    CheckResourceIdsExistRequest(int i, List<String> list) {
        this.f701a = i;
        this.f702b = list;
    }

    public final int m1192a() {
        return this.f701a;
    }

    public final List<String> m1193b() {
        return this.f702b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0188F.m1196a(this, parcel);
    }
}
