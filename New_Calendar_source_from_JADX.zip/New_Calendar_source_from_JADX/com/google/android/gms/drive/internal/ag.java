package com.google.android.gms.drive.internal;

import android.os.IInterface;

public interface ag extends IInterface {
    void m1261c(OnEventResponse onEventResponse);
}
