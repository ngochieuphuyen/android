package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class OnResourceIdSetResponse implements SafeParcelable {
    public static final Creator<OnResourceIdSetResponse> CREATOR;
    private final int f776a;
    private final List<String> f777b;

    static {
        CREATOR = new C0216r();
    }

    OnResourceIdSetResponse(int i, List<String> list) {
        this.f776a = i;
        this.f777b = list;
    }

    public final int m1209a() {
        return this.f776a;
    }

    public final List<String> m1210b() {
        return this.f777b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0216r.m1293a(this, parcel);
    }
}
