package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;

public class OnContentsResponse implements SafeParcelable {
    public static final Creator<OnContentsResponse> CREATOR;
    final int f751a;
    final Contents f752b;
    final boolean f753c;

    static {
        CREATOR = new C0206h();
    }

    OnContentsResponse(int i, Contents contents, boolean z) {
        this.f751a = i;
        this.f752b = contents;
        this.f753c = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0206h.m1283a(this, parcel, i);
    }
}
