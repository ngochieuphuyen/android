package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class AddEventListenerRequest implements SafeParcelable {
    public static final Creator<AddEventListenerRequest> CREATOR;
    final int f693a;
    final DriveId f694b;
    final int f695c;

    static {
        CREATOR = new C0199a();
    }

    AddEventListenerRequest(int i, DriveId driveId, int i2) {
        this.f693a = i;
        this.f694b = driveId;
        this.f695c = i2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0199a.m1212a(this, parcel, i);
    }
}
