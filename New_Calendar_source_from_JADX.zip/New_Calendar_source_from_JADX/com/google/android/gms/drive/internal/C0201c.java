package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.drive.internal.c */
public final class C0201c implements Creator<GetDriveIdFromUniqueIdentifierRequest> {
    static void m1264a(GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, getDriveIdFromUniqueIdentifierRequest.f740a);
        Security.m69a(parcel, 2, getDriveIdFromUniqueIdentifierRequest.f741b, false);
        Security.m73a(parcel, 3, getDriveIdFromUniqueIdentifierRequest.f742c);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        int G = Security.m12G(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new GetDriveIdFromUniqueIdentifierRequest(i, str, z);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new GetDriveIdFromUniqueIdentifierRequest[i];
    }
}
