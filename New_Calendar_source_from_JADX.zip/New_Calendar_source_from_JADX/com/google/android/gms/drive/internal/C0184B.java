package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.drive.internal.B */
public final class C0184B implements Creator<SetResourceParentsRequest> {
    static void m1190a(SetResourceParentsRequest setResourceParentsRequest, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, setResourceParentsRequest.f800a);
        Security.m65a(parcel, 2, setResourceParentsRequest.f801b, i, false);
        Security.m119c(parcel, 3, setResourceParentsRequest.f802c, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        DriveId driveId = null;
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    driveId = (DriveId) Security.m47a(parcel, readInt, DriveId.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    list = Security.m117c(parcel, readInt, DriveId.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new SetResourceParentsRequest(i, driveId, list);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new SetResourceParentsRequest[i];
    }
}
