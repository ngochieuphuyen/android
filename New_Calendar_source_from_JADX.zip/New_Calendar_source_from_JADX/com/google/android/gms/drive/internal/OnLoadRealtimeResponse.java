package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnLoadRealtimeResponse implements SafeParcelable {
    public static final Creator<OnLoadRealtimeResponse> CREATOR;
    final int f772a;
    final boolean f773b;

    static {
        CREATOR = new C0215q();
    }

    OnLoadRealtimeResponse(int i, boolean z) {
        this.f772a = i;
        this.f773b = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0215q.m1292a(this, parcel);
    }
}
