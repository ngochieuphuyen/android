package com.google.android.gms.drive.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.realtime.internal.C0285m;

public interface af extends IInterface {
    void m1248a(OnContentsResponse onContentsResponse);

    void m1249a(OnDeviceUsagePreferenceResponse onDeviceUsagePreferenceResponse);

    void m1250a(OnDownloadProgressResponse onDownloadProgressResponse);

    void m1251a(OnDriveIdResponse onDriveIdResponse);

    void m1252a(OnDrivePreferencesResponse onDrivePreferencesResponse);

    void m1253a(OnListEntriesResponse onListEntriesResponse);

    void m1254a(OnListParentsResponse onListParentsResponse);

    void m1255a(OnLoadRealtimeResponse onLoadRealtimeResponse, C0285m c0285m);

    void m1256a(OnMetadataResponse onMetadataResponse);

    void m1257a(OnResourceIdSetResponse onResourceIdSetResponse);

    void m1258a(OnStorageStatsResponse onStorageStatsResponse);

    void m1259a(OnSyncMoreResponse onSyncMoreResponse);

    void m1260n(Status status);

    void onSuccess();
}
