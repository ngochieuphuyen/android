package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class CreateFileRequest implements SafeParcelable {
    public static final Creator<CreateFileRequest> CREATOR;
    final int f721a;
    final DriveId f722b;
    final MetadataBundle f723c;
    final Contents f724d;
    final Integer f725e;
    final boolean f726f;
    final String f727g;
    final int f728h;
    final int f729i;

    static {
        CREATOR = new C0193K();
    }

    CreateFileRequest(int i, DriveId driveId, MetadataBundle metadataBundle, Contents contents, Integer num, boolean z, String str, int i2, int i3) {
        if (!(contents == null || i3 == 0)) {
            LunarUtil.m192b(contents.m1182a() == i3, "inconsistent contents reference");
        }
        if ((num == null || num.intValue() == 0) && contents == null && i3 == 0) {
            throw new IllegalArgumentException("Need a valid contents");
        }
        this.f721a = i;
        this.f722b = (DriveId) LunarUtil.m182a((Object) driveId);
        this.f723c = (MetadataBundle) LunarUtil.m182a((Object) metadataBundle);
        this.f724d = contents;
        this.f725e = num;
        this.f727g = str;
        this.f728h = i2;
        this.f726f = z;
        this.f729i = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0193K.m1203a(this, parcel, i);
    }
}
