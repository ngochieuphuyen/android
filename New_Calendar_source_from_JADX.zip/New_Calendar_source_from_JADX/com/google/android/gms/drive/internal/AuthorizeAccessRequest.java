package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class AuthorizeAccessRequest implements SafeParcelable {
    public static final Creator<AuthorizeAccessRequest> CREATOR;
    final int f696a;
    final long f697b;
    final DriveId f698c;

    static {
        CREATOR = new C0220v();
    }

    AuthorizeAccessRequest(int i, long j, DriveId driveId) {
        this.f696a = i;
        this.f697b = j;
        this.f698c = driveId;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0220v.m1297a(this, parcel, i);
    }
}
