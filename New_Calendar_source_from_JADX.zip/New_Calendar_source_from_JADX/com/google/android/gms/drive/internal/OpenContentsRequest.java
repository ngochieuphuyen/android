package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class OpenContentsRequest implements SafeParcelable {
    public static final Creator<OpenContentsRequest> CREATOR;
    final int f782a;
    final DriveId f783b;
    final int f784c;
    final int f785d;

    static {
        CREATOR = new C0219u();
    }

    OpenContentsRequest(int i, DriveId driveId, int i2, int i3) {
        this.f782a = i;
        this.f783b = driveId;
        this.f784c = i2;
        this.f785d = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0219u.m1296a(this, parcel, i);
    }
}
