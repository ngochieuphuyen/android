package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class OpenFileIntentSenderRequest implements SafeParcelable {
    public static final Creator<OpenFileIntentSenderRequest> CREATOR;
    final int f786a;
    final String f787b;
    final String[] f788c;
    final DriveId f789d;

    static {
        CREATOR = new C0221w();
    }

    OpenFileIntentSenderRequest(int i, String str, String[] strArr, DriveId driveId) {
        this.f786a = i;
        this.f787b = str;
        this.f788c = strArr;
        this.f789d = driveId;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0221w.m1298a(this, parcel, i);
    }
}
