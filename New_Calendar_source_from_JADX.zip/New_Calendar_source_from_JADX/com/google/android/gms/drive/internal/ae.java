package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import android.os.IInterface;
import com.google.android.gms.drive.RealtimeDocumentSyncRequest;

public interface ae extends IInterface {
    IntentSender m1213a(CreateFileIntentSenderRequest createFileIntentSenderRequest);

    IntentSender m1214a(OpenFileIntentSenderRequest openFileIntentSenderRequest);

    void m1215a(RealtimeDocumentSyncRequest realtimeDocumentSyncRequest, af afVar);

    void m1216a(AddEventListenerRequest addEventListenerRequest, ag agVar, String str, af afVar);

    void m1217a(AuthorizeAccessRequest authorizeAccessRequest, af afVar);

    void m1218a(CancelPendingActionsRequest cancelPendingActionsRequest, af afVar);

    void m1219a(CheckResourceIdsExistRequest checkResourceIdsExistRequest, af afVar);

    void m1220a(CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest, af afVar);

    void m1221a(CloseContentsRequest closeContentsRequest, af afVar);

    void m1222a(CreateContentsRequest createContentsRequest, af afVar);

    void m1223a(CreateFileRequest createFileRequest, af afVar);

    void m1224a(CreateFolderRequest createFolderRequest, af afVar);

    void m1225a(DeleteResourceRequest deleteResourceRequest, af afVar);

    void m1226a(DisconnectRequest disconnectRequest);

    void m1227a(GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest, af afVar);

    void m1228a(GetMetadataRequest getMetadataRequest, af afVar);

    void m1229a(ListParentsRequest listParentsRequest, af afVar);

    void m1230a(LoadRealtimeRequest loadRealtimeRequest, af afVar);

    void m1231a(OpenContentsRequest openContentsRequest, af afVar);

    void m1232a(QueryRequest queryRequest, af afVar);

    void m1233a(RemoveEventListenerRequest removeEventListenerRequest, ag agVar, String str, af afVar);

    void m1234a(SetDrivePreferencesRequest setDrivePreferencesRequest, af afVar);

    void m1235a(SetFileUploadPreferencesRequest setFileUploadPreferencesRequest, af afVar);

    void m1236a(SetResourceParentsRequest setResourceParentsRequest, af afVar);

    void m1237a(TrashResourceRequest trashResourceRequest, af afVar);

    void m1238a(UpdateMetadataRequest updateMetadataRequest, af afVar);

    void m1239a(af afVar);

    void m1240b(QueryRequest queryRequest, af afVar);

    void m1241b(af afVar);

    void m1242c(af afVar);

    void m1243d(af afVar);

    void m1244e(af afVar);

    void m1245f(af afVar);

    void m1246g(af afVar);

    void m1247h(af afVar);
}
