package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class CreateFolderRequest implements SafeParcelable {
    public static final Creator<CreateFolderRequest> CREATOR;
    final int f730a;
    final DriveId f731b;
    final MetadataBundle f732c;

    static {
        CREATOR = new C0194L();
    }

    CreateFolderRequest(int i, DriveId driveId, MetadataBundle metadataBundle) {
        this.f730a = i;
        this.f731b = (DriveId) LunarUtil.m182a((Object) driveId);
        this.f732c = (MetadataBundle) LunarUtil.m182a((Object) metadataBundle);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0194L.m1204a(this, parcel, i);
    }
}
