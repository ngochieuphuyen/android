package com.google.android.gms.drive.internal;

import android.os.IInterface;

public interface ah extends IInterface {
    void m1262M(boolean z);
}
