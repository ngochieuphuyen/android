package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnDownloadProgressResponse implements SafeParcelable {
    public static final Creator<OnDownloadProgressResponse> CREATOR;
    final int f756a;
    final long f757b;
    final long f758c;

    static {
        CREATOR = new C0208j();
    }

    OnDownloadProgressResponse(int i, long j, long j2) {
        this.f756a = i;
        this.f757b = j;
        this.f758c = j2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0208j.m1285a(this, parcel);
    }
}
