package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.drive.internal.r */
public final class C0216r implements Creator<OnResourceIdSetResponse> {
    static void m1293a(OnResourceIdSetResponse onResourceIdSetResponse, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, onResourceIdSetResponse.m1209a());
        Security.m108b(parcel, 2, onResourceIdSetResponse.m1210b(), false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new OnResourceIdSetResponse(i, list);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new OnResourceIdSetResponse[i];
    }
}
