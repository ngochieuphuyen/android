package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class TrashResourceRequest implements SafeParcelable {
    public static final Creator<TrashResourceRequest> CREATOR;
    final int f803a;
    final DriveId f804b;

    static {
        CREATOR = new C0185C();
    }

    TrashResourceRequest(int i, DriveId driveId) {
        this.f803a = i;
        this.f804b = driveId;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0185C.m1191a(this, parcel, i);
    }
}
