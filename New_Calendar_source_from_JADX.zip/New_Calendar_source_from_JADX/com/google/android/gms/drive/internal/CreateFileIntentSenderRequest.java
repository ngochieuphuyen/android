package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class CreateFileIntentSenderRequest implements SafeParcelable {
    public static final Creator<CreateFileIntentSenderRequest> CREATOR;
    final int f715a;
    final MetadataBundle f716b;
    final int f717c;
    final String f718d;
    final DriveId f719e;
    final Integer f720f;

    static {
        CREATOR = new C0192J();
    }

    CreateFileIntentSenderRequest(int i, MetadataBundle metadataBundle, int i2, String str, DriveId driveId, Integer num) {
        this.f715a = i;
        this.f716b = metadataBundle;
        this.f717c = i2;
        this.f718d = str;
        this.f719e = driveId;
        this.f720f = num;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0192J.m1202a(this, parcel, i);
    }
}
