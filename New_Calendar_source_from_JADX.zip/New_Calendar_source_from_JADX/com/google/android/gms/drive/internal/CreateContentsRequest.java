package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveFile;

public class CreateContentsRequest implements SafeParcelable {
    public static final Creator<CreateContentsRequest> CREATOR;
    final int f713a;
    final int f714b;

    static {
        CREATOR = new C0191I();
    }

    CreateContentsRequest(int i, int i2) {
        this.f713a = i;
        boolean z = i2 == DriveFile.MODE_WRITE_ONLY || i2 == DriveFile.MODE_READ_WRITE;
        LunarUtil.m192b(z, "Cannot create a new read-only contents!");
        this.f714b = i2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0191I.m1201a(this, parcel);
    }
}
