package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class DeleteResourceRequest implements SafeParcelable {
    public static final Creator<DeleteResourceRequest> CREATOR;
    final int f733a;
    final DriveId f734b;

    static {
        CREATOR = new C0196N();
    }

    DeleteResourceRequest(int i, DriveId driveId) {
        this.f733a = i;
        this.f734b = driveId;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0196N.m1205a(this, parcel, i);
    }
}
