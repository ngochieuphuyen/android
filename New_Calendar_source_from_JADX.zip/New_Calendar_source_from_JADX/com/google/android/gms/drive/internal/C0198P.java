package com.google.android.gms.drive.internal;

import android.util.Log;
import com.google.android.gms.internal.gE;

/* renamed from: com.google.android.gms.drive.internal.P */
public final class C0198P {
    private static final gE f790a;

    static {
        f790a = new gE("GmsDrive");
    }

    public static void m1211a(String str, String str2) {
        if (f790a.m3160a(5)) {
            Log.w(str, str2);
        }
    }
}
