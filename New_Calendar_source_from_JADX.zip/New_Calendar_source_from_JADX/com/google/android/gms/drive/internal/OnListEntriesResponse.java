package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.C0182i;

public class OnListEntriesResponse extends C0182i implements SafeParcelable {
    public static final Creator<OnListEntriesResponse> CREATOR;
    final int f767a;
    final DataHolder f768b;
    final boolean f769c;

    static {
        CREATOR = new C0212n();
    }

    OnListEntriesResponse(int i, DataHolder dataHolder, boolean z) {
        this.f767a = i;
        this.f768b = dataHolder;
        this.f769c = z;
    }

    protected final void m1207a(Parcel parcel, int i) {
        C0212n.m1289a(this, parcel, i);
    }

    public int describeContents() {
        return 0;
    }
}
