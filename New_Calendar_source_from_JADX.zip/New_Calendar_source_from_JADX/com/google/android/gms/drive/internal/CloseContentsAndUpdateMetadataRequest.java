package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class CloseContentsAndUpdateMetadataRequest implements SafeParcelable {
    public static final Creator<CloseContentsAndUpdateMetadataRequest> CREATOR;
    final int f703a;
    final DriveId f704b;
    final MetadataBundle f705c;
    final Contents f706d;
    final boolean f707e;
    final String f708f;
    final int f709g;

    static {
        CREATOR = new C0189G();
    }

    CloseContentsAndUpdateMetadataRequest(int i, DriveId driveId, MetadataBundle metadataBundle, Contents contents, boolean z, String str, int i2) {
        this.f703a = i;
        this.f704b = driveId;
        this.f705c = metadataBundle;
        this.f706d = contents;
        this.f707e = z;
        this.f708f = str;
        this.f709g = i2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0189G.m1199a(this, parcel, i);
    }
}
