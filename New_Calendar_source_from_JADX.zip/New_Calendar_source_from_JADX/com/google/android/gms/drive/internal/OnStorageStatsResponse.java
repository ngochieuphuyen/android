package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.StorageStats;

public class OnStorageStatsResponse implements SafeParcelable {
    public static final Creator<OnStorageStatsResponse> CREATOR;
    final int f778a;
    StorageStats f779b;

    static {
        CREATOR = new C0217s();
    }

    OnStorageStatsResponse(int i, StorageStats storageStats) {
        this.f778a = i;
        this.f779b = storageStats;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0217s.m1294a(this, parcel, i);
    }
}
