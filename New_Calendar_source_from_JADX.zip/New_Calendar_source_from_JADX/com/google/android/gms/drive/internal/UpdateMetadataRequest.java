package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class UpdateMetadataRequest implements SafeParcelable {
    public static final Creator<UpdateMetadataRequest> CREATOR;
    final int f805a;
    final DriveId f806b;
    final MetadataBundle f807c;

    static {
        CREATOR = new C0186D();
    }

    UpdateMetadataRequest(int i, DriveId driveId, MetadataBundle metadataBundle) {
        this.f805a = i;
        this.f806b = driveId;
        this.f807c = metadataBundle;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0186D.m1194a(this, parcel, i);
    }
}
