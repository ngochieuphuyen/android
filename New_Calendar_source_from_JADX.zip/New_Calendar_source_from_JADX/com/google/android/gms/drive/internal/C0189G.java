package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.internal.G */
public final class C0189G implements Creator<CloseContentsAndUpdateMetadataRequest> {
    static void m1199a(CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, closeContentsAndUpdateMetadataRequest.f703a);
        Security.m65a(parcel, 2, closeContentsAndUpdateMetadataRequest.f704b, i, false);
        Security.m65a(parcel, 3, closeContentsAndUpdateMetadataRequest.f705c, i, false);
        Security.m65a(parcel, 4, closeContentsAndUpdateMetadataRequest.f706d, i, false);
        Security.m73a(parcel, 5, closeContentsAndUpdateMetadataRequest.f707e);
        Security.m69a(parcel, 6, closeContentsAndUpdateMetadataRequest.f708f, false);
        Security.m118c(parcel, 7, closeContentsAndUpdateMetadataRequest.f709g);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        String str = null;
        int G = Security.m12G(parcel);
        boolean z = false;
        Contents contents = null;
        MetadataBundle metadataBundle = null;
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    driveId = (DriveId) Security.m47a(parcel, readInt, DriveId.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    metadataBundle = (MetadataBundle) Security.m47a(parcel, readInt, MetadataBundle.CREATOR);
                    break;
                case Error.BAD_CARD /*4*/:
                    contents = (Contents) Security.m47a(parcel, readInt, Contents.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CloseContentsAndUpdateMetadataRequest(i2, driveId, metadataBundle, contents, z, str, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CloseContentsAndUpdateMetadataRequest[i];
    }
}
