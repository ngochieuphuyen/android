package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.p003c.LunarUtil;

/* renamed from: com.google.android.gms.drive.i */
public abstract class C0182i implements Parcelable {
    private volatile transient boolean f692a;

    public C0182i() {
        this.f692a = false;
    }

    protected abstract void m1188a(Parcel parcel, int i);

    public void writeToParcel(Parcel parcel, int i) {
        LunarUtil.m188a(!this.f692a);
        this.f692a = true;
        m1188a(parcel, i);
    }
}
