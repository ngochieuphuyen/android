package com.google.android.gms.drive;

import com.google.android.gms.internal.C0477e;
import java.util.Arrays;

/* renamed from: com.google.android.gms.drive.a */
public final class C0171a {
    private final String f672a;
    private final boolean f673b;
    private final int f674c;

    public final boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        C0171a c0171a = (C0171a) obj;
        return C0477e.m2759a(this.f672a, c0171a.f672a) && this.f674c == c0171a.f674c && this.f673b == c0171a.f673b;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f672a, Integer.valueOf(this.f674c), Boolean.valueOf(this.f673b)});
    }
}
