package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.internal.C0195M;
import com.google.android.gms.drive.metadata.C0230b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.C0238f;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.hA;

/* renamed from: com.google.android.gms.drive.f */
final class C0179f extends C0173c {
    private final DataHolder f689a;
    private final int f690b;
    private final int f691c;

    public C0179f(DataHolder dataHolder, int i) {
        this.f689a = dataHolder;
        this.f690b = i;
        this.f691c = dataHolder.m1121a(i);
    }

    public final /* synthetic */ Object freeze() {
        MetadataBundle a = MetadataBundle.m1321a();
        for (MetadataField metadataField : C0238f.m1337a()) {
            if (!((metadataField instanceof C0230b) || metadataField == hA.f2782z)) {
                metadataField.m1307a(this.f689a, a, this.f690b, this.f691c);
            }
        }
        return new C0195M(a);
    }

    public final boolean isDataValid() {
        return !this.f689a.m1138h();
    }
}
