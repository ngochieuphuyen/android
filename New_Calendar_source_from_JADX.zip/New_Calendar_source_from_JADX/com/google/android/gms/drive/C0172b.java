package com.google.android.gms.drive;

/* renamed from: com.google.android.gms.drive.b */
public interface C0172b {
}
