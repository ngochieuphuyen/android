package com.google.android.gms.drive;

import com.google.android.gms.drive.metadata.internal.MetadataBundle;

/* renamed from: com.google.android.gms.drive.g */
public final class C0180g {
    static {
        C0180g c0180g = new C0180g(MetadataBundle.m1321a());
    }

    private C0180g(MetadataBundle metadataBundle) {
        MetadataBundle.m1322a(metadataBundle);
    }
}
