package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;

/* renamed from: com.google.android.gms.drive.c */
public abstract class C0173c implements Freezable<C0173c> {
}
