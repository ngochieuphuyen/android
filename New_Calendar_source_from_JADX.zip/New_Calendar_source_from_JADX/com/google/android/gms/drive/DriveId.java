package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import android.util.Base64;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.C0198P;
import com.google.android.gms.drive.internal.C0205g;
import com.google.android.gms.internal.kV;

public class DriveId implements SafeParcelable {
    public static final Creator<DriveId> CREATOR;
    final int f650a;
    final String f651b;
    final long f652c;
    final long f653d;
    private volatile String f654e;

    static {
        CREATOR = new C0225j();
    }

    DriveId(int i, String str, long j, long j2) {
        boolean z = false;
        this.f654e = null;
        this.f650a = i;
        this.f651b = str;
        LunarUtil.m191b(!"".equals(str));
        if (!(str == null && j == -1)) {
            z = true;
        }
        LunarUtil.m191b(z);
        this.f652c = j;
        this.f653d = j2;
    }

    public DriveId(String str, long j, long j2) {
        this(1, str, j, j2);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof DriveId)) {
            return false;
        }
        DriveId driveId = (DriveId) obj;
        if (driveId.f653d == this.f653d) {
            return (driveId.f652c == -1 && this.f652c == -1) ? driveId.f651b.equals(this.f651b) : driveId.f652c == this.f652c;
        } else {
            C0198P.m1211a("DriveId", "Attempt to compare invalid DriveId detected. Has local storage been cleared?");
            return false;
        }
    }

    public int hashCode() {
        return this.f652c == -1 ? this.f651b.hashCode() : (String.valueOf(this.f653d) + String.valueOf(this.f652c)).hashCode();
    }

    public String toString() {
        if (this.f654e == null) {
            kV c0205g = new C0205g();
            c0205g.f810a = this.f650a;
            c0205g.f811b = this.f651b == null ? "" : this.f651b;
            c0205g.f812c = this.f652c;
            c0205g.f813d = this.f653d;
            byte[] bArr = new byte[c0205g.m1274e()];
            kV.m1268a(c0205g, bArr, 0, bArr.length);
            this.f654e = "DriveId:" + Base64.encodeToString(bArr, 10);
        }
        return this.f654e;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0225j.m1302a(this, parcel);
    }
}
