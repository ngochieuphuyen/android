package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;

public class FilterHolder implements SafeParcelable {
    public static final Creator<FilterHolder> CREATOR;
    final int f848a;
    final ComparisonFilter<?> f849b;
    final FieldOnlyFilter f850c;
    final LogicalFilter f851d;
    final NotFilter f852e;
    final InFilter<?> f853f;
    final MatchAllFilter f854g;
    final HasFilter f855h;
    private final Filter f856i;

    static {
        CREATOR = new C0255d();
    }

    FilterHolder(int i, ComparisonFilter<?> comparisonFilter, FieldOnlyFilter fieldOnlyFilter, LogicalFilter logicalFilter, NotFilter notFilter, InFilter<?> inFilter, MatchAllFilter matchAllFilter, HasFilter<?> hasFilter) {
        this.f848a = i;
        this.f849b = comparisonFilter;
        this.f850c = fieldOnlyFilter;
        this.f851d = logicalFilter;
        this.f852e = notFilter;
        this.f853f = inFilter;
        this.f854g = matchAllFilter;
        this.f855h = hasFilter;
        if (this.f849b != null) {
            this.f856i = this.f849b;
        } else if (this.f850c != null) {
            this.f856i = this.f850c;
        } else if (this.f851d != null) {
            this.f856i = this.f851d;
        } else if (this.f852e != null) {
            this.f856i = this.f852e;
        } else if (this.f853f != null) {
            this.f856i = this.f853f;
        } else if (this.f854g != null) {
            this.f856i = this.f854g;
        } else if (this.f855h != null) {
            this.f856i = this.f855h;
        } else {
            throw new IllegalArgumentException("At least one filter must be set.");
        }
    }

    public final Filter m1379a() {
        return this.f856i;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format("FilterHolder[%s]", new Object[]{this.f856i});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0255d.m1389a(this, parcel, i);
    }
}
