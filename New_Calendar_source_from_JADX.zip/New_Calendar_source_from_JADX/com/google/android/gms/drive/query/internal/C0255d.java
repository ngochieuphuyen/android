package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.query.internal.d */
public final class C0255d implements Creator<FilterHolder> {
    static void m1389a(FilterHolder filterHolder, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m65a(parcel, 1, filterHolder.f849b, i, false);
        Security.m118c(parcel, 1000, filterHolder.f848a);
        Security.m65a(parcel, 2, filterHolder.f850c, i, false);
        Security.m65a(parcel, 3, filterHolder.f851d, i, false);
        Security.m65a(parcel, 4, filterHolder.f852e, i, false);
        Security.m65a(parcel, 5, filterHolder.f853f, i, false);
        Security.m65a(parcel, 6, filterHolder.f854g, i, false);
        Security.m65a(parcel, 7, filterHolder.f855h, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        HasFilter hasFilter = null;
        int G = Security.m12G(parcel);
        int i = 0;
        MatchAllFilter matchAllFilter = null;
        InFilter inFilter = null;
        NotFilter notFilter = null;
        LogicalFilter logicalFilter = null;
        FieldOnlyFilter fieldOnlyFilter = null;
        ComparisonFilter comparisonFilter = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    comparisonFilter = (ComparisonFilter) Security.m47a(parcel, readInt, ComparisonFilter.CREATOR);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    fieldOnlyFilter = (FieldOnlyFilter) Security.m47a(parcel, readInt, FieldOnlyFilter.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    logicalFilter = (LogicalFilter) Security.m47a(parcel, readInt, LogicalFilter.CREATOR);
                    break;
                case Error.BAD_CARD /*4*/:
                    notFilter = (NotFilter) Security.m47a(parcel, readInt, NotFilter.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    inFilter = (InFilter) Security.m47a(parcel, readInt, InFilter.CREATOR);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    matchAllFilter = (MatchAllFilter) Security.m47a(parcel, readInt, MatchAllFilter.CREATOR);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    hasFilter = (HasFilter) Security.m47a(parcel, readInt, HasFilter.CREATOR);
                    break;
                case 1000:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new FilterHolder(i, comparisonFilter, fieldOnlyFilter, logicalFilter, notFilter, inFilter, matchAllFilter, hasFilter);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new FilterHolder[i];
    }
}
