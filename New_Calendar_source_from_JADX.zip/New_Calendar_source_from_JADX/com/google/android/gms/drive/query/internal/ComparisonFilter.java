package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class ComparisonFilter<T> extends AbstractFilter {
    public static final C0252a CREATOR;
    final Operator f838a;
    final MetadataBundle f839b;
    final int f840c;
    private MetadataField<T> f841d;

    static {
        CREATOR = new C0252a();
    }

    ComparisonFilter(int i, Operator operator, MetadataBundle metadataBundle) {
        this.f840c = i;
        this.f838a = operator;
        this.f839b = metadataBundle;
        this.f841d = C0256e.m1390a(metadataBundle);
    }

    public <F> F m1377a(C0250f<F> c0250f) {
        return c0250f.m1366b(this.f838a, this.f841d, this.f839b.m1323a(this.f841d));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0252a.m1386a(this, parcel, i);
    }
}
