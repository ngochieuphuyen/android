package com.google.android.gms.drive.query;

import com.google.android.gms.drive.metadata.C0230b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.query.internal.C0250f;
import com.google.android.gms.drive.query.internal.Operator;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.c */
public final class C0251c implements C0250f<String> {
    public final /* synthetic */ Object m1371b(C0230b c0230b, Object obj) {
        return String.format("contains(%s,%s)", new Object[]{c0230b.getName(), obj});
    }

    public final /* synthetic */ Object m1372b(Operator operator, MetadataField metadataField, Object obj) {
        return String.format("cmp(%s,%s,%s)", new Object[]{operator.m1385a(), metadataField.getName(), obj});
    }

    public final /* synthetic */ Object m1373b(Operator operator, List list) {
        StringBuilder stringBuilder = new StringBuilder(operator.m1385a() + "(");
        String str = "";
        for (String str2 : list) {
            stringBuilder.append(str);
            stringBuilder.append(str2);
            str = ",";
        }
        return stringBuilder.append(")").toString();
    }

    public final /* synthetic */ Object m1374d(MetadataField metadataField) {
        return String.format("fieldOnly(%s)", new Object[]{metadataField.getName()});
    }

    public final /* synthetic */ Object m1375d(MetadataField metadataField, Object obj) {
        return String.format("has(%s,%s)", new Object[]{metadataField.getName(), obj});
    }

    public final /* synthetic */ Object m1376j(Object obj) {
        return String.format("not(%s)", new Object[]{(String) obj});
    }

    public final /* synthetic */ Object jd() {
        return "all()";
    }
}
