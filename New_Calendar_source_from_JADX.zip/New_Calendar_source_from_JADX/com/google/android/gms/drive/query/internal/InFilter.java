package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.C0230b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;

public class InFilter<T> extends AbstractFilter {
    public static final C0258h CREATOR;
    final MetadataBundle f860a;
    final int f861b;
    private final C0230b<T> f862c;

    static {
        CREATOR = new C0258h();
    }

    InFilter(int i, MetadataBundle metadataBundle) {
        this.f861b = i;
        this.f860a = metadataBundle;
        this.f862c = (C0230b) C0256e.m1390a(metadataBundle);
    }

    public <F> F m1381a(C0250f<F> c0250f) {
        return c0250f.m1365b(this.f862c, ((Collection) this.f860a.m1323a(this.f862c)).iterator().next());
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0258h.m1392a(this, parcel, i);
    }
}
