package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class NotFilter extends AbstractFilter {
    public static final Creator<NotFilter> CREATOR;
    final FilterHolder f867a;
    final int f868b;

    static {
        CREATOR = new C0261k();
    }

    NotFilter(int i, FilterHolder filterHolder) {
        this.f868b = i;
        this.f867a = filterHolder;
    }

    public <T> T m1384a(C0250f<T> c0250f) {
        return c0250f.m1370j(this.f867a.m1379a().m1362a(c0250f));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0261k.m1395a(this, parcel, i);
    }
}
