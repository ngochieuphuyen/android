package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.a */
public final class C0248a implements Creator<Query> {
    static void m1363a(Query query, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1000, query.f834e);
        Security.m65a(parcel, 1, query.f830a, i, false);
        Security.m69a(parcel, 3, query.f831b, false);
        Security.m65a(parcel, 4, query.f832c, i, false);
        Security.m108b(parcel, 5, query.f833d, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        List list = null;
        int G = Security.m12G(parcel);
        int i = 0;
        SortOrder sortOrder = null;
        String str = null;
        LogicalFilter logicalFilter = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    logicalFilter = (LogicalFilter) Security.m47a(parcel, readInt, LogicalFilter.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    sortOrder = (SortOrder) Security.m47a(parcel, readInt, SortOrder.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                case 1000:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new Query(i, logicalFilter, str, sortOrder, list);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new Query[i];
    }
}
