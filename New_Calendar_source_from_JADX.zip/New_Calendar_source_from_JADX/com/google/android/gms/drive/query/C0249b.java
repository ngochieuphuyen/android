package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.query.internal.FieldWithSortOrder;
import com.google.android.gms.games.request.GameRequest;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.b */
public final class C0249b implements Creator<SortOrder> {
    static void m1364a(SortOrder sortOrder, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1000, sortOrder.f837c);
        Security.m119c(parcel, 1, sortOrder.f835a, false);
        Security.m73a(parcel, 2, sortOrder.f836b);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        int G = Security.m12G(parcel);
        List list = null;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    list = Security.m117c(parcel, readInt, FieldWithSortOrder.CREATOR);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case 1000:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new SortOrder(i, list, z);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new SortOrder[i];
    }
}
