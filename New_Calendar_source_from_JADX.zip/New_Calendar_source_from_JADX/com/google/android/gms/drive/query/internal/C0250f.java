package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.metadata.C0230b;
import com.google.android.gms.drive.metadata.MetadataField;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.internal.f */
public interface C0250f<F> {
    <T> F m1365b(C0230b<T> c0230b, T t);

    <T> F m1366b(Operator operator, MetadataField<T> metadataField, T t);

    F m1367b(Operator operator, List<F> list);

    F m1368d(MetadataField<?> metadataField);

    <T> F m1369d(MetadataField<T> metadataField, T t);

    F m1370j(F f);

    F jd();
}
