package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class Operator implements SafeParcelable {
    public static final Creator<Operator> CREATOR;
    final String f869a;
    final int f870b;

    static {
        CREATOR = new C0262l();
        Operator operator = new Operator("=");
        operator = new Operator("<");
        operator = new Operator("<=");
        operator = new Operator(">");
        operator = new Operator(">=");
        operator = new Operator("and");
        operator = new Operator("or");
        operator = new Operator("not");
        operator = new Operator("contains");
    }

    Operator(int i, String str) {
        this.f870b = i;
        this.f869a = str;
    }

    private Operator(String str) {
        this(1, str);
    }

    public final String m1385a() {
        return this.f869a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Operator operator = (Operator) obj;
        return this.f869a == null ? operator.f869a == null : this.f869a.equals(operator.f869a);
    }

    public int hashCode() {
        return (this.f869a == null ? 0 : this.f869a.hashCode()) + 31;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0262l.m1396a(this, parcel);
    }
}
