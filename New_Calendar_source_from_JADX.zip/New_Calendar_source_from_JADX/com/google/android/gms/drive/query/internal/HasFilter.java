package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class HasFilter<T> extends AbstractFilter {
    public static final C0257g CREATOR;
    final MetadataBundle f857a;
    final int f858b;
    private MetadataField<T> f859c;

    static {
        CREATOR = new C0257g();
    }

    HasFilter(int i, MetadataBundle metadataBundle) {
        this.f858b = i;
        this.f857a = metadataBundle;
        this.f859c = C0256e.m1390a(metadataBundle);
    }

    public <F> F m1380a(C0250f<F> c0250f) {
        return c0250f.m1369d(this.f859c, this.f857a.m1323a(this.f859c));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0257g.m1391a(this, parcel, i);
    }
}
