package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Set;

/* renamed from: com.google.android.gms.drive.query.internal.e */
final class C0256e {
    static MetadataField<?> m1390a(MetadataBundle metadataBundle) {
        Set b = metadataBundle.m1325b();
        if (b.size() == 1) {
            return (MetadataField) b.iterator().next();
        }
        throw new IllegalArgumentException("bundle should have exactly 1 populated field");
    }
}
