package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Locale;

public class FieldWithSortOrder implements SafeParcelable {
    public static final C0254c CREATOR;
    final String f845a;
    final boolean f846b;
    final int f847c;

    static {
        CREATOR = new C0254c();
    }

    FieldWithSortOrder(int i, String str, boolean z) {
        this.f847c = i;
        this.f845a = str;
        this.f846b = z;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        Locale locale = Locale.US;
        String str = "FieldWithSortOrder[%s %s]";
        Object[] objArr = new Object[2];
        objArr[0] = this.f845a;
        objArr[1] = this.f846b ? "ASC" : "DESC";
        return String.format(locale, str, objArr);
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0254c.m1388a(this, parcel);
    }
}
