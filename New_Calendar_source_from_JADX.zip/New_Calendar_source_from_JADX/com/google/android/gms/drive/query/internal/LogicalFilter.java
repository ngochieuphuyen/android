package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.List;

public class LogicalFilter extends AbstractFilter {
    public static final Creator<LogicalFilter> CREATOR;
    final Operator f863a;
    final List<FilterHolder> f864b;
    final int f865c;

    static {
        CREATOR = new C0259i();
    }

    LogicalFilter(int i, Operator operator, List<FilterHolder> list) {
        this.f865c = i;
        this.f863a = operator;
        this.f864b = list;
    }

    public <T> T m1382a(C0250f<T> c0250f) {
        List arrayList = new ArrayList();
        for (FilterHolder a : this.f864b) {
            arrayList.add(a.m1379a().m1362a(c0250f));
        }
        return c0250f.m1367b(this.f863a, arrayList);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0259i.m1393a(this, parcel, i);
    }
}
