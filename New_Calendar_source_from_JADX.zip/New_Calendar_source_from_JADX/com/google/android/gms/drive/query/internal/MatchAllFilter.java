package com.google.android.gms.drive.query.internal;

import android.os.Parcel;

public class MatchAllFilter extends AbstractFilter {
    public static final C0260j CREATOR;
    final int f866a;

    static {
        CREATOR = new C0260j();
    }

    public MatchAllFilter() {
        this(1);
    }

    MatchAllFilter(int i) {
        this.f866a = i;
    }

    public <F> F m1383a(C0250f<F> c0250f) {
        return c0250f.jd();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0260j.m1394a(this, parcel);
    }
}
