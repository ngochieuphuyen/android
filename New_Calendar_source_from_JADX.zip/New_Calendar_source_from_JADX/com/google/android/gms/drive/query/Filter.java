package com.google.android.gms.drive.query;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.C0250f;

public interface Filter extends SafeParcelable {
    <T> T m1362a(C0250f<T> c0250f);
}
