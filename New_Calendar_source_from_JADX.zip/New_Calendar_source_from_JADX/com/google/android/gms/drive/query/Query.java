package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.LogicalFilter;
import java.util.List;
import java.util.Locale;

public class Query implements SafeParcelable {
    public static final Creator<Query> CREATOR;
    final LogicalFilter f830a;
    final String f831b;
    final SortOrder f832c;
    final List<String> f833d;
    final int f834e;

    static {
        CREATOR = new C0248a();
    }

    Query(int i, LogicalFilter logicalFilter, String str, SortOrder sortOrder, List<String> list) {
        this.f834e = i;
        this.f830a = logicalFilter;
        this.f831b = str;
        this.f832c = sortOrder;
        this.f833d = list;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format(Locale.US, "Query[%s,%s,PageToken=%s]", new Object[]{this.f830a, this.f832c, this.f831b});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0248a.m1363a(this, parcel, i);
    }
}
