package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.internal.FieldWithSortOrder;
import java.util.List;
import java.util.Locale;

public class SortOrder implements SafeParcelable {
    public static final Creator<SortOrder> CREATOR;
    final List<FieldWithSortOrder> f835a;
    final boolean f836b;
    final int f837c;

    static {
        CREATOR = new C0249b();
    }

    SortOrder(int i, List<FieldWithSortOrder> list, boolean z) {
        this.f837c = i;
        this.f835a = list;
        this.f836b = z;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format(Locale.US, "SortOrder[%s, %s]", new Object[]{TextUtils.join(",", this.f835a), Boolean.valueOf(this.f836b)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0249b.m1364a(this, parcel);
    }
}
