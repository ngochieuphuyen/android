package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class FieldOnlyFilter extends AbstractFilter {
    public static final Creator<FieldOnlyFilter> CREATOR;
    final MetadataBundle f842a;
    final int f843b;
    private final MetadataField<?> f844c;

    static {
        CREATOR = new C0253b();
    }

    FieldOnlyFilter(int i, MetadataBundle metadataBundle) {
        this.f843b = i;
        this.f842a = metadataBundle;
        this.f844c = C0256e.m1390a(metadataBundle);
    }

    public <T> T m1378a(C0250f<T> c0250f) {
        return c0250f.m1368d(this.f844c);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0253b.m1387a(this, parcel, i);
    }
}
