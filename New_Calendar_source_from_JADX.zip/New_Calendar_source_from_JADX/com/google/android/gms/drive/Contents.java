package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class Contents implements SafeParcelable {
    public static final Creator<Contents> CREATOR;
    final int f644a;
    final ParcelFileDescriptor f645b;
    final int f646c;
    final int f647d;
    final DriveId f648e;
    final boolean f649f;

    static {
        CREATOR = new C0181h();
    }

    Contents(int i, ParcelFileDescriptor parcelFileDescriptor, int i2, int i3, DriveId driveId, boolean z) {
        this.f644a = i;
        this.f645b = parcelFileDescriptor;
        this.f646c = i2;
        this.f647d = i3;
        this.f648e = driveId;
        this.f649f = z;
    }

    public final int m1182a() {
        return this.f646c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0181h.m1187a(this, parcel, i);
    }
}
