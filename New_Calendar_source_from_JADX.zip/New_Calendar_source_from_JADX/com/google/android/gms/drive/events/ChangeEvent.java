package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import java.util.Locale;

public final class ChangeEvent implements SafeParcelable, ResourceEvent {
    public static final Creator<ChangeEvent> CREATOR;
    final int f676a;
    final DriveId f677b;
    final int f678c;

    static {
        CREATOR = new C0177a();
    }

    ChangeEvent(int i, DriveId driveId, int i2) {
        this.f676a = i;
        this.f677b = driveId;
        this.f678c = i2;
    }

    public final int describeContents() {
        return 0;
    }

    public final DriveId getDriveId() {
        return this.f677b;
    }

    public final int getType() {
        return 1;
    }

    public final String toString() {
        return String.format(Locale.US, "ChangeEvent [id=%s,changeFlags=%x]", new Object[]{this.f677b, Integer.valueOf(this.f678c)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0177a.m1184a(this, parcel, i);
    }
}
