package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.List;
import java.util.Locale;

public final class CompletionEvent implements SafeParcelable, ResourceEvent {
    public static final Creator<CompletionEvent> CREATOR;
    final int f679a;
    final DriveId f680b;
    final String f681c;
    final ParcelFileDescriptor f682d;
    final ParcelFileDescriptor f683e;
    final MetadataBundle f684f;
    final List<String> f685g;
    final int f686h;
    final IBinder f687i;
    private boolean f688j;

    static {
        CREATOR = new C0178b();
    }

    CompletionEvent(int i, DriveId driveId, String str, ParcelFileDescriptor parcelFileDescriptor, ParcelFileDescriptor parcelFileDescriptor2, MetadataBundle metadataBundle, List<String> list, int i2, IBinder iBinder) {
        this.f688j = false;
        this.f679a = i;
        this.f680b = driveId;
        this.f681c = str;
        this.f682d = parcelFileDescriptor;
        this.f683e = parcelFileDescriptor2;
        this.f684f = metadataBundle;
        this.f685g = list;
        this.f686h = i2;
        this.f687i = iBinder;
    }

    public final int describeContents() {
        return 0;
    }

    public final DriveId getDriveId() {
        return this.f680b;
    }

    public final int getType() {
        return 2;
    }

    public final String toString() {
        String str = this.f685g == null ? "<null>" : "'" + TextUtils.join("','", this.f685g) + "'";
        return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[]{this.f680b, Integer.valueOf(this.f686h), str});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0178b.m1185a(this, parcel, i);
    }
}
