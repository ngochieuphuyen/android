package com.google.android.gms.drive.events;

public interface ChangeListener extends C0176c {
    void onChange(ChangeEvent changeEvent);
}
