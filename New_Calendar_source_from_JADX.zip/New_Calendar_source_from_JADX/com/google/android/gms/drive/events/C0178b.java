package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.List;

/* renamed from: com.google.android.gms.drive.events.b */
public final class C0178b implements Creator<CompletionEvent> {
    static void m1185a(CompletionEvent completionEvent, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, completionEvent.f679a);
        Security.m65a(parcel, 2, completionEvent.f680b, i, false);
        Security.m69a(parcel, 3, completionEvent.f681c, false);
        Security.m65a(parcel, 4, completionEvent.f682d, i, false);
        Security.m65a(parcel, 5, completionEvent.f683e, i, false);
        Security.m65a(parcel, 6, completionEvent.f684f, i, false);
        Security.m108b(parcel, 7, completionEvent.f685g, false);
        Security.m118c(parcel, 8, completionEvent.f686h);
        Security.m63a(parcel, 9, completionEvent.f687i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        IBinder iBinder = null;
        int G = Security.m12G(parcel);
        List list = null;
        MetadataBundle metadataBundle = null;
        ParcelFileDescriptor parcelFileDescriptor = null;
        ParcelFileDescriptor parcelFileDescriptor2 = null;
        String str = null;
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    driveId = (DriveId) Security.m47a(parcel, readInt, DriveId.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    parcelFileDescriptor2 = (ParcelFileDescriptor) Security.m47a(parcel, readInt, ParcelFileDescriptor.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) Security.m47a(parcel, readInt, ParcelFileDescriptor.CREATOR);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    metadataBundle = (MetadataBundle) Security.m47a(parcel, readInt, MetadataBundle.CREATOR);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    iBinder = Security.m151p(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CompletionEvent(i2, driveId, str, parcelFileDescriptor2, parcelFileDescriptor, metadataBundle, list, i, iBinder);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CompletionEvent[i];
    }
}
