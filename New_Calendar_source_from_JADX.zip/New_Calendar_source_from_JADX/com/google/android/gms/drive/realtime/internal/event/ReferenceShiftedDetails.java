package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ReferenceShiftedDetails implements SafeParcelable {
    public static final Creator<ReferenceShiftedDetails> CREATOR;
    final int f911a;
    final String f912b;
    final String f913c;
    final int f914d;
    final int f915e;

    static {
        CREATOR = new C0271d();
    }

    ReferenceShiftedDetails(int i, String str, String str2, int i2, int i3) {
        this.f911a = i;
        this.f912b = str;
        this.f913c = str2;
        this.f914d = i2;
        this.f915e = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0271d.m1408a(this, parcel);
    }
}
