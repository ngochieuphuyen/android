package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class BeginCompoundOperationRequest implements SafeParcelable {
    public static final Creator<BeginCompoundOperationRequest> CREATOR;
    final int f871a;
    final boolean f872b;
    final String f873c;
    final boolean f874d;

    static {
        CREATOR = new C0263a();
    }

    BeginCompoundOperationRequest(int i, boolean z, String str, boolean z2) {
        this.f871a = i;
        this.f872b = z;
        this.f873c = str;
        this.f874d = z2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0263a.m1397a(this, parcel);
    }
}
