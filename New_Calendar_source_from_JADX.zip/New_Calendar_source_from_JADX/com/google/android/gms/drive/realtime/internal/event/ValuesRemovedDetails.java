package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ValuesRemovedDetails implements SafeParcelable {
    public static final Creator<ValuesRemovedDetails> CREATOR;
    final int f930a;
    final int f931b;
    final int f932c;
    final int f933d;
    final String f934e;
    final int f935f;

    static {
        CREATOR = new C0276i();
    }

    ValuesRemovedDetails(int i, int i2, int i3, int i4, String str, int i5) {
        this.f930a = i;
        this.f931b = i2;
        this.f932c = i3;
        this.f933d = i4;
        this.f934e = str;
        this.f935f = i5;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0276i.m1413a(this, parcel);
    }
}
