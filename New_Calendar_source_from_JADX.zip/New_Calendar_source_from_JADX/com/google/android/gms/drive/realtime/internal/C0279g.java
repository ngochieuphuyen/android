package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.realtime.internal.event.ParcelableEventList;

/* renamed from: com.google.android.gms.drive.realtime.internal.g */
public interface C0279g extends IInterface {
    void m1417a(DataHolder dataHolder, ParcelableEventList parcelableEventList);

    void m1418n(Status status);
}
