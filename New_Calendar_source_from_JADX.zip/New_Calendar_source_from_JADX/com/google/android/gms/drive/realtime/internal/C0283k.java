package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.drive.realtime.internal.k */
public interface C0283k extends IInterface {
    void m1423a(ParcelableIndexReference parcelableIndexReference);

    void m1424n(Status status);
}
