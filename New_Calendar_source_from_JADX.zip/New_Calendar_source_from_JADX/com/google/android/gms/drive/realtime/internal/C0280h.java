package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;

/* renamed from: com.google.android.gms.drive.realtime.internal.h */
public interface C0280h extends IInterface {
    void m1419c(boolean z, boolean z2);
}
