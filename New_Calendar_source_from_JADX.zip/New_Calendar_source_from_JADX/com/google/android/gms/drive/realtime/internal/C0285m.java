package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.data.DataHolder;

/* renamed from: com.google.android.gms.drive.realtime.internal.m */
public interface C0285m extends IInterface {
    void m1426a(int i, C0282j c0282j);

    void m1427a(BeginCompoundOperationRequest beginCompoundOperationRequest, C0287o c0287o);

    void m1428a(EndCompoundOperationRequest endCompoundOperationRequest, C0282j c0282j);

    void m1429a(EndCompoundOperationRequest endCompoundOperationRequest, C0287o c0287o);

    void m1430a(ParcelableIndexReference parcelableIndexReference, C0286n c0286n);

    void m1431a(C0265c c0265c);

    void m1432a(C0266d c0266d);

    void m1433a(C0267e c0267e);

    void m1434a(C0280h c0280h);

    void m1435a(C0281i c0281i);

    void m1436a(C0282j c0282j);

    void m1437a(C0284l c0284l);

    void m1438a(C0287o c0287o);

    void m1439a(String str, int i, int i2, C0279g c0279g);

    void m1440a(String str, int i, int i2, C0282j c0282j);

    void m1441a(String str, int i, DataHolder dataHolder, C0279g c0279g);

    void m1442a(String str, int i, DataHolder dataHolder, C0282j c0282j);

    void m1443a(String str, int i, C0287o c0287o);

    void m1444a(String str, int i, String str2, int i2, C0282j c0282j);

    void m1445a(String str, int i, String str2, C0282j c0282j);

    void m1446a(String str, DataHolder dataHolder, C0282j c0282j);

    void m1447a(String str, C0278f c0278f);

    void m1448a(String str, C0282j c0282j);

    void m1449a(String str, C0283k c0283k);

    void m1450a(String str, C0284l c0284l);

    void m1451a(String str, C0286n c0286n);

    void m1452a(String str, C0287o c0287o);

    void m1453a(String str, String str2, C0278f c0278f);

    void m1454a(String str, String str2, C0279g c0279g);

    void m1455a(String str, String str2, C0282j c0282j);

    void m1456b(C0265c c0265c);

    void m1457b(C0282j c0282j);

    void m1458b(C0284l c0284l);

    void m1459b(C0287o c0287o);

    void m1460b(String str, C0278f c0278f);

    void m1461b(String str, C0284l c0284l);

    void m1462b(String str, C0286n c0286n);

    void m1463b(String str, C0287o c0287o);

    void m1464c(C0265c c0265c);

    void m1465c(String str, C0284l c0284l);

    void m1466d(C0265c c0265c);
}
