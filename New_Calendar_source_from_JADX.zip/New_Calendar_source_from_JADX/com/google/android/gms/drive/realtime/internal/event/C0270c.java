package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.c */
public final class C0270c implements Creator<ParcelableEventList> {
    static void m1407a(ParcelableEventList parcelableEventList, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, parcelableEventList.f906a);
        Security.m119c(parcel, 2, parcelableEventList.f907b, false);
        Security.m65a(parcel, 3, parcelableEventList.f908c, i, false);
        Security.m73a(parcel, 4, parcelableEventList.f909d);
        Security.m108b(parcel, 5, parcelableEventList.f910e, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        List list = null;
        int G = Security.m12G(parcel);
        DataHolder dataHolder = null;
        List list2 = null;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    list2 = Security.m117c(parcel, readInt, ParcelableEvent.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    dataHolder = (DataHolder) Security.m47a(parcel, readInt, DataHolder.CREATOR);
                    break;
                case Error.BAD_CARD /*4*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ParcelableEventList(i, list2, dataHolder, z, list);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ParcelableEventList[i];
    }
}
