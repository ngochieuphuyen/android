package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.realtime.internal.p */
public final class C0288p implements Creator<ParcelableCollaborator> {
    static void m1469a(ParcelableCollaborator parcelableCollaborator, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, parcelableCollaborator.f876a);
        Security.m73a(parcel, 2, parcelableCollaborator.f877b);
        Security.m73a(parcel, 3, parcelableCollaborator.f878c);
        Security.m69a(parcel, 4, parcelableCollaborator.f879d, false);
        Security.m69a(parcel, 5, parcelableCollaborator.f880e, false);
        Security.m69a(parcel, 6, parcelableCollaborator.f881f, false);
        Security.m69a(parcel, 7, parcelableCollaborator.f882g, false);
        Security.m69a(parcel, 8, parcelableCollaborator.f883h, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        String str = null;
        int G = Security.m12G(parcel);
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    z2 = Security.m121c(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    str5 = Security.m148o(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ParcelableCollaborator(i, z2, z, str5, str4, str3, str2, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ParcelableCollaborator[i];
    }
}
