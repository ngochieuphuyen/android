package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ParcelableCollaborator implements SafeParcelable {
    public static final Creator<ParcelableCollaborator> CREATOR;
    final int f876a;
    final boolean f877b;
    final boolean f878c;
    final String f879d;
    final String f880e;
    final String f881f;
    final String f882g;
    final String f883h;

    static {
        CREATOR = new C0288p();
    }

    ParcelableCollaborator(int i, boolean z, boolean z2, String str, String str2, String str3, String str4, String str5) {
        this.f876a = i;
        this.f877b = z;
        this.f878c = z2;
        this.f879d = str;
        this.f880e = str2;
        this.f881f = str3;
        this.f882g = str4;
        this.f883h = str5;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ParcelableCollaborator)) {
            return false;
        }
        return this.f879d.equals(((ParcelableCollaborator) obj).f879d);
    }

    public int hashCode() {
        return this.f879d.hashCode();
    }

    public String toString() {
        return "Collaborator [isMe=" + this.f877b + ", isAnonymous=" + this.f878c + ", sessionId=" + this.f879d + ", userId=" + this.f880e + ", displayName=" + this.f881f + ", color=" + this.f882g + ", photoUrl=" + this.f883h + "]";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0288p.m1469a(this, parcel);
    }
}
