package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

/* renamed from: com.google.android.gms.drive.realtime.internal.f */
public interface C0278f extends IInterface {
    void m1415b(DataHolder dataHolder);

    void m1416n(Status status);
}
