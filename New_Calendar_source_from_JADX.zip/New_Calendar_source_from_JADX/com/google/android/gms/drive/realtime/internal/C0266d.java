package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;

/* renamed from: com.google.android.gms.drive.realtime.internal.d */
public interface C0266d extends IInterface {
    void m1401a(ParcelableCollaborator parcelableCollaborator);

    void m1402b(ParcelableCollaborator parcelableCollaborator);
}
