package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.drive.realtime.internal.n */
public interface C0286n extends IInterface {
    void br(String str);

    void m1467n(Status status);
}
