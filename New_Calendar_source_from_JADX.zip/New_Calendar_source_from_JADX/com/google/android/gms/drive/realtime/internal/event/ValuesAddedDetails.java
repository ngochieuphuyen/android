package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ValuesAddedDetails implements SafeParcelable {
    public static final Creator<ValuesAddedDetails> CREATOR;
    final int f924a;
    final int f925b;
    final int f926c;
    final int f927d;
    final String f928e;
    final int f929f;

    static {
        CREATOR = new C0275h();
    }

    ValuesAddedDetails(int i, int i2, int i3, int i4, String str, int i5) {
        this.f924a = i;
        this.f925b = i2;
        this.f926c = i3;
        this.f927d = i4;
        this.f928e = str;
        this.f929f = i5;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0275h.m1412a(this, parcel);
    }
}
