package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.i */
public final class C0276i implements Creator<ValuesRemovedDetails> {
    static void m1413a(ValuesRemovedDetails valuesRemovedDetails, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, valuesRemovedDetails.f930a);
        Security.m118c(parcel, 2, valuesRemovedDetails.f931b);
        Security.m118c(parcel, 3, valuesRemovedDetails.f932c);
        Security.m118c(parcel, 4, valuesRemovedDetails.f933d);
        Security.m69a(parcel, 5, valuesRemovedDetails.f934e, false);
        Security.m118c(parcel, 6, valuesRemovedDetails.f935f);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        String str = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i5 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i4 = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ValuesRemovedDetails(i5, i4, i3, i2, str, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ValuesRemovedDetails[i];
    }
}
