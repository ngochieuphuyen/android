package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.List;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.b */
public final class C0269b implements Creator<ParcelableEvent> {
    static void m1406a(ParcelableEvent parcelableEvent, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, parcelableEvent.f891a);
        Security.m69a(parcel, 2, parcelableEvent.f892b, false);
        Security.m69a(parcel, 3, parcelableEvent.f893c, false);
        Security.m108b(parcel, 4, parcelableEvent.f894d, false);
        Security.m73a(parcel, 5, parcelableEvent.f895e);
        Security.m69a(parcel, 6, parcelableEvent.f896f, false);
        Security.m69a(parcel, 7, parcelableEvent.f897g, false);
        Security.m65a(parcel, 8, parcelableEvent.f898h, i, false);
        Security.m65a(parcel, 9, parcelableEvent.f899i, i, false);
        Security.m65a(parcel, 10, parcelableEvent.f900j, i, false);
        Security.m65a(parcel, 11, parcelableEvent.f901k, i, false);
        Security.m65a(parcel, 12, parcelableEvent.f902l, i, false);
        Security.m65a(parcel, 13, parcelableEvent.f903m, i, false);
        Security.m65a(parcel, 14, parcelableEvent.f904n, i, false);
        Security.m65a(parcel, 15, parcelableEvent.f905o, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        List list = null;
        boolean z = false;
        String str3 = null;
        String str4 = null;
        TextInsertedDetails textInsertedDetails = null;
        TextDeletedDetails textDeletedDetails = null;
        ValuesAddedDetails valuesAddedDetails = null;
        ValuesRemovedDetails valuesRemovedDetails = null;
        ValuesSetDetails valuesSetDetails = null;
        ValueChangedDetails valueChangedDetails = null;
        ReferenceShiftedDetails referenceShiftedDetails = null;
        ObjectChangedDetails objectChangedDetails = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    textInsertedDetails = (TextInsertedDetails) Security.m47a(parcel, readInt, TextInsertedDetails.CREATOR);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    textDeletedDetails = (TextDeletedDetails) Security.m47a(parcel, readInt, TextDeletedDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    valuesAddedDetails = (ValuesAddedDetails) Security.m47a(parcel, readInt, ValuesAddedDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_android_checkable /*11*/:
                    valuesRemovedDetails = (ValuesRemovedDetails) Security.m47a(parcel, readInt, ValuesRemovedDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_android_onClick /*12*/:
                    valuesSetDetails = (ValuesSetDetails) Security.m47a(parcel, readInt, ValuesSetDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_showAsAction /*13*/:
                    valueChangedDetails = (ValueChangedDetails) Security.m47a(parcel, readInt, ValueChangedDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_actionLayout /*14*/:
                    referenceShiftedDetails = (ReferenceShiftedDetails) Security.m47a(parcel, readInt, ReferenceShiftedDetails.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_actionViewClass /*15*/:
                    objectChangedDetails = (ObjectChangedDetails) Security.m47a(parcel, readInt, ObjectChangedDetails.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ParcelableEvent(i, str, str2, list, z, str3, str4, textInsertedDetails, textDeletedDetails, valuesAddedDetails, valuesRemovedDetails, valuesSetDetails, valueChangedDetails, referenceShiftedDetails, objectChangedDetails);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ParcelableEvent[i];
    }
}
