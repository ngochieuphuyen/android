package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class TextDeletedDetails implements SafeParcelable {
    public static final Creator<TextDeletedDetails> CREATOR;
    final int f916a;
    final int f917b;
    final int f918c;

    static {
        CREATOR = new C0272e();
    }

    TextDeletedDetails(int i, int i2, int i3) {
        this.f916a = i;
        this.f917b = i2;
        this.f918c = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0272e.m1409a(this, parcel);
    }
}
