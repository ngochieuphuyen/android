package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class ParcelableEvent implements SafeParcelable {
    public static final Creator<ParcelableEvent> CREATOR;
    final int f891a;
    final String f892b;
    final String f893c;
    final List<String> f894d;
    final boolean f895e;
    final String f896f;
    final String f897g;
    final TextInsertedDetails f898h;
    final TextDeletedDetails f899i;
    final ValuesAddedDetails f900j;
    final ValuesRemovedDetails f901k;
    final ValuesSetDetails f902l;
    final ValueChangedDetails f903m;
    final ReferenceShiftedDetails f904n;
    final ObjectChangedDetails f905o;

    static {
        CREATOR = new C0269b();
    }

    ParcelableEvent(int i, String str, String str2, List<String> list, boolean z, String str3, String str4, TextInsertedDetails textInsertedDetails, TextDeletedDetails textDeletedDetails, ValuesAddedDetails valuesAddedDetails, ValuesRemovedDetails valuesRemovedDetails, ValuesSetDetails valuesSetDetails, ValueChangedDetails valueChangedDetails, ReferenceShiftedDetails referenceShiftedDetails, ObjectChangedDetails objectChangedDetails) {
        this.f891a = i;
        this.f892b = str;
        this.f893c = str2;
        this.f894d = list;
        this.f895e = z;
        this.f896f = str3;
        this.f897g = str4;
        this.f898h = textInsertedDetails;
        this.f899i = textDeletedDetails;
        this.f900j = valuesAddedDetails;
        this.f901k = valuesRemovedDetails;
        this.f902l = valuesSetDetails;
        this.f903m = valueChangedDetails;
        this.f904n = referenceShiftedDetails;
        this.f905o = objectChangedDetails;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0269b.m1406a(this, parcel, i);
    }
}
