package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ParcelableIndexReference implements SafeParcelable {
    public static final Creator<ParcelableIndexReference> CREATOR;
    final int f884a;
    final String f885b;
    final int f886c;
    final boolean f887d;

    static {
        CREATOR = new C0289q();
    }

    ParcelableIndexReference(int i, String str, int i2, boolean z) {
        this.f884a = i;
        this.f885b = str;
        this.f886c = i2;
        this.f887d = z;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0289q.m1470a(this, parcel);
    }
}
