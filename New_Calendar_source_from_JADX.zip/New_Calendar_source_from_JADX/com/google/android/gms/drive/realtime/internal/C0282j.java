package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.realtime.internal.event.ParcelableEventList;

/* renamed from: com.google.android.gms.drive.realtime.internal.j */
public interface C0282j extends IInterface {
    void m1421a(ParcelableEventList parcelableEventList);

    void m1422n(Status status);
}
