package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.drive.realtime.internal.c */
public interface C0265c extends IInterface {
    void m1399N(boolean z);

    void m1400n(Status status);
}
