package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class TextInsertedDetails implements SafeParcelable {
    public static final Creator<TextInsertedDetails> CREATOR;
    final int f919a;
    final int f920b;
    final int f921c;

    static {
        CREATOR = new C0273f();
    }

    TextInsertedDetails(int i, int i2, int i3) {
        this.f919a = i;
        this.f920b = i2;
        this.f921c = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0273f.m1410a(this, parcel);
    }
}
