package com.google.android.gms.drive.realtime.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.drive.realtime.internal.e */
public interface C0267e extends IInterface {
    void m1403a(ParcelableCollaborator[] parcelableCollaboratorArr);

    void m1404n(Status status);
}
