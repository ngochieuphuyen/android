package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.C0230b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/* renamed from: com.google.android.gms.drive.metadata.internal.j */
public class C0242j<T extends Parcelable> extends C0230b<T> {
    public C0242j(String str, int i) {
        super(str, Collections.emptySet(), Collections.singleton(str), i);
    }

    protected final /* synthetic */ Object m1346a(Bundle bundle) {
        return bundle.getParcelableArrayList(getName());
    }

    protected final /* synthetic */ void m1347a(Bundle bundle, Object obj) {
        bundle.putParcelableArrayList(getName(), new ArrayList((Collection) obj));
    }
}
