package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public final class AppVisibleCustomProperties implements SafeParcelable, Iterable<CustomProperty> {
    public static final Creator<AppVisibleCustomProperties> CREATOR;
    public static final AppVisibleCustomProperties f820a;
    final int f821b;
    final List<CustomProperty> f822c;

    static {
        CREATOR = new C0234b();
        f820a = new C0233a().m1326a();
    }

    AppVisibleCustomProperties(int i, Collection<CustomProperty> collection) {
        this.f821b = i;
        LunarUtil.m182a((Object) collection);
        this.f822c = new ArrayList(collection);
    }

    private AppVisibleCustomProperties(Collection<CustomProperty> collection) {
        this(1, (Collection) collection);
    }

    public final int describeContents() {
        return 0;
    }

    public final Iterator<CustomProperty> iterator() {
        return this.f822c.iterator();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0234b.m1327a(this, parcel);
    }
}
