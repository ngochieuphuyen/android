package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.google.android.gms.drive.metadata.a */
public abstract class C0229a<T> implements MetadataField<T> {
    private final String f818a;
    private final Set<String> f819b;

    protected C0229a(String str, int i) {
        this.f818a = (String) LunarUtil.m183a((Object) str, (Object) "fieldName");
        this.f819b = Collections.singleton(str);
        Collections.emptySet();
    }

    protected C0229a(String str, Collection<String> collection, Collection<String> collection2, int i) {
        this.f818a = (String) LunarUtil.m183a((Object) str, (Object) "fieldName");
        this.f819b = Collections.unmodifiableSet(new HashSet(collection));
        Collections.unmodifiableSet(new HashSet(collection2));
    }

    protected abstract T m1310a(Bundle bundle);

    public final T m1311a(DataHolder dataHolder, int i, int i2) {
        return m1315b(dataHolder, i, i2) ? m1316c(dataHolder, i, i2) : null;
    }

    protected abstract void m1312a(Bundle bundle, T t);

    public final void m1313a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2) {
        LunarUtil.m183a((Object) dataHolder, (Object) "dataHolder");
        LunarUtil.m183a((Object) metadataBundle, (Object) "bundle");
        metadataBundle.m1324a(this, m1311a(dataHolder, i, i2));
    }

    public final void m1314a(T t, Bundle bundle) {
        LunarUtil.m183a((Object) bundle, (Object) "bundle");
        if (t == null) {
            bundle.putString(getName(), null);
        } else {
            m1312a(bundle, (Object) t);
        }
    }

    protected boolean m1315b(DataHolder dataHolder, int i, int i2) {
        for (String h : this.f819b) {
            if (dataHolder.m1139h(h, i, i2)) {
                return false;
            }
        }
        return true;
    }

    protected abstract T m1316c(DataHolder dataHolder, int i, int i2);

    public final String getName() {
        return this.f818a;
    }

    public final T m1317h(Bundle bundle) {
        LunarUtil.m183a((Object) bundle, (Object) "bundle");
        return bundle.get(getName()) != null ? m1310a(bundle) : null;
    }

    public String toString() {
        return this.f818a;
    }
}
