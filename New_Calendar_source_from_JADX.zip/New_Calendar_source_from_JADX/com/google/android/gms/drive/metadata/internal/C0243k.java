package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.C0229a;
import java.util.Collection;

/* renamed from: com.google.android.gms.drive.metadata.internal.k */
public abstract class C0243k<T extends Parcelable> extends C0229a<T> {
    public C0243k(String str, Collection<String> collection, Collection<String> collection2, int i) {
        super(str, collection, collection2, i);
    }

    protected final /* synthetic */ Object m1348a(Bundle bundle) {
        return bundle.getParcelable(getName());
    }

    protected final /* synthetic */ void m1349a(Bundle bundle, Object obj) {
        bundle.putParcelable(getName(), (Parcelable) obj);
    }
}
