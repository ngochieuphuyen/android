package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.C0198P;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.C0477e;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MetadataBundle implements SafeParcelable {
    public static final Creator<MetadataBundle> CREATOR;
    final int f826a;
    final Bundle f827b;

    static {
        CREATOR = new C0241i();
    }

    MetadataBundle(int i, Bundle bundle) {
        this.f826a = i;
        this.f827b = (Bundle) LunarUtil.m182a((Object) bundle);
        this.f827b.setClassLoader(getClass().getClassLoader());
        List<String> arrayList = new ArrayList();
        for (String str : this.f827b.keySet()) {
            if (C0238f.m1336a(str) == null) {
                arrayList.add(str);
                C0198P.m1211a("MetadataBundle", "Ignored unknown metadata field in bundle: " + str);
            }
        }
        for (String str2 : arrayList) {
            this.f827b.remove(str2);
        }
    }

    private MetadataBundle(Bundle bundle) {
        this(1, bundle);
    }

    public static MetadataBundle m1321a() {
        return new MetadataBundle(new Bundle());
    }

    public static MetadataBundle m1322a(MetadataBundle metadataBundle) {
        return new MetadataBundle(new Bundle(metadataBundle.f827b));
    }

    public final <T> T m1323a(MetadataField<T> metadataField) {
        return metadataField.m1309h(this.f827b);
    }

    public final <T> void m1324a(MetadataField<T> metadataField, T t) {
        if (C0238f.m1336a(metadataField.getName()) == null) {
            throw new IllegalArgumentException("Unregistered field: " + metadataField.getName());
        }
        metadataField.m1308a(t, this.f827b);
    }

    public final Set<MetadataField<?>> m1325b() {
        Set<MetadataField<?>> hashSet = new HashSet();
        for (String a : this.f827b.keySet()) {
            hashSet.add(C0238f.m1336a(a));
        }
        return hashSet;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MetadataBundle)) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.f827b.keySet();
        if (!keySet.equals(metadataBundle.f827b.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!C0477e.m2759a(this.f827b.get(str), metadataBundle.f827b.get(str))) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 1;
        for (String str : this.f827b.keySet()) {
            i *= 31;
            i = this.f827b.get(str).hashCode() + i;
        }
        return i;
    }

    public final String toString() {
        return "MetadataBundle [values=" + this.f827b + "]";
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0241i.m1345a(this, parcel);
    }
}
