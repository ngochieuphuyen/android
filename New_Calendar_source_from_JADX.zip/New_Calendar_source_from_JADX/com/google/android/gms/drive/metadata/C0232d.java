package com.google.android.gms.drive.metadata;

/* renamed from: com.google.android.gms.drive.metadata.d */
public abstract class C0232d<T extends Comparable<T>> extends C0229a<T> {
    protected C0232d(String str, int i) {
        super(str, i);
    }
}
