package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0229a;

/* renamed from: com.google.android.gms.drive.metadata.internal.c */
public class C0235c extends C0229a<Boolean> {
    public C0235c(String str, int i) {
        super(str, i);
    }

    protected final /* synthetic */ Object m1328a(Bundle bundle) {
        return Boolean.valueOf(bundle.getBoolean(getName()));
    }

    protected final /* synthetic */ void m1329a(Bundle bundle, Object obj) {
        bundle.putBoolean(getName(), ((Boolean) obj).booleanValue());
    }

    protected /* synthetic */ Object m1330c(DataHolder dataHolder, int i, int i2) {
        return m1331d(dataHolder, i, i2);
    }

    protected Boolean m1331d(DataHolder dataHolder, int i, int i2) {
        return Boolean.valueOf(dataHolder.m1130d(getName(), i, i2));
    }
}
