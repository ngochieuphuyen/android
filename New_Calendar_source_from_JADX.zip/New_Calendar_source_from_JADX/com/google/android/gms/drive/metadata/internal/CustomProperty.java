package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.CustomPropertyKey;

public class CustomProperty implements SafeParcelable {
    public static final Creator<CustomProperty> CREATOR;
    final int f823a;
    final CustomPropertyKey f824b;
    final String f825c;

    static {
        CREATOR = new C0236d();
    }

    CustomProperty(int i, CustomPropertyKey customPropertyKey, String str) {
        this.f823a = i;
        LunarUtil.m183a((Object) customPropertyKey, (Object) "key");
        this.f824b = customPropertyKey;
        this.f825c = str;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0236d.m1332a(this, parcel, i);
    }
}
