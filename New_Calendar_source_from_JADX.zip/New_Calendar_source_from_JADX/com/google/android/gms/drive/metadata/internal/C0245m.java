package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0229a;

/* renamed from: com.google.android.gms.drive.metadata.internal.m */
public class C0245m extends C0229a<String> {
    public C0245m(String str, int i) {
        super(str, i);
    }

    protected final /* synthetic */ Object m1354a(Bundle bundle) {
        return bundle.getString(getName());
    }

    protected final /* synthetic */ void m1355a(Bundle bundle, Object obj) {
        bundle.putString(getName(), (String) obj);
    }

    protected final /* synthetic */ Object m1356c(DataHolder dataHolder, int i, int i2) {
        return dataHolder.m1128c(getName(), i, i2);
    }
}
