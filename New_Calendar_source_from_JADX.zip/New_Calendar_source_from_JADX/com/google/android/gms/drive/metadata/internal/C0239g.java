package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0229a;

/* renamed from: com.google.android.gms.drive.metadata.internal.g */
public final class C0239g extends C0229a<Integer> {
    public C0239g(String str, int i) {
        super(str, 4300000);
    }

    protected final /* synthetic */ Object m1339a(Bundle bundle) {
        return Integer.valueOf(bundle.getInt(getName()));
    }

    protected final /* synthetic */ void m1340a(Bundle bundle, Object obj) {
        bundle.putInt(getName(), ((Integer) obj).intValue());
    }

    protected final /* synthetic */ Object m1341c(DataHolder dataHolder, int i, int i2) {
        return Integer.valueOf(dataHolder.m1127b(getName(), i, i2));
    }
}
