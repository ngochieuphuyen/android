package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0232d;
import java.util.Date;

/* renamed from: com.google.android.gms.drive.metadata.internal.e */
public class C0237e extends C0232d<Date> {
    public C0237e(String str, int i) {
        super(str, i);
    }

    protected final /* synthetic */ Object m1333a(Bundle bundle) {
        return new Date(bundle.getLong(getName()));
    }

    protected final /* synthetic */ void m1334a(Bundle bundle, Object obj) {
        bundle.putLong(getName(), ((Date) obj).getTime());
    }

    protected final /* synthetic */ Object m1335c(DataHolder dataHolder, int i, int i2) {
        return new Date(dataHolder.m1122a(getName(), i, i2));
    }
}
