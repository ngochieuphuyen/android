package com.google.android.gms.drive.metadata;

public interface SortableMetadataField<T> extends MetadataField<T> {
}
