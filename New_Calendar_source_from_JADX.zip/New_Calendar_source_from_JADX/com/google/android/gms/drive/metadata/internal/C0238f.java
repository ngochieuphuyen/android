package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.hA;
import com.google.android.gms.internal.hL;
import com.google.android.gms.internal.hS;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.metadata.internal.f */
public final class C0238f {
    private static Map<String, MetadataField<?>> f829a;

    static {
        f829a = new HashMap();
        C0238f.m1338a(hA.f2757a);
        C0238f.m1338a(hA.f2750A);
        C0238f.m1338a(hA.f2774r);
        C0238f.m1338a(hA.f2781y);
        C0238f.m1338a(hA.f2751B);
        C0238f.m1338a(hA.f2768l);
        C0238f.m1338a(hA.f2769m);
        C0238f.m1338a(hA.f2766j);
        C0238f.m1338a(hA.f2771o);
        C0238f.m1338a(hA.f2779w);
        C0238f.m1338a(hA.f2758b);
        C0238f.m1338a(hA.f2776t);
        C0238f.m1338a(hA.f2760d);
        C0238f.m1338a(hA.f2767k);
        C0238f.m1338a(hA.f2761e);
        C0238f.m1338a(hA.f2762f);
        C0238f.m1338a(hA.f2763g);
        C0238f.m1338a(hA.f2773q);
        C0238f.m1338a(hA.f2770n);
        C0238f.m1338a(hA.f2775s);
        C0238f.m1338a(hA.f2777u);
        C0238f.m1338a(hA.f2778v);
        C0238f.m1338a(hA.f2780x);
        C0238f.m1338a(hA.f2752C);
        C0238f.m1338a(hA.f2753D);
        C0238f.m1338a(hA.f2765i);
        C0238f.m1338a(hA.f2764h);
        C0238f.m1338a(hA.f2782z);
        C0238f.m1338a(hA.f2772p);
        C0238f.m1338a(hA.f2759c);
        C0238f.m1338a(hA.f2754E);
        C0238f.m1338a(hA.f2755F);
        C0238f.m1338a(hA.f2756G);
        C0238f.m1338a(hL.f2783a);
        C0238f.m1338a(hL.f2785c);
        C0238f.m1338a(hL.f2786d);
        C0238f.m1338a(hL.f2787e);
        C0238f.m1338a(hL.f2784b);
        C0238f.m1338a(hS.f2789a);
        C0238f.m1338a(hS.f2790b);
    }

    public static MetadataField<?> m1336a(String str) {
        return (MetadataField) f829a.get(str);
    }

    public static Collection<MetadataField<?>> m1337a() {
        return Collections.unmodifiableCollection(f829a.values());
    }

    private static void m1338a(MetadataField<?> metadataField) {
        if (f829a.containsKey(metadataField.getName())) {
            throw new IllegalArgumentException("Duplicate field name registered: " + metadataField.getName());
        }
        f829a.put(metadataField.getName(), metadataField);
    }
}
