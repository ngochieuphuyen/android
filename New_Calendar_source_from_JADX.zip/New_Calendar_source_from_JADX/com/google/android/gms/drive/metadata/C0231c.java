package com.google.android.gms.drive.metadata;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.drive.metadata.c */
public final class C0231c implements Creator<CustomPropertyKey> {
    static void m1320a(CustomPropertyKey customPropertyKey, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, customPropertyKey.f815a);
        Security.m69a(parcel, 2, customPropertyKey.f816b, false);
        Security.m118c(parcel, 3, customPropertyKey.f817c);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CustomPropertyKey(i2, str, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CustomPropertyKey[i];
    }
}
