package com.google.android.gms.drive.metadata;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.regex.Pattern;

public class CustomPropertyKey implements SafeParcelable {
    public static final Creator<CustomPropertyKey> CREATOR;
    private static final Pattern f814d;
    final int f815a;
    final String f816b;
    final int f817c;

    static {
        CREATOR = new C0231c();
        f814d = Pattern.compile("[\\w.!@$%^&*()/-]+");
    }

    CustomPropertyKey(int i, String str, int i2) {
        boolean z = true;
        LunarUtil.m183a((Object) str, (Object) "key");
        LunarUtil.m192b(f814d.matcher(str).matches(), "key name characters must be alphanumeric or one of .!@$%^&*()-_/");
        if (!(i2 == 0 || i2 == 1)) {
            z = false;
        }
        LunarUtil.m192b(z, "visibility must be either PUBLIC or PRIVATE");
        this.f815a = i;
        this.f816b = str;
        this.f817c = i2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CustomPropertyKey)) {
            return false;
        }
        CustomPropertyKey customPropertyKey = (CustomPropertyKey) obj;
        return customPropertyKey.f816b.equals(this.f816b) && customPropertyKey.f817c == this.f817c;
    }

    public int hashCode() {
        return (this.f816b + this.f817c).hashCode();
    }

    public String toString() {
        return "CustomPropertyKey(" + this.f816b + "," + this.f817c + ")";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0231c.m1320a(this, parcel);
    }
}
