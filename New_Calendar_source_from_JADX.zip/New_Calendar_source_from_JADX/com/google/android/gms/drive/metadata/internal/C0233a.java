package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.CustomPropertyKey;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.metadata.internal.a */
public class C0233a {
    private final Map<CustomPropertyKey, CustomProperty> f828a;

    public C0233a() {
        this.f828a = new HashMap();
    }

    public AppVisibleCustomProperties m1326a() {
        return new AppVisibleCustomProperties((byte) 0);
    }
}
