package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.UserMetadata;
import java.util.Arrays;
import java.util.Collections;

/* renamed from: com.google.android.gms.drive.metadata.internal.n */
public final class C0246n extends C0243k<UserMetadata> {
    public C0246n(String str, int i) {
        super(str, Arrays.asList(new String[]{C0246n.m1358a(str, "permissionId"), C0246n.m1358a(str, "displayName"), C0246n.m1358a(str, "picture"), C0246n.m1358a(str, "isAuthenticatedUser"), C0246n.m1358a(str, "emailAddress")}), Collections.emptyList(), 6000000);
    }

    private String m1357a(String str) {
        return C0246n.m1358a(getName(), str);
    }

    private static String m1358a(String str, String str2) {
        return "." + str2;
    }

    protected final boolean m1359b(DataHolder dataHolder, int i, int i2) {
        return !dataHolder.m1139h(m1357a("permissionId"), i, i2);
    }

    protected final /* synthetic */ Object m1360c(DataHolder dataHolder, int i, int i2) {
        String c = dataHolder.m1128c(m1357a("permissionId"), i, i2);
        if (c == null) {
            return null;
        }
        String c2 = dataHolder.m1128c(m1357a("displayName"), i, i2);
        String c3 = dataHolder.m1128c(m1357a("picture"), i, i2);
        Boolean valueOf = Boolean.valueOf(dataHolder.m1130d(m1357a("isAuthenticatedUser"), i, i2));
        return new UserMetadata(c, c2, c3, valueOf.booleanValue(), dataHolder.m1128c(m1357a("emailAddress"), i, i2));
    }
}
