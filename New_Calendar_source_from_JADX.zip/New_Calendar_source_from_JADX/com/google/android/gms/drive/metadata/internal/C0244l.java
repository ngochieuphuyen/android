package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0230b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import org.json.JSONArray;

/* renamed from: com.google.android.gms.drive.metadata.internal.l */
public final class C0244l extends C0230b<String> {
    public C0244l(String str, int i) {
        super(str, Collections.singleton(str), Collections.emptySet(), 4300000);
    }

    protected final /* synthetic */ Object m1350a(Bundle bundle) {
        return bundle.getStringArrayList(getName());
    }

    protected final /* synthetic */ void m1351a(Bundle bundle, Object obj) {
        bundle.putStringArrayList(getName(), new ArrayList((Collection) obj));
    }

    protected final /* synthetic */ Object m1352c(DataHolder dataHolder, int i, int i2) {
        return m1353d(dataHolder, i, i2);
    }

    protected final Collection<String> m1353d(DataHolder dataHolder, int i, int i2) {
        try {
            String c = dataHolder.m1128c(getName(), i, i2);
            if (c == null) {
                return null;
            }
            Collection arrayList = new ArrayList();
            JSONArray jSONArray = new JSONArray(c);
            for (int i3 = 0; i3 < jSONArray.length(); i3++) {
                arrayList.add(jSONArray.getString(i3));
            }
            return Collections.unmodifiableCollection(arrayList);
        } catch (Throwable e) {
            throw new IllegalStateException("DataHolder supplied invalid JSON", e);
        }
    }
}
