package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0229a;

/* renamed from: com.google.android.gms.drive.metadata.internal.h */
public class C0240h extends C0229a<Long> {
    public C0240h(String str, int i) {
        super(str, i);
    }

    protected final /* synthetic */ Object m1342a(Bundle bundle) {
        return Long.valueOf(bundle.getLong(getName()));
    }

    protected final /* synthetic */ void m1343a(Bundle bundle, Object obj) {
        bundle.putLong(getName(), ((Long) obj).longValue());
    }

    protected final /* synthetic */ Object m1344c(DataHolder dataHolder, int i, int i2) {
        return Long.valueOf(dataHolder.m1122a(getName(), i, i2));
    }
}
