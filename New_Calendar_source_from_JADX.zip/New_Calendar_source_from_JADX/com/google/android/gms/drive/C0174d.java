package com.google.android.gms.drive;

import com.google.android.gms.common.data.C0087b;

/* renamed from: com.google.android.gms.drive.d */
public final class C0174d extends C0087b<C0173c> {
    private C0179f f675b;

    public final /* synthetic */ Object m1183a(int i) {
        C0179f c0179f = this.f675b;
        if (c0179f != null && c0179f.f690b == i) {
            return c0179f;
        }
        c0179f = new C0179f(this.a, i);
        this.f675b = c0179f;
        return c0179f;
    }
}
