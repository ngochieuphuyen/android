package com.google.android.gms.drive;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import java.io.InputStream;
import java.io.OutputStream;

public interface DriveContents {
    PendingResult<Status> commit(GoogleApiClient googleApiClient, C0180g c0180g);

    PendingResult<Status> commit(GoogleApiClient googleApiClient, C0180g c0180g, C0171a c0171a);

    void discard(GoogleApiClient googleApiClient);

    DriveId getDriveId();

    InputStream getInputStream();

    int getMode();

    OutputStream getOutputStream();

    ParcelFileDescriptor getParcelFileDescriptor();

    Contents ir();

    void is();

    boolean it();

    PendingResult<DriveContentsResult> reopenForWrite(GoogleApiClient googleApiClient);
}
