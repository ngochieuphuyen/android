package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

public final class ka implements Creator<oh> {
    public static oh m3731a(Parcel parcel) {
        String str = null;
        int G = Security.m12G(parcel);
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case 1000:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new oh(i, str4, str3, str2, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    static void m3732a(oh ohVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m69a(parcel, 1, ohVar.f3139b, false);
        Security.m118c(parcel, 1000, ohVar.f3138a);
        Security.m69a(parcel, 2, ohVar.f3140c, false);
        Security.m69a(parcel, 3, ohVar.f3141d, false);
        Security.m69a(parcel, 4, ohVar.f3142e, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3731a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new oh[i];
    }
}
