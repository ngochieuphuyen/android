package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class fr implements Creator<ha> {
    fr() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new ha(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ha[i];
    }
}
