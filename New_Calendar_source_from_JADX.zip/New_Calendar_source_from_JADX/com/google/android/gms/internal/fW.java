package com.google.android.gms.internal;

import com.google.android.gms.cast.Cast.MessageReceivedCallback;

final class fW implements Runnable {
    private /* synthetic */ String f2590a;
    private /* synthetic */ String f2591b;
    private /* synthetic */ fS f2592c;

    fW(fS fSVar, String str, String str2) {
        this.f2592c = fSVar;
        this.f2590a = str;
        this.f2591b = str2;
    }

    public final void run() {
        synchronized (this.f2592c.f2582a.f2557g) {
            MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.f2592c.f2582a.f2557g.get(this.f2590a);
        }
        if (messageReceivedCallback != null) {
            messageReceivedCallback.onMessageReceived(this.f2592c.f2582a.f2554d, this.f2590a, this.f2591b);
            return;
        }
        fP.f2551b.m3271a("Discarded message for unknown namespace '%s'", this.f2590a);
    }
}
