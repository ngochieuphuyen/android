package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class kk implements SafeParcelable {
    public static final hg CREATOR;
    final int f2971a;
    public final String f2972b;
    public final int f2973c;

    static {
        CREATOR = new hg();
    }

    public kk(int i, String str, int i2) {
        this.f2971a = i;
        this.f2972b = str;
        this.f2973c = i2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        hg.m3332a(this, parcel);
    }
}
