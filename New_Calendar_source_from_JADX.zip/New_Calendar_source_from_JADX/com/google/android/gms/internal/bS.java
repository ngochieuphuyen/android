package com.google.android.gms.internal;

import android.support.v4.p000a.Security;

final class bS implements Runnable {
    private /* synthetic */ bO f1935a;

    bS(bO bOVar) {
        this.f1935a = bOVar;
    }

    public final void run() {
        try {
            this.f1935a.f1930a.onAdOpened();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdOpened.", e);
        }
    }
}
