package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.data.C0092g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.google.android.gms.plus.model.moments.Moment;

public final class kj extends C0092g implements Moment {
    private pf f2970c;

    public kj(DataHolder dataHolder, int i) {
        super(dataHolder, i);
    }

    private pf m3744b() {
        synchronized (this) {
            if (this.f2970c == null) {
                byte[] g = m961g("momentImpl");
                Parcel obtain = Parcel.obtain();
                obtain.unmarshall(g, 0, g.length);
                obtain.setDataPosition(0);
                kg kgVar = pf.CREATOR;
                this.f2970c = kg.m3742a(obtain);
                obtain.recycle();
            }
        }
        return this.f2970c;
    }

    public final /* synthetic */ Object freeze() {
        return m3744b();
    }

    public final String getId() {
        return m3744b().getId();
    }

    public final ItemScope getResult() {
        return m3744b().getResult();
    }

    public final String getStartDate() {
        return m3744b().getStartDate();
    }

    public final ItemScope getTarget() {
        return m3744b().getTarget();
    }

    public final String getType() {
        return m3744b().getType();
    }

    public final boolean hasId() {
        return m3744b().hasId();
    }

    public final boolean hasResult() {
        return m3744b().hasResult();
    }

    public final boolean hasStartDate() {
        return m3744b().hasStartDate();
    }

    public final boolean hasTarget() {
        return m3744b().hasTarget();
    }

    public final boolean hasType() {
        return m3744b().hasType();
    }
}
