package com.google.android.gms.internal;

import android.content.Intent;
import android.os.Bundle;
import android.os.IInterface;

public interface oj extends IInterface {
    void m3917a(int i, Bundle bundle, int i2, Intent intent);
}
