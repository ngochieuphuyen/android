package com.google.android.gms.internal;

import android.text.TextUtils;
import android.util.Log;

public final class gb {
    private static boolean f2699a;
    private String f2700b;
    private boolean f2701c;

    static {
        f2699a = false;
    }

    public gb(String str) {
        this(str, false);
    }

    private gb(String str, boolean z) {
        this.f2700b = str;
        this.f2701c = z;
    }

    private String m3270d(String str, Object... objArr) {
        if (objArr.length != 0) {
            str = String.format(str, objArr);
        }
        return !TextUtils.isEmpty(null) ? null + str : str;
    }

    public final void m3271a(String str, Object... objArr) {
        if (this.f2701c) {
            Log.d(this.f2700b, m3270d(str, objArr));
        }
    }

    public final void m3272a(Throwable th, String str, Object... objArr) {
        if (this.f2701c) {
            Log.d(this.f2700b, m3270d(str, objArr), th);
        }
    }

    public final void m3273b(String str, Object... objArr) {
        Log.i(this.f2700b, m3270d(str, objArr));
    }

    public final void m3274c(String str, Object... objArr) {
        Log.w(this.f2700b, m3270d(str, objArr));
    }
}
