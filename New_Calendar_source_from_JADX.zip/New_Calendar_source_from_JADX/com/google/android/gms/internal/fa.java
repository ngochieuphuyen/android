package com.google.android.gms.internal;

final class fa implements Runnable {
    private /* synthetic */ ct f2594a;

    fa(gv gvVar, ct ctVar) {
        this.f2594a = ctVar;
    }

    public final void run() {
        this.f2594a.m2656d();
    }
}
