package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.maps.model.LatLng;
import java.util.ArrayList;
import java.util.List;

public class oc implements SafeParcelable {
    public static final Creator<oc> CREATOR;
    final int f3126a;
    private final String f3127b;
    private final LatLng f3128c;
    private final String f3129d;
    private final List<oa> f3130e;
    private final String f3131f;
    private final String f3132g;

    static {
        CREATOR = new jW();
    }

    oc(int i, String str, LatLng latLng, String str2, List<oa> list, String str3, String str4) {
        this.f3126a = i;
        this.f3127b = str;
        this.f3128c = latLng;
        this.f3129d = str2;
        this.f3130e = new ArrayList(list);
        this.f3131f = str3;
        this.f3132g = str4;
    }

    public final String m3910a() {
        return this.f3127b;
    }

    public final LatLng m3911b() {
        return this.f3128c;
    }

    public final String m3912c() {
        return this.f3129d;
    }

    public final List<oa> m3913d() {
        return this.f3130e;
    }

    public int describeContents() {
        return 0;
    }

    public final String m3914e() {
        return this.f3131f;
    }

    public final String m3915f() {
        return this.f3132g;
    }

    public void writeToParcel(Parcel parcel, int i) {
        jW.m3574a(this, parcel, i);
    }
}
