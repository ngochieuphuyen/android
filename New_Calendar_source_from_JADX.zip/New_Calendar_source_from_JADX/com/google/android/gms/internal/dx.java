package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;

public interface dx extends IInterface {
    void m2574X();

    void onCreate(Bundle bundle);

    void onDestroy();

    void onPause();

    void onRestart();

    void onResume();

    void onSaveInstanceState(Bundle bundle);

    void onStart();

    void onStop();
}
