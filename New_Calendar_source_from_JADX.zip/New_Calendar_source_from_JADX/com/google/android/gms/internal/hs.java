package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

public final class hs implements Creator<ky> {
    public static ky m3340a(Parcel parcel) {
        kv kvVar = null;
        int G = Security.m12G(parcel);
        int i = 0;
        Parcel parcel2 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    parcel2 = Security.m3D(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    kvVar = (kv) Security.m47a(parcel, readInt, kv.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ky(i, parcel2, kvVar);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    static void m3341a(ky kyVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, kyVar.m3811d());
        Security.m64a(parcel, 2, kyVar.m3812e(), false);
        Security.m65a(parcel, 3, kyVar.m3813f(), i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3340a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ky[i];
    }
}
