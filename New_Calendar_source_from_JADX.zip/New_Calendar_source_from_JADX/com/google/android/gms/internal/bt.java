package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

@ey
public final class bt {
    public final List<bs> f1993a;
    public final long f1994b;
    public final List<String> f1995c;
    public final List<String> f1996d;
    public final List<String> f1997e;
    public final String f1998f;
    public final long f1999g;
    public int f2000h;
    public int f2001i;

    public bt(String str) {
        JSONObject jSONObject = new JSONObject(str);
        if (Security.m157v(2)) {
            Security.m36V("Mediation Response JSON: " + jSONObject.toString(2));
        }
        JSONArray jSONArray = jSONObject.getJSONArray("ad_networks");
        List arrayList = new ArrayList(jSONArray.length());
        int i = -1;
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            bs bsVar = new bs(jSONArray.getJSONObject(i2));
            arrayList.add(bsVar);
            if (i < 0 && m2547a(bsVar)) {
                i = i2;
            }
        }
        this.f2000h = i;
        this.f2001i = jSONArray.length();
        this.f1993a = Collections.unmodifiableList(arrayList);
        this.f1998f = jSONObject.getString("qdata");
        JSONObject optJSONObject = jSONObject.optJSONObject("settings");
        if (optJSONObject != null) {
            this.f1994b = optJSONObject.optLong("ad_network_timeout_millis", -1);
            this.f1995c = Security.m52a(optJSONObject, "click_urls");
            this.f1996d = Security.m52a(optJSONObject, "imp_urls");
            this.f1997e = Security.m52a(optJSONObject, "nofill_urls");
            long optLong = optJSONObject.optLong("refresh", -1);
            this.f1999g = optLong > 0 ? optLong * 1000 : -1;
            return;
        }
        this.f1994b = -1;
        this.f1995c = null;
        this.f1996d = null;
        this.f1997e = null;
        this.f1999g = -1;
    }

    private static boolean m2547a(bs bsVar) {
        for (String equals : bsVar.f1988c) {
            if (equals.equals("com.google.ads.mediation.admob.AdMobAdapter")) {
                return true;
            }
        }
        return false;
    }
}
