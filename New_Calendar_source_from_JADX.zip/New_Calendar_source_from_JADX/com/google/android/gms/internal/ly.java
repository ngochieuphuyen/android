package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.fitness.result.DataTypeResult;

public interface ly extends IInterface {
    void m3373a(DataTypeResult dataTypeResult);
}
