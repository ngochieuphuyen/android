package com.google.android.gms.internal;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.support.v4.p000a.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

@ey
public final class cR extends cY {
    private String f2042a;
    private Context f2043b;
    private String f2044c;
    private ArrayList<String> f2045d;

    public cR(String str, ArrayList<String> arrayList, Context context, String str2) {
        this.f2044c = str;
        this.f2045d = arrayList;
        this.f2042a = str2;
        this.f2043b = context;
    }

    private String m2603a(String str, HashMap<String, String> hashMap) {
        Object obj;
        Object obj2 = "";
        try {
            obj = this.f2043b.getPackageManager().getPackageInfo(this.f2043b.getPackageName(), 0).versionName;
        } catch (Throwable e) {
            Security.m126d("Error to retrieve app version", e);
            obj = obj2;
        }
        long elapsedRealtime = SystemClock.elapsedRealtime() - eB.m2782d().m2801a();
        for (String str2 : hashMap.keySet()) {
            str = str.replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{str2}), String.format("$1%s$2", new Object[]{hashMap.get(str2)}));
        }
        return str.replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"sessionid"}), String.format("$1%s$2", new Object[]{eB.f2272a})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"appid"}), String.format("$1%s$2", new Object[]{r2})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"osversion"}), String.format("$1%s$2", new Object[]{String.valueOf(VERSION.SDK_INT)})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"sdkversion"}), String.format("$1%s$2", new Object[]{this.f2042a})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"appversion"}), String.format("$1%s$2", new Object[]{obj})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"timestamp"}), String.format("$1%s$2", new Object[]{String.valueOf(elapsedRealtime)})).replaceAll(String.format("(?<!@)((?:@@)*)@%s(?<!@)((?:@@)*)@", new Object[]{"[^@]+"}), String.format("$1%s$2", new Object[]{""})).replaceAll("@@", "@");
    }

    private void m2604a() {
        try {
            this.f2043b.getClassLoader().loadClass("com.google.ads.conversiontracking.IAPConversionReporter").getDeclaredMethod("reportWithProductId", new Class[]{Context.class, String.class, String.class, Boolean.TYPE}).invoke(null, new Object[]{this.f2043b, this.f2044c, "", Boolean.valueOf(true)});
        } catch (ClassNotFoundException e) {
            Security.m38W("Google Conversion Tracking SDK 1.2.0 or above is required to report a conversion.");
        } catch (NoSuchMethodException e2) {
            Security.m38W("Google Conversion Tracking SDK 1.2.0 or above is required to report a conversion.");
        } catch (Throwable e3) {
            Security.m126d("Fail to report a conversion.", e3);
        }
    }

    public final String getProductId() {
        return this.f2044c;
    }

    public final void recordPlayBillingResolution(int i) {
        int i2 = 1;
        if (i == 0) {
            m2604a();
        }
        HashMap hashMap = new HashMap();
        hashMap.put("google_play_status", String.valueOf(i));
        hashMap.put("sku", this.f2044c);
        String str = "status";
        if (i != 0) {
            i2 = i == 1 ? 2 : i == 4 ? 3 : 0;
        }
        hashMap.put(str, String.valueOf(i2));
        Iterator it = this.f2045d.iterator();
        while (it.hasNext()) {
            new eV(this.f2043b, this.f2042a, m2603a((String) it.next(), hashMap)).m2593e();
        }
    }

    public final void recordResolution(int i) {
        if (i == 1) {
            m2604a();
        }
        HashMap hashMap = new HashMap();
        hashMap.put("status", String.valueOf(i));
        hashMap.put("sku", this.f2044c);
        Iterator it = this.f2045d.iterator();
        while (it.hasNext()) {
            new eV(this.f2043b, this.f2042a, m2603a((String) it.next(), hashMap)).m2593e();
        }
    }
}
