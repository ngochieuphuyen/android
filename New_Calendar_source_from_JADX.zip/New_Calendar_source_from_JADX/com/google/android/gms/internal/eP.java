package com.google.android.gms.internal;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

@ey
public final class eP<T> implements Future<T> {
    private final T f2324a;

    public eP(T t) {
        this.f2324a = null;
    }

    public final boolean cancel(boolean z) {
        return false;
    }

    public final T get() {
        return this.f2324a;
    }

    public final T get(long j, TimeUnit timeUnit) {
        return this.f2324a;
    }

    public final boolean isCancelled() {
        return false;
    }

    public final boolean isDone() {
        return true;
    }
}
