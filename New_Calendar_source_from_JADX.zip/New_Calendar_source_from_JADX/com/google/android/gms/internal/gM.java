package com.google.android.gms.internal;

import android.support.v4.p003c.LunarUtil;
import java.util.ArrayList;
import java.util.List;

public final class gM {
    private final List<String> f2688a;
    private final Object f2689b;

    private gM(Object obj) {
        this.f2689b = LunarUtil.m182a(obj);
        this.f2688a = new ArrayList();
    }

    public final gM m3252a(String str, Object obj) {
        this.f2688a.add(((String) LunarUtil.m182a((Object) str)) + "=" + String.valueOf(obj));
        return this;
    }

    public final String toString() {
        StringBuilder append = new StringBuilder(100).append(this.f2689b.getClass().getSimpleName()).append('{');
        int size = this.f2688a.size();
        for (int i = 0; i < size; i++) {
            append.append((String) this.f2688a.get(i));
            if (i < size - 1) {
                append.append(", ");
            }
        }
        return append.append('}').toString();
    }
}
