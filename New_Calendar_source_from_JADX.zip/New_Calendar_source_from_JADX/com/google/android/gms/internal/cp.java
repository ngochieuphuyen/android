package com.google.android.gms.internal;

public final class cp {
    private boolean f2103a;
    private boolean f2104b;
    private boolean f2105c;
    private boolean f2106d;
    private boolean f2107e;

    public final cp m2635a(boolean z) {
        this.f2103a = z;
        return this;
    }

    public final cp m2636b(boolean z) {
        this.f2104b = z;
        return this;
    }

    public final cp m2637c(boolean z) {
        this.f2105c = z;
        return this;
    }

    public final cp m2638d(boolean z) {
        this.f2106d = z;
        return this;
    }

    public final cp m2639e(boolean z) {
        this.f2107e = z;
        return this;
    }
}
