package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import java.util.Iterator;

public final class gC implements ServiceConnection {
    private /* synthetic */ gB f2682a;

    public gC(gB gBVar) {
        this.f2682a = gBVar;
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this.f2682a.f2674a.f2672d) {
            this.f2682a.f2680g = iBinder;
            this.f2682a.f2681h = componentName;
            Iterator it = this.f2682a.f2677d.iterator();
            while (it.hasNext()) {
                ((gx) it.next()).onServiceConnected(componentName, iBinder);
            }
            this.f2682a.f2678e = 1;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (this.f2682a.f2674a.f2672d) {
            this.f2682a.f2680g = null;
            this.f2682a.f2681h = componentName;
            Iterator it = this.f2682a.f2677d.iterator();
            while (it.hasNext()) {
                ((gx) it.next()).onServiceDisconnected(componentName);
            }
            this.f2682a.f2678e = 2;
        }
    }
}
