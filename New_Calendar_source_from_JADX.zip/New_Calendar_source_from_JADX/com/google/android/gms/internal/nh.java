package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.IInterface;

public interface nh extends IInterface {
    void m3483a(int i, PendingIntent pendingIntent);

    void m3484a(int i, String[] strArr);

    void m3485b(int i, String[] strArr);
}
