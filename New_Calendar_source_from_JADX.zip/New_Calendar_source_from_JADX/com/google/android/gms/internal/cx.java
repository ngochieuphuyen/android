package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

@ey
final class cx extends RelativeLayout {
    private final eQ f2140a;

    public cx(Context context, String str) {
        super(context);
        this.f2140a = new eQ(context, str);
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        this.f2140a.m2852a(motionEvent);
        return false;
    }
}
