package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

public final class cr implements Creator<C0476do> {
    static void m2641a(C0476do c0476do, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, c0476do.f2233a);
        Security.m69a(parcel, 2, c0476do.f2234b, false);
        Security.m69a(parcel, 3, c0476do.f2235c, false);
        Security.m69a(parcel, 4, c0476do.f2236d, false);
        Security.m69a(parcel, 5, c0476do.f2237e, false);
        Security.m69a(parcel, 6, c0476do.f2238f, false);
        Security.m69a(parcel, 7, c0476do.f2239g, false);
        Security.m69a(parcel, 8, c0476do.f2240h, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        String str = null;
        int G = Security.m12G(parcel);
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str7 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str6 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    str5 = Security.m148o(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new C0476do(i, str7, str6, str5, str4, str3, str2, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0476do[i];
    }
}
