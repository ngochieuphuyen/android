package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import android.util.Base64OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.util.PriorityQueue;

/* renamed from: com.google.android.gms.internal.R */
public final class C0456R {
    private final int f1610a;
    private final int f1611b;
    private final C0455Q f1612c;
    private Base64OutputStream f1613d;
    private ByteArrayOutputStream f1614e;

    public C0456R(int i) {
        this.f1612c = new C0458T();
        this.f1611b = i;
        this.f1610a = 6;
    }

    final String m2303a(String str) {
        String[] split = str.split("\n");
        if (split == null || split.length == 0) {
            return "";
        }
        this.f1614e = new ByteArrayOutputStream();
        this.f1613d = new Base64OutputStream(this.f1614e, 10);
        PriorityQueue priorityQueue = new PriorityQueue(this.f1611b, new C0457S(this));
        for (String b : split) {
            String[] b2 = C0477e.m2761b(b);
            if (b2.length >= 6) {
                C0477e.m2757a(b2, this.f1611b, 6, priorityQueue);
            }
        }
        Iterator it = priorityQueue.iterator();
        while (it.hasNext()) {
            try {
                this.f1613d.write(this.f1612c.m2302a(((C0459U) it.next()).f1617b));
            } catch (Throwable e) {
                Security.m112b("Error while writing hash to byteStream", e);
            }
        }
        try {
            this.f1613d.flush();
            this.f1613d.close();
            return this.f1614e.toString();
        } catch (Throwable e2) {
            Security.m112b("HashManager: unable to convert to base 64", e2);
            return "";
        }
    }
}
