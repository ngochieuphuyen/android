package com.google.android.gms.internal;

import android.support.v4.p000a.Security;

final class bT implements Runnable {
    private /* synthetic */ bO f1936a;

    bT(bO bOVar) {
        this.f1936a = bOVar;
    }

    public final void run() {
        try {
            this.f1936a.f1930a.onAdLoaded();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdLoaded.", e);
        }
    }
}
