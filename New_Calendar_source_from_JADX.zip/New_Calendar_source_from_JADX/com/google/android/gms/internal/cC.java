package com.google.android.gms.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.MediaController;
import android.widget.VideoView;
import java.util.HashMap;
import java.util.Map;

@ey
public final class cC extends FrameLayout implements OnCompletionListener, OnErrorListener, OnPreparedListener {
    private final eY f2011a;
    private final MediaController f2012b;
    private final cD f2013c;
    private final VideoView f2014d;
    private long f2015e;
    private String f2016f;

    public cC(Context context, eY eYVar) {
        super(context);
        this.f2011a = eYVar;
        this.f2014d = new VideoView(context);
        addView(this.f2014d, new LayoutParams(-1, -1, 17));
        this.f2012b = new MediaController(context);
        this.f2013c = new cD(this);
        this.f2013c.m2569b();
        this.f2014d.setOnCompletionListener(this);
        this.f2014d.setOnPreparedListener(this);
        this.f2014d.setOnErrorListener(this);
    }

    public static void m2555a(eY eYVar, String str, String str2) {
        Object obj = str2 == null ? 1 : null;
        Map hashMap = new HashMap(obj != null ? 2 : 3);
        hashMap.put("what", str);
        if (obj == null) {
            hashMap.put("extra", str2);
        }
        m2557a(eYVar, "error", hashMap);
    }

    private static void m2556a(eY eYVar, String str, String str2, String str3) {
        Map hashMap = new HashMap(2);
        hashMap.put(str2, str3);
        m2557a(eYVar, str, hashMap);
    }

    private static void m2557a(eY eYVar, String str, Map<String, String> map) {
        map.put("event", str);
        eYVar.m2878a("onVideoEvent", (Map) map);
    }

    public final void m2558a() {
        this.f2013c.m2568a();
        this.f2014d.stopPlayback();
    }

    public final void m2559a(int i) {
        this.f2014d.seekTo(i);
    }

    public final void m2560a(MotionEvent motionEvent) {
        this.f2014d.dispatchTouchEvent(motionEvent);
    }

    public final void m2561a(String str) {
        this.f2016f = str;
    }

    public final void m2562a(boolean z) {
        if (z) {
            this.f2014d.setMediaController(this.f2012b);
            return;
        }
        this.f2012b.hide();
        this.f2014d.setMediaController(null);
    }

    public final void m2563b() {
        if (TextUtils.isEmpty(this.f2016f)) {
            m2555a(this.f2011a, "no_src", null);
        } else {
            this.f2014d.setVideoPath(this.f2016f);
        }
    }

    public final void m2564c() {
        this.f2014d.pause();
    }

    public final void m2565d() {
        this.f2014d.start();
    }

    public final void m2566e() {
        long currentPosition = (long) this.f2014d.getCurrentPosition();
        if (this.f2015e != currentPosition) {
            m2556a(this.f2011a, "timeupdate", "time", String.valueOf(((float) currentPosition) / 1000.0f));
            this.f2015e = currentPosition;
        }
    }

    public final void onCompletion(MediaPlayer mediaPlayer) {
        m2557a(this.f2011a, "ended", new HashMap(1));
    }

    public final boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        m2555a(this.f2011a, String.valueOf(i), String.valueOf(i2));
        return true;
    }

    public final void onPrepared(MediaPlayer mediaPlayer) {
        m2556a(this.f2011a, "canplaythrough", "duration", String.valueOf(((float) this.f2014d.getDuration()) / 1000.0f));
    }
}
