package com.google.android.gms.internal;

import android.view.View;
import android.view.View.OnClickListener;

final class le implements OnClickListener {
    private /* synthetic */ C0521v f3037a;

    le(la laVar, C0521v c0521v) {
        this.f3037a = c0521v;
    }

    public final void onClick(View view) {
        this.f3037a.m3982a();
    }
}
