package com.google.android.gms.internal;

import android.content.Intent;
import android.support.v4.p000a.Security;

final class lf implements Runnable {
    private /* synthetic */ Intent f3038a;
    private /* synthetic */ la f3039b;

    lf(la laVar, Intent intent) {
        this.f3039b = laVar;
        this.f3038a = intent;
    }

    public final void run() {
        if (!(Security.m122d(this.f3038a) != 0 || this.f3039b.f3030c.f3050j == null || this.f3039b.f3030c.f3050j.f2428b == null || this.f3039b.f3030c.f3050j.f2428b.m2885d() == null)) {
            this.f3039b.f3030c.f3050j.f2428b.m2885d().m2648a();
        }
        this.f3039b.f3030c.f3062v = false;
    }
}
