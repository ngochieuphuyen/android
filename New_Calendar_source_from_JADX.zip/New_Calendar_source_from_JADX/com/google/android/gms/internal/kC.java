package com.google.android.gms.internal;

import android.support.v7.appcompat.C0015R;
import com.google.android.gms.wallet.LineItem.Role;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public final class kC extends kQ<kC> {
    private long f2932a;
    private aL f2933b;
    private aO f2934c;

    public kC() {
        this.f2932a = 0;
        this.f2933b = null;
        this.f2934c = null;
        this.i = null;
        this.j = -1;
    }

    protected final int m3633a() {
        int a = super.m1275a() + kO.m3681c(1, this.f2932a);
        if (this.f2933b != null) {
            a += kO.m3677b(2, this.f2933b);
        }
        return this.f2934c != null ? a + kO.m3677b(3, this.f2934c) : a;
    }

    public final /* synthetic */ kV m3634a(kN kNVar) {
        while (true) {
            int a = kNVar.m3654a();
            switch (a) {
                case Role.REGULAR /*0*/:
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    this.f2932a = kNVar.m3667g();
                    continue;
                case C0015R.styleable.ActionBar_itemPadding /*18*/:
                    if (this.f2933b == null) {
                        this.f2933b = new aL();
                    }
                    kNVar.m3656a(this.f2933b);
                    continue;
                case 26:
                    if (this.f2934c == null) {
                        this.f2934c = new aO();
                    }
                    kNVar.m3656a(this.f2934c);
                    continue;
                default:
                    if (!m1277a(kNVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void m3635a(kO kOVar) {
        kOVar.m3687a(1, this.f2932a);
        if (this.f2933b != null) {
            kOVar.m3688a(2, this.f2933b);
        }
        if (this.f2934c != null) {
            kOVar.m3688a(3, this.f2934c);
        }
        super.m1276a(kOVar);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof kC)) {
            return false;
        }
        kC kCVar = (kC) obj;
        if (this.f2932a != kCVar.f2932a) {
            return false;
        }
        if (this.f2933b == null) {
            if (kCVar.f2933b != null) {
                return false;
            }
        } else if (!this.f2933b.equals(kCVar.f2933b)) {
            return false;
        }
        if (this.f2934c == null) {
            if (kCVar.f2934c != null) {
                return false;
            }
        } else if (!this.f2934c.equals(kCVar.f2934c)) {
            return false;
        }
        return m1278a((kQ) kCVar);
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((this.f2933b == null ? 0 : this.f2933b.hashCode()) + ((((int) (this.f2932a ^ (this.f2932a >>> 32))) + 527) * 31)) * 31;
        if (this.f2934c != null) {
            i = this.f2934c.hashCode();
        }
        return ((hashCode + i) * 31) + m1279c();
    }
}
