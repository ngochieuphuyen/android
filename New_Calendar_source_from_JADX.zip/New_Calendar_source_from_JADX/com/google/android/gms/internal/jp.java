package com.google.android.gms.internal;

import android.app.PendingIntent;
import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.request.C0375u;

final class jp extends hV {
    private /* synthetic */ PendingIntent f2924a;

    jp(jh jhVar, GoogleApiClient googleApiClient, PendingIntent pendingIntent) {
        this.f2924a = pendingIntent;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3619a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        md hUVar = new hU(this);
        luVar.jM().m3415a(new C0375u(this.f2924a), hUVar, luVar.getContext().getPackageName());
    }
}
