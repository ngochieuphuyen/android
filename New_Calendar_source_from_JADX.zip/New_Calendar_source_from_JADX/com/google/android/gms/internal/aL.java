package com.google.android.gms.internal;

import android.support.v7.appcompat.C0015R;
import android.support.v7.internal.widget.ActivityChooserModel;
import com.google.android.gms.wallet.LineItem.Role;

public final class aL extends kQ<aL> {
    private String[] f1713a;
    private String[] f1714b;
    private bH[] f1715c;
    private aK[] f1716d;
    private aH[] f1717e;
    private aH[] f1718f;
    private aH[] f1719g;
    private aM[] f1720h;
    private String f1721k;
    private String f1722l;
    private String f1723m;
    private String f1724n;
    private aG f1725o;
    private float f1726p;
    private boolean f1727q;
    private String[] f1728r;
    private int f1729s;

    public aL() {
        this.f1713a = kX.f2964b;
        this.f1714b = kX.f2964b;
        this.f1715c = bH.m2487b();
        this.f1716d = aK.m2339b();
        this.f1717e = aH.m2328b();
        this.f1718f = aH.m2328b();
        this.f1719g = aH.m2328b();
        this.f1720h = aM.m2346b();
        this.f1721k = "";
        this.f1722l = "";
        this.f1723m = "0";
        this.f1724n = "";
        this.f1725o = null;
        this.f1726p = 0.0f;
        this.f1727q = false;
        this.f1728r = kX.f2964b;
        this.f1729s = 0;
        this.i = null;
        this.j = -1;
    }

    protected final int m2343a() {
        int i;
        int i2;
        int i3;
        int i4 = 0;
        int a = super.m1275a();
        if (this.f1714b == null || this.f1714b.length <= 0) {
            i = a;
        } else {
            i2 = 0;
            i3 = 0;
            for (String str : this.f1714b) {
                if (str != null) {
                    i3++;
                    i2 += kO.m3672a(str);
                }
            }
            i = (a + i2) + (i3 * 1);
        }
        if (this.f1715c != null && this.f1715c.length > 0) {
            i2 = i;
            for (kV kVVar : this.f1715c) {
                if (kVVar != null) {
                    i2 += kO.m3677b(2, kVVar);
                }
            }
            i = i2;
        }
        if (this.f1716d != null && this.f1716d.length > 0) {
            i2 = i;
            for (kV kVVar2 : this.f1716d) {
                if (kVVar2 != null) {
                    i2 += kO.m3677b(3, kVVar2);
                }
            }
            i = i2;
        }
        if (this.f1717e != null && this.f1717e.length > 0) {
            i2 = i;
            for (kV kVVar22 : this.f1717e) {
                if (kVVar22 != null) {
                    i2 += kO.m3677b(4, kVVar22);
                }
            }
            i = i2;
        }
        if (this.f1718f != null && this.f1718f.length > 0) {
            i2 = i;
            for (kV kVVar222 : this.f1718f) {
                if (kVVar222 != null) {
                    i2 += kO.m3677b(5, kVVar222);
                }
            }
            i = i2;
        }
        if (this.f1719g != null && this.f1719g.length > 0) {
            i2 = i;
            for (kV kVVar2222 : this.f1719g) {
                if (kVVar2222 != null) {
                    i2 += kO.m3677b(6, kVVar2222);
                }
            }
            i = i2;
        }
        if (this.f1720h != null && this.f1720h.length > 0) {
            i2 = i;
            for (kV kVVar22222 : this.f1720h) {
                if (kVVar22222 != null) {
                    i2 += kO.m3677b(7, kVVar22222);
                }
            }
            i = i2;
        }
        if (!this.f1721k.equals("")) {
            i += kO.m3678b(9, this.f1721k);
        }
        if (!this.f1722l.equals("")) {
            i += kO.m3678b(10, this.f1722l);
        }
        if (!this.f1723m.equals("0")) {
            i += kO.m3678b(12, this.f1723m);
        }
        if (!this.f1724n.equals("")) {
            i += kO.m3678b(13, this.f1724n);
        }
        if (this.f1725o != null) {
            i += kO.m3677b(14, this.f1725o);
        }
        if (Float.floatToIntBits(this.f1726p) != Float.floatToIntBits(0.0f)) {
            float f = this.f1726p;
            i += kO.m3680c(15) + 4;
        }
        if (this.f1728r != null && this.f1728r.length > 0) {
            i3 = 0;
            a = 0;
            for (String str2 : this.f1728r) {
                if (str2 != null) {
                    a++;
                    i3 += kO.m3672a(str2);
                }
            }
            i = (i + i3) + (a * 2);
        }
        if (this.f1729s != 0) {
            i += kO.m3676b(17, this.f1729s);
        }
        if (this.f1727q) {
            boolean z = this.f1727q;
            i += kO.m3680c(18) + 1;
        }
        if (this.f1713a == null || this.f1713a.length <= 0) {
            return i;
        }
        i2 = 0;
        i3 = 0;
        while (i4 < this.f1713a.length) {
            String str3 = this.f1713a[i4];
            if (str3 != null) {
                i3++;
                i2 += kO.m3672a(str3);
            }
            i4++;
        }
        return (i + i2) + (i3 * 2);
    }

    public final /* synthetic */ kV m2344a(kN kNVar) {
        while (true) {
            int a = kNVar.m3654a();
            int a2;
            Object obj;
            switch (a) {
                case Role.REGULAR /*0*/:
                    break;
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    a2 = kX.m3722a(kNVar, 10);
                    a = this.f1714b == null ? 0 : this.f1714b.length;
                    obj = new String[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1714b, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = kNVar.m3662d();
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = kNVar.m3662d();
                    this.f1714b = obj;
                    continue;
                case C0015R.styleable.ActionBar_itemPadding /*18*/:
                    a2 = kX.m3722a(kNVar, 18);
                    a = this.f1715c == null ? 0 : this.f1715c.length;
                    obj = new bH[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1715c, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new bH();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new bH();
                    kNVar.m3656a(obj[a]);
                    this.f1715c = obj;
                    continue;
                case 26:
                    a2 = kX.m3722a(kNVar, 26);
                    a = this.f1716d == null ? 0 : this.f1716d.length;
                    obj = new aK[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1716d, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aK();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new aK();
                    kNVar.m3656a(obj[a]);
                    this.f1716d = obj;
                    continue;
                case 34:
                    a2 = kX.m3722a(kNVar, 34);
                    a = this.f1717e == null ? 0 : this.f1717e.length;
                    obj = new aH[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1717e, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aH();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new aH();
                    kNVar.m3656a(obj[a]);
                    this.f1717e = obj;
                    continue;
                case 42:
                    a2 = kX.m3722a(kNVar, 42);
                    a = this.f1718f == null ? 0 : this.f1718f.length;
                    obj = new aH[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1718f, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aH();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new aH();
                    kNVar.m3656a(obj[a]);
                    this.f1718f = obj;
                    continue;
                case ActivityChooserModel.DEFAULT_HISTORY_MAX_LENGTH /*50*/:
                    a2 = kX.m3722a(kNVar, 50);
                    a = this.f1719g == null ? 0 : this.f1719g.length;
                    obj = new aH[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1719g, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aH();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new aH();
                    kNVar.m3656a(obj[a]);
                    this.f1719g = obj;
                    continue;
                case 58:
                    a2 = kX.m3722a(kNVar, 58);
                    a = this.f1720h == null ? 0 : this.f1720h.length;
                    obj = new aM[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1720h, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new aM();
                        kNVar.m3656a(obj[a]);
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = new aM();
                    kNVar.m3656a(obj[a]);
                    this.f1720h = obj;
                    continue;
                case 74:
                    this.f1721k = kNVar.m3662d();
                    continue;
                case 82:
                    this.f1722l = kNVar.m3662d();
                    continue;
                case 98:
                    this.f1723m = kNVar.m3662d();
                    continue;
                case 106:
                    this.f1724n = kNVar.m3662d();
                    continue;
                case 114:
                    if (this.f1725o == null) {
                        this.f1725o = new aG();
                    }
                    kNVar.m3656a(this.f1725o);
                    continue;
                case 125:
                    this.f1726p = Float.intBitsToFloat(kNVar.m3668h());
                    continue;
                case 130:
                    a2 = kX.m3722a(kNVar, 130);
                    a = this.f1728r == null ? 0 : this.f1728r.length;
                    obj = new String[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1728r, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = kNVar.m3662d();
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = kNVar.m3662d();
                    this.f1728r = obj;
                    continue;
                case 136:
                    this.f1729s = kNVar.m3666f();
                    continue;
                case 144:
                    this.f1727q = kNVar.m3661c();
                    continue;
                case 154:
                    a2 = kX.m3722a(kNVar, 154);
                    a = this.f1713a == null ? 0 : this.f1713a.length;
                    obj = new String[(a2 + a)];
                    if (a != 0) {
                        System.arraycopy(this.f1713a, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = kNVar.m3662d();
                        kNVar.m3654a();
                        a++;
                    }
                    obj[a] = kNVar.m3662d();
                    this.f1713a = obj;
                    continue;
                default:
                    if (!m1277a(kNVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void m2345a(kO kOVar) {
        int floatToIntBits;
        int i = 0;
        if (this.f1714b != null && this.f1714b.length > 0) {
            for (String str : this.f1714b) {
                if (str != null) {
                    kOVar.m3689a(1, str);
                }
            }
        }
        if (this.f1715c != null && this.f1715c.length > 0) {
            for (kV kVVar : this.f1715c) {
                if (kVVar != null) {
                    kOVar.m3688a(2, kVVar);
                }
            }
        }
        if (this.f1716d != null && this.f1716d.length > 0) {
            for (kV kVVar2 : this.f1716d) {
                if (kVVar2 != null) {
                    kOVar.m3688a(3, kVVar2);
                }
            }
        }
        if (this.f1717e != null && this.f1717e.length > 0) {
            for (kV kVVar22 : this.f1717e) {
                if (kVVar22 != null) {
                    kOVar.m3688a(4, kVVar22);
                }
            }
        }
        if (this.f1718f != null && this.f1718f.length > 0) {
            for (kV kVVar222 : this.f1718f) {
                if (kVVar222 != null) {
                    kOVar.m3688a(5, kVVar222);
                }
            }
        }
        if (this.f1719g != null && this.f1719g.length > 0) {
            for (kV kVVar2222 : this.f1719g) {
                if (kVVar2222 != null) {
                    kOVar.m3688a(6, kVVar2222);
                }
            }
        }
        if (this.f1720h != null && this.f1720h.length > 0) {
            for (kV kVVar22222 : this.f1720h) {
                if (kVVar22222 != null) {
                    kOVar.m3688a(7, kVVar22222);
                }
            }
        }
        if (!this.f1721k.equals("")) {
            kOVar.m3689a(9, this.f1721k);
        }
        if (!this.f1722l.equals("")) {
            kOVar.m3689a(10, this.f1722l);
        }
        if (!this.f1723m.equals("0")) {
            kOVar.m3689a(12, this.f1723m);
        }
        if (!this.f1724n.equals("")) {
            kOVar.m3689a(13, this.f1724n);
        }
        if (this.f1725o != null) {
            kOVar.m3688a(14, this.f1725o);
        }
        if (Float.floatToIntBits(this.f1726p) != Float.floatToIntBits(0.0f)) {
            float f = this.f1726p;
            kOVar.m3696c(15, 5);
            floatToIntBits = Float.floatToIntBits(f);
            kOVar.m3693b(floatToIntBits & 255);
            kOVar.m3693b((floatToIntBits >> 8) & 255);
            kOVar.m3693b((floatToIntBits >> 16) & 255);
            kOVar.m3693b(floatToIntBits >>> 24);
        }
        if (this.f1728r != null && this.f1728r.length > 0) {
            for (String str2 : this.f1728r) {
                if (str2 != null) {
                    kOVar.m3689a(16, str2);
                }
            }
        }
        if (this.f1729s != 0) {
            kOVar.m3686a(17, this.f1729s);
        }
        if (this.f1727q) {
            kOVar.m3690a(18, this.f1727q);
        }
        if (this.f1713a != null && this.f1713a.length > 0) {
            while (i < this.f1713a.length) {
                String str3 = this.f1713a[i];
                if (str3 != null) {
                    kOVar.m3689a(19, str3);
                }
                i++;
            }
        }
        super.m1276a(kOVar);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof aL)) {
            return false;
        }
        aL aLVar = (aL) obj;
        if (!kT.m3712a(this.f1713a, aLVar.f1713a) || !kT.m3712a(this.f1714b, aLVar.f1714b) || !kT.m3712a(this.f1715c, aLVar.f1715c) || !kT.m3712a(this.f1716d, aLVar.f1716d) || !kT.m3712a(this.f1717e, aLVar.f1717e) || !kT.m3712a(this.f1718f, aLVar.f1718f) || !kT.m3712a(this.f1719g, aLVar.f1719g) || !kT.m3712a(this.f1720h, aLVar.f1720h)) {
            return false;
        }
        if (this.f1721k == null) {
            if (aLVar.f1721k != null) {
                return false;
            }
        } else if (!this.f1721k.equals(aLVar.f1721k)) {
            return false;
        }
        if (this.f1722l == null) {
            if (aLVar.f1722l != null) {
                return false;
            }
        } else if (!this.f1722l.equals(aLVar.f1722l)) {
            return false;
        }
        if (this.f1723m == null) {
            if (aLVar.f1723m != null) {
                return false;
            }
        } else if (!this.f1723m.equals(aLVar.f1723m)) {
            return false;
        }
        if (this.f1724n == null) {
            if (aLVar.f1724n != null) {
                return false;
            }
        } else if (!this.f1724n.equals(aLVar.f1724n)) {
            return false;
        }
        if (this.f1725o == null) {
            if (aLVar.f1725o != null) {
                return false;
            }
        } else if (!this.f1725o.equals(aLVar.f1725o)) {
            return false;
        }
        return (Float.floatToIntBits(this.f1726p) == Float.floatToIntBits(aLVar.f1726p) && this.f1727q == aLVar.f1727q && kT.m3712a(this.f1728r, aLVar.f1728r) && this.f1729s == aLVar.f1729s) ? m1278a((kQ) aLVar) : false;
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((this.f1724n == null ? 0 : this.f1724n.hashCode()) + (((this.f1723m == null ? 0 : this.f1723m.hashCode()) + (((this.f1722l == null ? 0 : this.f1722l.hashCode()) + (((this.f1721k == null ? 0 : this.f1721k.hashCode()) + ((((((((((((((((kT.m3710a(this.f1713a) + 527) * 31) + kT.m3710a(this.f1714b)) * 31) + kT.m3710a(this.f1715c)) * 31) + kT.m3710a(this.f1716d)) * 31) + kT.m3710a(this.f1717e)) * 31) + kT.m3710a(this.f1718f)) * 31) + kT.m3710a(this.f1719g)) * 31) + kT.m3710a(this.f1720h)) * 31)) * 31)) * 31)) * 31)) * 31;
        if (this.f1725o != null) {
            i = this.f1725o.hashCode();
        }
        return (((((((this.f1727q ? 1231 : 1237) + ((((hashCode + i) * 31) + Float.floatToIntBits(this.f1726p)) * 31)) * 31) + kT.m3710a(this.f1728r)) * 31) + this.f1729s) * 31) + m1279c();
    }
}
