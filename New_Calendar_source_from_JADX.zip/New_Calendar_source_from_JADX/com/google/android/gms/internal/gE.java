package com.google.android.gms.internal;

import android.support.v4.p003c.LunarUtil;
import android.util.Log;

public final class gE {
    private final String f2684a;

    public gE(String str) {
        this.f2684a = (String) LunarUtil.m182a((Object) str);
    }

    public final boolean m3160a(int i) {
        return Log.isLoggable(this.f2684a, 5);
    }
}
