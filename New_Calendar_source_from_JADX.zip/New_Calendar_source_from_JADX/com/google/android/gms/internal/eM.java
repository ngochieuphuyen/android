package com.google.android.gms.internal;

import android.content.Context;

final class eM implements Runnable {
    private /* synthetic */ Context f2319a;

    eM(Context context) {
        this.f2319a = context;
    }

    public final void run() {
        synchronized (eL.f2314a) {
            eL.f2317d = eL.m2848f(this.f2319a);
            eL.f2314a.notifyAll();
        }
    }
}
