package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.fitness.result.SessionStopResult;
import com.google.code.yadview.EventResource;

public abstract class ip extends Binder implements mc {
    public ip() {
        attachInterface(this, "com.google.android.gms.fitness.internal.ISessionStopCallback");
    }

    public static mc m3461a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.fitness.internal.ISessionStopCallback");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof mc)) ? new is(iBinder) : (mc) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                parcel.enforceInterface("com.google.android.gms.fitness.internal.ISessionStopCallback");
                m3460a(parcel.readInt() != 0 ? (SessionStopResult) SessionStopResult.CREATOR.createFromParcel(parcel) : null);
                parcel2.writeNoException();
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.fitness.internal.ISessionStopCallback");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
