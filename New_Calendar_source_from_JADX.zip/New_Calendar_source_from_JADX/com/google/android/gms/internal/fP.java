package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.support.v4.p000a.Security;
import android.text.TextUtils;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class fP extends gq<iq> {
    private static final Object f2550A;
    private static final gb f2551b;
    private static final Object f2552z;
    private ApplicationMetadata f2553c;
    private final CastDevice f2554d;
    private final Security f2555e;
    private final Handler f2556f;
    private final Map<String, MessageReceivedCallback> f2557g;
    private final long f2558h;
    private fS f2559i;
    private String f2560j;
    private boolean f2561k;
    private boolean f2562l;
    private boolean f2563m;
    private boolean f2564n;
    private double f2565o;
    private int f2566p;
    private int f2567q;
    private final AtomicLong f2568r;
    private String f2569s;
    private String f2570t;
    private Bundle f2571u;
    private final Map<Long, BaseImplementation$b<Status>> f2572v;
    private final fR f2573w;
    private BaseImplementation$b<ApplicationConnectionResult> f2574x;
    private BaseImplementation$b<Status> f2575y;

    static {
        f2551b = new gb("CastClientImpl");
        f2552z = new Object();
        f2550A = new Object();
    }

    public fP(Context context, Looper looper, CastDevice castDevice, long j, Security security, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, null);
        this.f2554d = castDevice;
        this.f2555e = security;
        this.f2558h = j;
        this.f2556f = new Handler(looper);
        this.f2557g = new HashMap();
        this.f2568r = new AtomicLong(0);
        this.f2572v = new HashMap();
        m3040n();
        this.f2573w = new fR();
        m2525a(this.f2573w);
    }

    static /* synthetic */ void m3023a(fP fPVar, ij ijVar) {
        boolean z;
        Object b = ijVar.m3449b();
        if (Security.m96a(b, fPVar.f2560j)) {
            z = false;
        } else {
            fPVar.f2560j = b;
            z = true;
        }
        f2551b.m3271a("hasChanged=%b, mFirstApplicationStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(fPVar.f2562l));
        if (fPVar.f2555e != null && (z || fPVar.f2562l)) {
            Security security = fPVar.f2555e;
        }
        fPVar.f2562l = false;
    }

    static /* synthetic */ void m3024a(fP fPVar, io ioVar) {
        boolean z;
        Object f = ioVar.m3459f();
        if (!Security.m96a(f, fPVar.f2553c)) {
            fPVar.f2553c = f;
            Security security = fPVar.f2555e;
            ApplicationMetadata applicationMetadata = fPVar.f2553c;
        }
        double b = ioVar.m3455b();
        if (b == Double.NaN || b == fPVar.f2565o) {
            z = false;
        } else {
            fPVar.f2565o = b;
            z = true;
        }
        boolean c = ioVar.m3456c();
        if (c != fPVar.f2561k) {
            fPVar.f2561k = c;
            z = true;
        }
        f2551b.m3271a("hasVolumeChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(fPVar.f2563m));
        if (fPVar.f2555e != null && (z || fPVar.f2563m)) {
            security = fPVar.f2555e;
        }
        int d = ioVar.m3457d();
        if (d != fPVar.f2566p) {
            fPVar.f2566p = d;
            z = true;
        } else {
            z = false;
        }
        f2551b.m3271a("hasActiveInputChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(fPVar.f2563m));
        if (fPVar.f2555e != null && (z || fPVar.f2563m)) {
            security = fPVar.f2555e;
            d = fPVar.f2566p;
        }
        d = ioVar.m3458e();
        if (d != fPVar.f2567q) {
            fPVar.f2567q = d;
            z = true;
        } else {
            z = false;
        }
        f2551b.m3271a("hasStandbyStateChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(fPVar.f2563m));
        if (fPVar.f2555e != null && (z || fPVar.f2563m)) {
            security = fPVar.f2555e;
            d = fPVar.f2567q;
        }
        fPVar.f2563m = false;
    }

    private void m3027b(BaseImplementation$b<ApplicationConnectionResult> baseImplementation$b) {
        synchronized (f2552z) {
            if (this.f2574x != null) {
                this.f2574x.m988b(new fQ(new Status(2002)));
            }
            this.f2574x = baseImplementation$b;
        }
    }

    private void m3030c(BaseImplementation$b<Status> baseImplementation$b) {
        synchronized (f2550A) {
            if (this.f2575y != null) {
                baseImplementation$b.m988b(new Status(2001));
                return;
            }
            this.f2575y = baseImplementation$b;
        }
    }

    private void m3040n() {
        this.f2564n = false;
        this.f2566p = -1;
        this.f2567q = -1;
        this.f2553c = null;
        this.f2560j = null;
        this.f2565o = 0.0d;
        this.f2561k = false;
    }

    private void m3041o() {
        f2551b.m3271a("removing all MessageReceivedCallbacks", new Object[0]);
        synchronized (this.f2557g) {
            this.f2557g.clear();
        }
    }

    private void m3042p() {
        if (!this.f2564n || this.f2559i == null || this.f2559i.m3081b()) {
            throw new IllegalStateException("Not connected to a device");
        }
    }

    protected final /* synthetic */ IInterface m3043a(IBinder iBinder) {
        return fY.m3091a(iBinder);
    }

    protected final String m3044a() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    public final void m3045a(double d) {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            throw new IllegalArgumentException("Volume cannot be " + d);
        }
        ((iq) m2536m()).m3084a(d, this.f2565o, this.f2561k);
    }

    protected final void m3046a(int i, IBinder iBinder, Bundle bundle) {
        f2551b.m3271a("in onPostInitHandler; statusCode=%d", Integer.valueOf(i));
        if (i == 0 || i == 1001) {
            this.f2564n = true;
            this.f2562l = true;
            this.f2563m = true;
        } else {
            this.f2564n = false;
        }
        if (i == 1001) {
            this.f2571u = new Bundle();
            this.f2571u.putBoolean("com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING", true);
            i = 0;
        }
        super.m2522a(i, iBinder, bundle);
    }

    public final void m3047a(BaseImplementation$b<Status> baseImplementation$b) {
        m3030c((BaseImplementation$b) baseImplementation$b);
        ((iq) m2536m()).gl();
    }

    protected final void m3048a(jt jtVar, gw gwVar) {
        Bundle bundle = new Bundle();
        f2551b.m3271a("getServiceFromBroker(): mLastApplicationId=%s, mLastSessionId=%s", this.f2569s, this.f2570t);
        this.f2554d.m974a(bundle);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.f2558h);
        if (this.f2569s != null) {
            bundle.putString("last_application_id", this.f2569s);
            if (this.f2570t != null) {
                bundle.putString("last_session_id", this.f2570t);
            }
        }
        this.f2559i = new fS();
        jtVar.m3168a((js) gwVar, 6587000, getContext().getPackageName(), this.f2559i.asBinder(), bundle);
    }

    public final void m3049a(String str) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        synchronized (this.f2557g) {
            MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.f2557g.remove(str);
        }
        if (messageReceivedCallback != null) {
            try {
                ((iq) m2536m()).aJ(str);
            } catch (Throwable e) {
                f2551b.m3272a(e, "Error unregistering namespace (%s): %s", str, e.getMessage());
            }
        }
    }

    public final void m3050a(String str, MessageReceivedCallback messageReceivedCallback) {
        Security.aF(str);
        m3049a(str);
        if (messageReceivedCallback != null) {
            synchronized (this.f2557g) {
                this.f2557g.put(str, messageReceivedCallback);
            }
            ((iq) m2536m()).aI(str);
        }
    }

    public final void m3051a(String str, LaunchOptions launchOptions, BaseImplementation$b<ApplicationConnectionResult> baseImplementation$b) {
        m3027b((BaseImplementation$b) baseImplementation$b);
        ((iq) m2536m()).m3085a(str, launchOptions);
    }

    public final void m3052a(String str, BaseImplementation$b<Status> baseImplementation$b) {
        m3030c((BaseImplementation$b) baseImplementation$b);
        ((iq) m2536m()).aH(str);
    }

    public final void m3053a(String str, String str2, BaseImplementation$b<Status> baseImplementation$b) {
        if (TextUtils.isEmpty(str2)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        } else if (str2.length() > 65536) {
            throw new IllegalArgumentException("Message exceeds maximum size");
        } else {
            Security.aF(str);
            m3042p();
            long incrementAndGet = this.f2568r.incrementAndGet();
            try {
                this.f2572v.put(Long.valueOf(incrementAndGet), baseImplementation$b);
                ((iq) m2536m()).m3086a(str, str2, incrementAndGet);
            } catch (Throwable th) {
                this.f2572v.remove(Long.valueOf(incrementAndGet));
            }
        }
    }

    public final void m3054a(String str, boolean z, BaseImplementation$b<ApplicationConnectionResult> baseImplementation$b) {
        m3027b((BaseImplementation$b) baseImplementation$b);
        ((iq) m2536m()).m3089g(str, false);
    }

    public final void m3055a(boolean z) {
        ((iq) m2536m()).m3088a(z, this.f2565o, this.f2561k);
    }

    protected final String m3056b() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    public final void m3057b(String str, String str2, BaseImplementation$b<ApplicationConnectionResult> baseImplementation$b) {
        m3027b((BaseImplementation$b) baseImplementation$b);
        ((iq) m2536m()).m3090k(str, str2);
    }

    public final void m3058c() {
        ((iq) m2536m()).fY();
    }

    public final double m3059d() {
        m3042p();
        return this.f2565o;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void disconnect() {
        /*
        r6 = this;
        r5 = 1;
        r4 = 0;
        r0 = f2551b;
        r1 = "disconnect(); ServiceListener=%s, isConnected=%b";
        r2 = 2;
        r2 = new java.lang.Object[r2];
        r3 = r6.f2559i;
        r2[r4] = r3;
        r3 = r6.isConnected();
        r3 = java.lang.Boolean.valueOf(r3);
        r2[r5] = r3;
        r0.m3271a(r1, r2);
        r0 = r6.f2559i;
        r1 = 0;
        r6.f2559i = r1;
        if (r0 == 0) goto L_0x0027;
    L_0x0021:
        r0 = r0.m3077a();
        if (r0 != 0) goto L_0x0031;
    L_0x0027:
        r0 = f2551b;
        r1 = "already disposed, so short-circuiting";
        r2 = new java.lang.Object[r4];
        r0.m3271a(r1, r2);
    L_0x0030:
        return;
    L_0x0031:
        r6.m3041o();
        r0 = r6.isConnected();	 Catch:{ RemoteException -> 0x004d }
        if (r0 != 0) goto L_0x0040;
    L_0x003a:
        r0 = r6.m2534k();	 Catch:{ RemoteException -> 0x004d }
        if (r0 == 0) goto L_0x0049;
    L_0x0040:
        r0 = r6.m2536m();	 Catch:{ RemoteException -> 0x004d }
        r0 = (com.google.android.gms.internal.iq) r0;	 Catch:{ RemoteException -> 0x004d }
        r0.disconnect();	 Catch:{ RemoteException -> 0x004d }
    L_0x0049:
        super.disconnect();
        goto L_0x0030;
    L_0x004d:
        r0 = move-exception;
        r1 = f2551b;	 Catch:{ all -> 0x0063 }
        r2 = "Error while disconnecting the controller interface: %s";
        r3 = 1;
        r3 = new java.lang.Object[r3];	 Catch:{ all -> 0x0063 }
        r4 = 0;
        r5 = r0.getMessage();	 Catch:{ all -> 0x0063 }
        r3[r4] = r5;	 Catch:{ all -> 0x0063 }
        r1.m3272a(r0, r2, r3);	 Catch:{ all -> 0x0063 }
        super.disconnect();
        goto L_0x0030;
    L_0x0063:
        r0 = move-exception;
        super.disconnect();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.fP.disconnect():void");
    }

    public final boolean m3060e() {
        m3042p();
        return this.f2561k;
    }

    public final ApplicationMetadata m3061f() {
        m3042p();
        return this.f2553c;
    }

    public final Bundle fX() {
        if (this.f2571u == null) {
            return super.fX();
        }
        Bundle bundle = this.f2571u;
        this.f2571u = null;
        return bundle;
    }

    public final String m3062g() {
        m3042p();
        return this.f2560j;
    }
}
