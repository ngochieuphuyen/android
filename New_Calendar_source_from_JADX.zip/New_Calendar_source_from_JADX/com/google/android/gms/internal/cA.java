package com.google.android.gms.internal;

import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;

@ey
final class cA {
    public final int f2008a;
    public final LayoutParams f2009b;
    public final ViewGroup f2010c;

    public cA(eY eYVar) {
        this.f2009b = eYVar.getLayoutParams();
        ViewParent parent = eYVar.getParent();
        if (parent instanceof ViewGroup) {
            this.f2010c = (ViewGroup) parent;
            this.f2008a = this.f2010c.indexOfChild(eYVar);
            this.f2010c.removeView(eYVar);
            eYVar.m2880a(true);
            return;
        }
        throw new cw("Could not get the parent of the WebView for an overlay.");
    }
}
