package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.List;

/* renamed from: com.google.android.gms.internal.X */
public final class C0462X implements Creator<av> {
    public static av m2309a(Parcel parcel) {
        int G = Security.m12G(parcel);
        int i = 0;
        long j = 0;
        Bundle bundle = null;
        int i2 = 0;
        List list = null;
        boolean z = false;
        int i3 = 0;
        boolean z2 = false;
        String str = null;
        bj bjVar = null;
        Location location = null;
        String str2 = null;
        Bundle bundle2 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    j = Security.m139i(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    bundle = Security.m152q(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    z2 = Security.m121c(parcel, readInt);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    bjVar = (bj) Security.m47a(parcel, readInt, bj.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_android_checkable /*11*/:
                    location = (Location) Security.m47a(parcel, readInt, Location.CREATOR);
                    break;
                case C0015R.styleable.MenuItem_android_onClick /*12*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_showAsAction /*13*/:
                    bundle2 = Security.m152q(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new av(i, j, bundle, i2, list, z, i3, z2, str, bjVar, location, str2, bundle2);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    static void m2310a(av avVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, avVar.f1864a);
        Security.m61a(parcel, 2, avVar.f1865b);
        Security.m62a(parcel, 3, avVar.f1866c, false);
        Security.m118c(parcel, 4, avVar.f1867d);
        Security.m108b(parcel, 5, avVar.f1868e, false);
        Security.m73a(parcel, 6, avVar.f1869f);
        Security.m118c(parcel, 7, avVar.f1870g);
        Security.m73a(parcel, 8, avVar.f1871h);
        Security.m69a(parcel, 9, avVar.f1872i, false);
        Security.m65a(parcel, 10, avVar.f1873j, i, false);
        Security.m65a(parcel, 11, avVar.f1874k, i, false);
        Security.m69a(parcel, 12, avVar.f1875l, false);
        Security.m62a(parcel, 13, avVar.f1876m, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return C0462X.m2309a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new av[i];
    }
}
