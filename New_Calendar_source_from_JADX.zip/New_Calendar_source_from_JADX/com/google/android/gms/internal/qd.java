package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.dynamic.C0294c;
import com.google.android.gms.dynamic.C0295d;
import com.google.android.gms.wallet.fragment.WalletFragmentOptions;

public interface qd extends IInterface {
    qa m3644a(C0295d c0295d, C0294c c0294c, WalletFragmentOptions walletFragmentOptions, qb qbVar);
}
