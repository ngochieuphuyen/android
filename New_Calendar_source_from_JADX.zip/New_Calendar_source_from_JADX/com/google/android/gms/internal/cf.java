package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class cf implements OnClickListener {
    private /* synthetic */ cc f2080a;

    cf(cc ccVar) {
        this.f2080a = ccVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f2080a.f2074c.startActivity(this.f2080a.m2621b());
    }
}
