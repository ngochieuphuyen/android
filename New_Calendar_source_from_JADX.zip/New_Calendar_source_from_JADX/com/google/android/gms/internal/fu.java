package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

public final class fu implements Creator<hd> {
    static void m3132a(hd hdVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m76a(parcel, 1, hdVar.f2798b, i, false);
        Security.m118c(parcel, 1000, hdVar.f2797a);
        Security.m69a(parcel, 2, hdVar.f2799c, false);
        Security.m73a(parcel, 3, hdVar.f2800d);
        Security.m65a(parcel, 4, hdVar.f2801e, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        Account account = null;
        int G = Security.m12G(parcel);
        String str = null;
        hh[] hhVarArr = null;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    hhVarArr = (hh[]) Security.m114b(parcel, readInt, hh.CREATOR);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    account = (Account) Security.m47a(parcel, readInt, Account.CREATOR);
                    break;
                case 1000:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new hd(i, hhVarArr, str, z, account);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new hd[i];
    }
}
