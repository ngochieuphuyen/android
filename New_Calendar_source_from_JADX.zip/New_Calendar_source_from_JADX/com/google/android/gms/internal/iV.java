package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.request.af;

final class iV extends hV {
    private /* synthetic */ af f2855a;

    iV(iT iTVar, GoogleApiClient googleApiClient, af afVar) {
        this.f2855a = afVar;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3386a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3406a(this.f2855a, new hU(this), luVar.getContext().getPackageName());
    }
}
