package com.google.android.gms.internal;

import android.net.Uri.Builder;
import android.support.v4.p000a.Security;
import android.text.TextUtils;
import com.google.android.gms.internal.C0521v.C0506a;

@ey
public final class li implements C0506a {
    private final ex f3065a;
    private final eY f3066b;

    public li(ex exVar, eY eYVar) {
        this.f3065a = exVar;
        this.f3066b = eYVar;
    }

    public final void m3864e(String str) {
        Security.m30S("An auto-clicking creative is blocked");
        Builder builder = new Builder();
        builder.scheme("https");
        builder.path("//pagead2.googlesyndication.com/pagead/gen_204");
        builder.appendQueryParameter("id", "gmob-apps-blocked-navigation");
        if (!TextUtils.isEmpty(str)) {
            builder.appendQueryParameter("navigationURL", str);
        }
        if (!(this.f3065a == null || this.f3065a.f2449b == null || TextUtils.isEmpty(this.f3065a.f2449b.f2633o))) {
            builder.appendQueryParameter("debugDialog", this.f3065a.f2449b.f2633o);
        }
        eL.m2820a(this.f3066b.getContext(), this.f3066b.m2890i().f2732b, builder.toString());
    }
}
