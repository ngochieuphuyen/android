package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.C0089b;
import com.google.android.gms.common.api.Scope;
import com.google.api.client.repackaged.com.google.common.p017a.Preconditions;

public final class gQ {
    public static final Preconditions<gX> f2693a;
    public static final Api<NoOptions> f2694b;
    public static final kd f2695c;
    private static final C0089b<gX, NoOptions> f2696d;

    static {
        f2693a = new Preconditions();
        f2696d = new gR();
        f2694b = new Api(f2696d, f2693a, new Scope[0]);
        f2695c = new gS();
    }
}
