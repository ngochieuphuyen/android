package com.google.android.gms.internal;

public abstract class kQ<M extends kQ<M>> extends kV {
    protected kR f809i;

    protected int m1275a() {
        int i = 0;
        if (this.f809i == null) {
            return 0;
        }
        int i2 = 0;
        while (i < this.f809i.m3700a()) {
            i2 += this.f809i.m3703b(i).m3706a();
            i++;
        }
        return i2;
    }

    public void m1276a(kO kOVar) {
        if (this.f809i != null) {
            for (int i = 0; i < this.f809i.m3700a(); i++) {
                this.f809i.m3703b(i).m3707a(kOVar);
            }
        }
    }

    protected final boolean m1277a(kN kNVar, int i) {
        int j = kNVar.m3670j();
        if (!kNVar.m3659b(i)) {
            return false;
        }
        int b = kX.m3723b(i);
        kW kWVar = new kW(i, kNVar.m3657a(j, kNVar.m3670j() - j));
        kS kSVar = null;
        if (this.f809i == null) {
            this.f809i = new kR();
        } else {
            kSVar = this.f809i.m3701a(b);
        }
        if (kSVar == null) {
            kSVar = new kS();
            this.f809i.m3702a(b, kSVar);
        }
        kSVar.m3708a(kWVar);
        return true;
    }

    protected final boolean m1278a(M m) {
        return (this.f809i == null || this.f809i.m3704b()) ? m.f809i == null || m.f809i.m3704b() : this.f809i.equals(m.f809i);
    }

    protected final int m1279c() {
        return (this.f809i == null || this.f809i.m3704b()) ? 0 : this.f809i.hashCode();
    }
}
