package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

final class dV implements fl {
    private IBinder f2207a;

    dV(IBinder iBinder) {
        this.f2207a = iBinder;
    }

    public final IBinder asBinder() {
        return this.f2207a;
    }

    public final fj m2712b(fh fhVar) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            fj a;
            obtain.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
            if (fhVar != null) {
                obtain.writeInt(1);
                fhVar.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f2207a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            if (obtain2.readInt() != 0) {
                dT dTVar = fj.CREATOR;
                a = dT.m2708a(obtain2);
            } else {
                a = null;
            }
            obtain2.recycle();
            obtain.recycle();
            return a;
        } catch (Throwable th) {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
