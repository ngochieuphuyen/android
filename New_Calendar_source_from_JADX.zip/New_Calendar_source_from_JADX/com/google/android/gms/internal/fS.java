package com.google.android.gms.internal;

import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.Status;
import java.util.concurrent.atomic.AtomicBoolean;

final class fS extends ga {
    final /* synthetic */ fP f2582a;
    private final AtomicBoolean f2583b;

    private fS(fP fPVar) {
        this.f2582a = fPVar;
        this.f2583b = new AtomicBoolean(false);
    }

    private void m3071a(long j, int i) {
        synchronized (this.f2582a.f2572v) {
            BaseImplementation$b baseImplementation$b = (BaseImplementation$b) this.f2582a.f2572v.remove(Long.valueOf(j));
        }
        if (baseImplementation$b != null) {
            baseImplementation$b.m988b(new Status(i));
        }
    }

    private boolean m3072a(int i) {
        synchronized (fP.f2550A) {
            if (this.f2582a.f2575y != null) {
                this.f2582a.f2575y.m988b(new Status(i));
                this.f2582a.f2575y = null;
                return true;
            }
            return false;
        }
    }

    public final void m3073a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
        if (!this.f2583b.get()) {
            this.f2582a.f2553c = applicationMetadata;
            this.f2582a.f2569s = applicationMetadata.m968b();
            this.f2582a.f2570t = str2;
            synchronized (fP.f2552z) {
                if (this.f2582a.f2574x != null) {
                    this.f2582a.f2574x.m988b(new fQ(new Status(0), applicationMetadata, str, str2, z));
                    this.f2582a.f2574x = null;
                }
            }
        }
    }

    public final void m3074a(String str, double d, boolean z) {
        fP.f2551b.m3271a("Deprecated callback: \"onStatusreceived\"", new Object[0]);
    }

    public final void m3075a(String str, long j) {
        if (!this.f2583b.get()) {
            m3071a(j, 0);
        }
    }

    public final void m3076a(String str, long j, int i) {
        if (!this.f2583b.get()) {
            m3071a(j, i);
        }
    }

    public final boolean m3077a() {
        if (this.f2583b.getAndSet(true)) {
            return false;
        }
        this.f2582a.m3040n();
        return true;
    }

    public final void ad(int i) {
        if (m3077a()) {
            fP.f2551b.m3271a("ICastDeviceControllerListener.onDisconnected: %d", Integer.valueOf(i));
            if (i != 0) {
                this.f2582a.m2521a(2);
            }
        }
    }

    public final void ae(int i) {
        if (!this.f2583b.get()) {
            synchronized (fP.f2552z) {
                if (this.f2582a.f2574x != null) {
                    this.f2582a.f2574x.m988b(new fQ(new Status(i)));
                    this.f2582a.f2574x = null;
                }
            }
        }
    }

    public final void af(int i) {
        if (!this.f2583b.get()) {
            m3072a(i);
        }
    }

    public final void ag(int i) {
        if (!this.f2583b.get()) {
            m3072a(i);
        }
    }

    public final void m3078b(ij ijVar) {
        if (!this.f2583b.get()) {
            fP.f2551b.m3271a("onApplicationStatusChanged", new Object[0]);
            this.f2582a.f2556f.post(new fV(this, ijVar));
        }
    }

    public final void m3079b(io ioVar) {
        if (!this.f2583b.get()) {
            fP.f2551b.m3271a("onDeviceStatusChanged", new Object[0]);
            this.f2582a.f2556f.post(new fU(this, ioVar));
        }
    }

    public final void m3080b(String str, byte[] bArr) {
        if (!this.f2583b.get()) {
            fP.f2551b.m3271a("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", str, Integer.valueOf(bArr.length));
        }
    }

    public final boolean m3081b() {
        return this.f2583b.get();
    }

    public final void m3082j(String str, String str2) {
        if (!this.f2583b.get()) {
            fP.f2551b.m3271a("Receive (type=text, ns=%s) %s", str, str2);
            this.f2582a.f2556f.post(new fW(this, str, str2));
        }
    }

    public final void onApplicationDisconnected(int i) {
        if (!this.f2583b.get()) {
            this.f2582a.f2569s = null;
            this.f2582a.f2570t = null;
            m3072a(i);
            if (this.f2582a.f2555e != null) {
                this.f2582a.f2556f.post(new fT(this, i));
            }
        }
    }
}
