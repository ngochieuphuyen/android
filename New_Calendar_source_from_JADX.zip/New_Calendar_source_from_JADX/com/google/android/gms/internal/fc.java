package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.webkit.JsResult;

final class fc implements OnCancelListener {
    private /* synthetic */ JsResult f2596a;

    /* renamed from: com.google.android.gms.internal.fc.a */
    public interface C0482a {
        void m3102a(ew ewVar);
    }

    fc(JsResult jsResult) {
        this.f2596a = jsResult;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        this.f2596a.cancel();
    }
}
