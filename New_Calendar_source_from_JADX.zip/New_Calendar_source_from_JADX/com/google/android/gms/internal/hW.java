package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;

public final class hW extends gq<lz> implements lu {
    private final String f2792b;

    public hW(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.f2792b = str;
    }

    protected final /* synthetic */ IInterface m3319a(IBinder iBinder) {
        return ig.m3421a(iBinder);
    }

    protected final String m3320a() {
        return "com.google.android.gms.fitness.GoogleFitnessService.START";
    }

    protected final void m3321a(jt jtVar, gw gwVar) {
        jtVar.m3172a((js) gwVar, 6587000, getContext().getPackageName(), this.f2792b, m2535l(), new Bundle());
    }

    protected final String m3322b() {
        return "com.google.android.gms.fitness.internal.IGoogleFitnessService";
    }

    public final lz jM() {
        return (lz) m2536m();
    }
}
