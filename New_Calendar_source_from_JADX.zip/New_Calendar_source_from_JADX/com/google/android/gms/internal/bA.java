package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.os.SystemClock;
import android.support.v4.p000a.Security;
import android.text.TextUtils;
import com.google.android.gms.dynamic.C0307q;
import com.google.android.gms.internal.cv.C0468a;

@ey
public final class bA implements C0468a {
    private final String f1890a;
    private final cy f1891b;
    private final long f1892c;
    private final bs f1893d;
    private final av f1894e;
    private final ay f1895f;
    private final Context f1896g;
    private final Object f1897h;
    private final gs f1898i;
    private cz f1899j;
    private int f1900k;

    public bA(Context context, String str, cy cyVar, bt btVar, bs bsVar, av avVar, ay ayVar, gs gsVar) {
        this.f1897h = new Object();
        this.f1900k = -2;
        this.f1896g = context;
        this.f1891b = cyVar;
        this.f1893d = bsVar;
        if ("com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
            this.f1890a = m2462b();
        } else {
            this.f1890a = str;
        }
        this.f1892c = btVar.f1994b != -1 ? btVar.f1994b : 10000;
        this.f1894e = avVar;
        this.f1895f = ayVar;
        this.f1898i = gsVar;
    }

    private void m2459a(long j, long j2, long j3, long j4) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j5 = j2 - (elapsedRealtime - j);
        elapsedRealtime = j4 - (elapsedRealtime - j3);
        if (j5 <= 0 || elapsedRealtime <= 0) {
            Security.m34U("Timed out waiting for adapter.");
            this.f1900k = 3;
            return;
        }
        try {
            this.f1897h.wait(Math.min(j5, elapsedRealtime));
        } catch (InterruptedException e) {
            this.f1900k = -1;
        }
    }

    static /* synthetic */ void m2460a(bA bAVar, bu buVar) {
        try {
            if (bAVar.f1898i.f2734d < 4100000) {
                if (bAVar.f1895f.f1884e) {
                    bAVar.f1899j.m2478a(C0307q.m1508a(bAVar.f1896g), bAVar.f1894e, bAVar.f1893d.f1992g, buVar);
                } else {
                    bAVar.f1899j.m2480a(C0307q.m1508a(bAVar.f1896g), bAVar.f1895f, bAVar.f1894e, bAVar.f1893d.f1992g, (da) buVar);
                }
            } else if (bAVar.f1895f.f1884e) {
                bAVar.f1899j.m2479a(C0307q.m1508a(bAVar.f1896g), bAVar.f1894e, bAVar.f1893d.f1992g, bAVar.f1893d.f1986a, (da) buVar);
            } else {
                bAVar.f1899j.m2481a(C0307q.m1508a(bAVar.f1896g), bAVar.f1895f, bAVar.f1894e, bAVar.f1893d.f1992g, bAVar.f1893d.f1986a, buVar);
            }
        } catch (Throwable e) {
            Security.m126d("Could not request ad from mediation adapter.", e);
            bAVar.m2468k(5);
        }
    }

    private String m2462b() {
        try {
            if (!TextUtils.isEmpty(this.f1893d.f1990e)) {
                return this.f1891b.m2470y(this.f1893d.f1990e) ? "com.google.android.gms.ads.mediation.customevent.CustomEventAdapter" : "com.google.ads.mediation.customevent.CustomEventAdapter";
            }
        } catch (RemoteException e) {
            Security.m38W("Fail to determine the custom event's version, assuming the old one.");
        }
        return "com.google.ads.mediation.customevent.CustomEventAdapter";
    }

    private cz m2463c() {
        Security.m34U("Instantiating mediation adapter: " + this.f1890a);
        try {
            return this.f1891b.m2469x(this.f1890a);
        } catch (Throwable e) {
            Security.m84a("Could not instantiate mediation adapter: " + this.f1890a, e);
            return null;
        }
    }

    public final cv m2466a(long j, long j2) {
        cv cvVar;
        synchronized (this.f1897h) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            bu buVar = new bu();
            eW.f2340a.post(new bB(this, buVar));
            long j3 = this.f1892c;
            while (this.f1900k == -2) {
                m2459a(elapsedRealtime, j3, j, j2);
            }
            cvVar = new cv(this.f1893d, this.f1899j, this.f1890a, buVar, this.f1900k);
        }
        return cvVar;
    }

    public final void m2467a() {
        synchronized (this.f1897h) {
            try {
                if (this.f1899j != null) {
                    this.f1899j.destroy();
                }
            } catch (Throwable e) {
                Security.m126d("Could not destroy mediation adapter.", e);
            }
            this.f1900k = -1;
            this.f1897h.notify();
        }
    }

    public final void m2468k(int i) {
        synchronized (this.f1897h) {
            this.f1900k = i;
            this.f1897h.notify();
        }
    }
}
