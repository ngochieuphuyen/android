package com.google.android.gms.internal;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.v4.p000a.Security;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View.MeasureSpec;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@ey
public final class eY extends WebView implements DownloadListener {
    private final gv f2341a;
    private final eZ f2342b;
    private final Object f2343c;
    private final gO f2344d;
    private final gs f2345e;
    private ct f2346f;
    private ay f2347g;
    private boolean f2348h;
    private boolean f2349i;
    private boolean f2350j;
    private boolean f2351k;
    private final WindowManager f2352l;

    private eY(eZ eZVar, ay ayVar, boolean z, boolean z2, gO gOVar, gs gsVar) {
        super(eZVar);
        this.f2343c = new Object();
        this.f2342b = eZVar;
        this.f2347g = ayVar;
        this.f2348h = z;
        this.f2344d = gOVar;
        this.f2345e = gsVar;
        this.f2352l = (WindowManager) getContext().getSystemService("window");
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        eL.m2819a((Context) eZVar, gsVar.f2732b, settings);
        if (VERSION.SDK_INT >= 17) {
            Security.m53a(getContext(), settings);
            settings.setMediaPlaybackRequiresUserGesture(false);
        } else if (VERSION.SDK_INT >= 11) {
            Security.m53a(getContext(), settings);
        }
        setDownloadListener(this);
        if (VERSION.SDK_INT >= 11) {
            this.f2341a = new fm(this, z2);
        } else {
            this.f2341a = new gv(this, z2);
        }
        setWebViewClient(this.f2341a);
        if (VERSION.SDK_INT >= 14) {
            setWebChromeClient(new fo(this));
        } else if (VERSION.SDK_INT >= 11) {
            setWebChromeClient(new fb(this));
        }
        m2869l();
    }

    public static eY m2867a(Context context, ay ayVar, boolean z, boolean z2, gO gOVar, gs gsVar) {
        return new eY(new eZ(context), ayVar, z, z2, gOVar, gsVar);
    }

    private void m2868a(String str) {
        synchronized (this.f2343c) {
            if (m2872o()) {
                Security.m38W("The webview is destroyed. Ignoring action.");
            } else {
                loadUrl(str);
            }
        }
    }

    private void m2869l() {
        synchronized (this.f2343c) {
            if (this.f2348h || this.f2347g.f1884e) {
                if (VERSION.SDK_INT < 14) {
                    Security.m30S("Disabling hardware acceleration on an overlay.");
                    m2870m();
                } else {
                    Security.m30S("Enabling hardware acceleration on an overlay.");
                    m2871n();
                }
            } else if (VERSION.SDK_INT < 18) {
                Security.m30S("Disabling hardware acceleration on an AdView.");
                m2870m();
            } else {
                Security.m30S("Enabling hardware acceleration on an AdView.");
                m2871n();
            }
        }
    }

    private void m2870m() {
        synchronized (this.f2343c) {
            if (!this.f2349i && VERSION.SDK_INT >= 11) {
                setLayerType(1, null);
            }
            this.f2349i = true;
        }
    }

    private void m2871n() {
        synchronized (this.f2343c) {
            if (this.f2349i && VERSION.SDK_INT >= 11) {
                setLayerType(0, null);
            }
            this.f2349i = false;
        }
    }

    private boolean m2872o() {
        boolean z;
        synchronized (this.f2343c) {
            z = this.f2350j;
        }
        return z;
    }

    public final void m2873a() {
        if (this.f2341a.m3115b()) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            Display defaultDisplay = this.f2352l.getDefaultDisplay();
            defaultDisplay.getMetrics(displayMetrics);
            int c = eL.m2839c(getContext());
            float f = 160.0f / ((float) displayMetrics.densityDpi);
            int round = Math.round(((float) displayMetrics.widthPixels) * f);
            try {
                m2882b("onScreenInfoChanged", new JSONObject().put("width", round).put("height", Math.round(((float) (displayMetrics.heightPixels - c)) * f)).put("density", (double) displayMetrics.density).put("rotation", defaultDisplay.getRotation()));
            } catch (Throwable e) {
                Security.m112b("Error occured while obtaining screen information.", e);
            }
        }
    }

    public final void m2874a(Context context) {
        this.f2342b.setBaseContext(context);
    }

    public final void m2875a(Context context, ay ayVar) {
        synchronized (this.f2343c) {
            this.f2342b.setBaseContext(context);
            this.f2346f = null;
            this.f2347g = ayVar;
            this.f2348h = false;
            this.f2351k = false;
            eL.m2837b((WebView) this);
            loadUrl("about:blank");
            this.f2341a.m3117d();
            setOnTouchListener(null);
            setOnClickListener(null);
        }
    }

    public final void m2876a(ay ayVar) {
        synchronized (this.f2343c) {
            this.f2347g = ayVar;
            requestLayout();
        }
    }

    public final void m2877a(ct ctVar) {
        synchronized (this.f2343c) {
            this.f2346f = ctVar;
        }
    }

    public final void m2878a(String str, Map<String, ?> map) {
        try {
            m2882b(str, eL.m2818a((Map) map));
        } catch (JSONException e) {
            Security.m38W("Could not convert parameters to JSON.");
        }
    }

    public final void m2879a(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("javascript:" + str + "(");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        m2868a(stringBuilder.toString());
    }

    public final void m2880a(boolean z) {
        synchronized (this.f2343c) {
            this.f2348h = z;
            m2869l();
        }
    }

    public final void m2881b() {
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.f2345e.f2732b);
        m2878a("onhide", hashMap);
    }

    public final void m2882b(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("javascript:AFMA_ReceiveMessage('");
        stringBuilder.append(str);
        stringBuilder.append("'");
        stringBuilder.append(",");
        stringBuilder.append(jSONObject2);
        stringBuilder.append(");");
        Security.m36V("Dispatching AFMA event: " + stringBuilder);
        m2868a(stringBuilder.toString());
    }

    public final void m2883b(boolean z) {
        synchronized (this.f2343c) {
            if (this.f2346f != null) {
                this.f2346f.m2652a(z);
            } else {
                this.f2351k = z;
            }
        }
    }

    public final void m2884c() {
        Map hashMap = new HashMap(1);
        hashMap.put("version", this.f2345e.f2732b);
        m2878a("onshow", hashMap);
    }

    public final ct m2885d() {
        ct ctVar;
        synchronized (this.f2343c) {
            ctVar = this.f2346f;
        }
        return ctVar;
    }

    public final void destroy() {
        synchronized (this.f2343c) {
            if (this.f2346f != null) {
                this.f2346f.m2648a();
            }
            this.f2350j = true;
            super.destroy();
        }
    }

    public final ay m2886e() {
        ay ayVar;
        synchronized (this.f2343c) {
            ayVar = this.f2347g;
        }
        return ayVar;
    }

    public final void evaluateJavascript(String str, ValueCallback<String> valueCallback) {
        synchronized (this.f2343c) {
            if (m2872o()) {
                Security.m38W("The webview is destroyed. Ignoring action.");
                if (valueCallback != null) {
                    valueCallback.onReceiveValue(null);
                }
                return;
            }
            super.evaluateJavascript(str, valueCallback);
        }
    }

    public final gv m2887f() {
        return this.f2341a;
    }

    public final boolean m2888g() {
        return this.f2351k;
    }

    public final gO m2889h() {
        return this.f2344d;
    }

    public final gs m2890i() {
        return this.f2345e;
    }

    public final boolean m2891j() {
        boolean z;
        synchronized (this.f2343c) {
            z = this.f2348h;
        }
        return z;
    }

    public final Context m2892k() {
        return this.f2342b.m2893a();
    }

    public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(str), str4);
            getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Security.m30S("Couldn't find an Activity to view url/mimetype: " + str + " / " + str4);
        }
    }

    protected final void onMeasure(int i, int i2) {
        int i3 = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        synchronized (this.f2343c) {
            if (isInEditMode() || this.f2348h) {
                super.onMeasure(i, i2);
                return;
            }
            int mode = MeasureSpec.getMode(i);
            int size = MeasureSpec.getSize(i);
            int mode2 = MeasureSpec.getMode(i2);
            int size2 = MeasureSpec.getSize(i2);
            mode = (mode == Integer.MIN_VALUE || mode == 1073741824) ? size : Integer.MAX_VALUE;
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i3 = size2;
            }
            if (this.f2347g.f1886g > mode || this.f2347g.f1883d > r0) {
                float f = this.f2342b.getResources().getDisplayMetrics().density;
                Security.m38W("Not enough space to show ad. Needs " + ((int) (((float) this.f2347g.f1886g) / f)) + "x" + ((int) (((float) this.f2347g.f1883d) / f)) + " dp, but only has " + ((int) (((float) size) / f)) + "x" + ((int) (((float) size2) / f)) + " dp.");
                if (getVisibility() != 8) {
                    setVisibility(4);
                }
                setMeasuredDimension(0, 0);
            } else {
                if (getVisibility() != 8) {
                    setVisibility(0);
                }
                setMeasuredDimension(this.f2347g.f1886g, this.f2347g.f1883d);
            }
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f2344d != null) {
            this.f2344d.m3258a(motionEvent);
        }
        return super.onTouchEvent(motionEvent);
    }
}
