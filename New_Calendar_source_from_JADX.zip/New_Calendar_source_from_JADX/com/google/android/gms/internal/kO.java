package com.google.android.gms.internal;

import android.support.v4.app.NotificationCompat;
import java.io.UnsupportedEncodingException;

public final class kO {
    private final byte[] f2951a;
    private final int f2952b;
    private int f2953c;

    private kO(byte[] bArr, int i, int i2) {
        this.f2951a = bArr;
        this.f2953c = i;
        this.f2952b = i + i2;
    }

    public static int m3671a(int i) {
        return i >= 0 ? m3684e(i) : 10;
    }

    public static int m3672a(String str) {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            return bytes.length + m3684e(bytes.length);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported.");
        }
    }

    public static kO m3673a(byte[] bArr) {
        return m3674a(bArr, 0, bArr.length);
    }

    public static kO m3674a(byte[] bArr, int i, int i2) {
        return new kO(bArr, i, i2);
    }

    private void m3675a(long j) {
        while ((-128 & j) != 0) {
            m3693b((((int) j) & 127) | NotificationCompat.FLAG_HIGH_PRIORITY);
            j >>>= 7;
        }
        m3693b((int) j);
    }

    public static int m3676b(int i, int i2) {
        return m3680c(i) + m3671a(i2);
    }

    public static int m3677b(int i, kV kVVar) {
        int c = m3680c(i);
        int e = kVVar.m1274e();
        return c + (e + m3684e(e));
    }

    public static int m3678b(int i, String str) {
        return m3680c(i) + m3672a(str);
    }

    private static int m3679b(long j) {
        return (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (Long.MIN_VALUE & j) == 0 ? 9 : 10;
    }

    public static int m3680c(int i) {
        return m3684e(kX.m3721a(i, 0));
    }

    public static int m3681c(int i, long j) {
        return m3680c(i) + m3679b(j);
    }

    private static long m3682c(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public static int m3683d(int i, long j) {
        return m3680c(i) + m3679b(m3682c(j));
    }

    public static int m3684e(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (-268435456 & i) == 0 ? 4 : 5;
    }

    public final int m3685a() {
        return this.f2952b - this.f2953c;
    }

    public final void m3686a(int i, int i2) {
        m3696c(i, 0);
        if (i2 >= 0) {
            m3697d(i2);
        } else {
            m3675a((long) i2);
        }
    }

    public final void m3687a(int i, long j) {
        m3696c(i, 0);
        m3675a(j);
    }

    public final void m3688a(int i, kV kVVar) {
        m3696c(i, 2);
        m3691a(kVVar);
    }

    public final void m3689a(int i, String str) {
        m3696c(i, 2);
        byte[] bytes = str.getBytes("UTF-8");
        m3697d(bytes.length);
        m3695b(bytes);
    }

    public final void m3690a(int i, boolean z) {
        int i2 = 0;
        m3696c(i, 0);
        if (z) {
            i2 = 1;
        }
        m3693b(i2);
    }

    public final void m3691a(kV kVVar) {
        m3697d(kVVar.m1273d());
        kVVar.m1272a(this);
    }

    public final void m3692b() {
        if (m3685a() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public final void m3693b(int i) {
        byte b = (byte) i;
        if (this.f2953c == this.f2952b) {
            throw new kP(this.f2953c, this.f2952b);
        }
        byte[] bArr = this.f2951a;
        int i2 = this.f2953c;
        this.f2953c = i2 + 1;
        bArr[i2] = b;
    }

    public final void m3694b(int i, long j) {
        m3696c(i, 0);
        m3675a(m3682c(j));
    }

    public final void m3695b(byte[] bArr) {
        int length = bArr.length;
        if (this.f2952b - this.f2953c >= length) {
            System.arraycopy(bArr, 0, this.f2951a, this.f2953c, length);
            this.f2953c = length + this.f2953c;
            return;
        }
        throw new kP(this.f2953c, this.f2952b);
    }

    public final void m3696c(int i, int i2) {
        m3697d(kX.m3721a(i, i2));
    }

    public final void m3697d(int i) {
        while ((i & -128) != 0) {
            m3693b((i & 127) | NotificationCompat.FLAG_HIGH_PRIORITY);
            i >>>= 7;
        }
        m3693b(i);
    }
}
