package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

@ey
public final class bg implements cd {
    private final ce f1946a;
    private final C0521v f1947b;

    public bg(ce ceVar, C0521v c0521v) {
        this.f1946a = ceVar;
        this.f1947b = c0521v;
    }

    private static boolean m2505a(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int m2506b(Map<String, String> map) {
        String str = (String) map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return eL.m2838c();
            }
            if ("l".equalsIgnoreCase(str)) {
                return eL.m2834b();
            }
        }
        return -1;
    }

    public final void m2507a(eY eYVar, Map<String, String> map) {
        String str = (String) map.get("a");
        if (str == null) {
            Security.m38W("Action missing from an open GMSG.");
        } else if (this.f1947b == null || this.f1947b.m3985b()) {
            gv f = eYVar.m2887f();
            if ("expand".equalsIgnoreCase(str)) {
                if (eYVar.m2891j()) {
                    Security.m38W("Cannot expand WebView that is already expanded.");
                } else {
                    f.m3112a(m2505a(map), m2506b(map));
                }
            } else if ("webapp".equalsIgnoreCase(str)) {
                str = (String) map.get("u");
                if (str != null) {
                    f.m3113a(m2505a(map), m2506b(map), str);
                } else {
                    f.m3114a(m2505a(map), m2506b(map), (String) map.get("html"), (String) map.get("baseurl"));
                }
            } else if ("in_app_purchase".equalsIgnoreCase(str)) {
                str = (String) map.get("product_id");
                String str2 = (String) map.get("report_urls");
                if (this.f1946a == null) {
                    return;
                }
                if (str2 == null || str2.isEmpty()) {
                    this.f1946a.m2622a(str, new ArrayList());
                    return;
                }
                this.f1946a.m2622a(str, new ArrayList(Arrays.asList(str2.split(" "))));
            } else {
                f.m3106a(new C0476do((String) map.get("i"), (String) map.get("u"), (String) map.get("m"), (String) map.get("p"), (String) map.get("c"), (String) map.get("f"), (String) map.get("e")));
            }
        } else {
            this.f1947b.m3984a((String) map.get("u"));
        }
    }
}
