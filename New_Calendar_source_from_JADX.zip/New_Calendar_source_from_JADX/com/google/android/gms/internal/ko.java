package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.kr.C0499b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public final class ko implements SafeParcelable, C0499b<String, Integer> {
    public static final hk CREATOR;
    private final int f2979a;
    private final HashMap<String, Integer> f2980b;
    private final HashMap<Integer, String> f2981c;

    /* renamed from: com.google.android.gms.internal.ko.a */
    public final class C0498a implements SafeParcelable {
        public static final hl CREATOR;
        final int f2976a;
        final String f2977b;
        final int f2978c;

        static {
            CREATOR = new hl();
        }

        C0498a(int i, String str, int i2) {
            this.f2976a = i;
            this.f2977b = str;
            this.f2978c = i2;
        }

        C0498a(String str, int i) {
            this.f2976a = 1;
            this.f2977b = str;
            this.f2978c = i;
        }

        public final int describeContents() {
            hl hlVar = CREATOR;
            return 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            hl hlVar = CREATOR;
            hl.m3335a(this, parcel);
        }
    }

    static {
        CREATOR = new hk();
    }

    public ko() {
        this.f2979a = 1;
        this.f2980b = new HashMap();
        this.f2981c = new HashMap();
    }

    ko(int i, ArrayList<C0498a> arrayList) {
        this.f2979a = i;
        this.f2980b = new HashMap();
        this.f2981c = new HashMap();
        m3752a(arrayList);
    }

    private void m3752a(ArrayList<C0498a> arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C0498a c0498a = (C0498a) it.next();
            m3754a(c0498a.f2977b, c0498a.f2978c);
        }
    }

    final int m3753a() {
        return this.f2979a;
    }

    public final ko m3754a(String str, int i) {
        this.f2980b.put(str, Integer.valueOf(i));
        this.f2981c.put(Integer.valueOf(i), str);
        return this;
    }

    final ArrayList<C0498a> m3755b() {
        ArrayList<C0498a> arrayList = new ArrayList();
        for (String str : this.f2980b.keySet()) {
            arrayList.add(new C0498a(str, ((Integer) this.f2980b.get(str)).intValue()));
        }
        return arrayList;
    }

    public final /* synthetic */ Object convertBack(Object obj) {
        String str = (String) this.f2981c.get((Integer) obj);
        return (str == null && this.f2980b.containsKey("gms_unknown")) ? "gms_unknown" : str;
    }

    public final int describeContents() {
        hk hkVar = CREATOR;
        return 0;
    }

    public final int hI() {
        return 7;
    }

    public final int hJ() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        hk hkVar = CREATOR;
        hk.m3334a(this, parcel);
    }
}
