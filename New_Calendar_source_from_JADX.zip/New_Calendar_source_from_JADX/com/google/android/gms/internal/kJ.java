package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.dynamic.C0302m;
import com.google.android.gms.dynamic.C0305o;
import com.google.android.gms.wallet.fragment.WalletFragmentOptions;
import com.google.code.yadview.EventResource;

public abstract class kJ extends Binder implements qd {
    public static qd m3645a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof qd)) ? new kK(iBinder) : (qd) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        IBinder iBinder = null;
        switch (i) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                parcel.enforceInterface("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
                qa a = m3644a(C0305o.m1507a(parcel.readStrongBinder()), C0302m.m1501a(parcel.readStrongBinder()), parcel.readInt() != 0 ? (WalletFragmentOptions) WalletFragmentOptions.CREATOR.createFromParcel(parcel) : null, kH.m3642a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                if (a != null) {
                    iBinder = a.asBinder();
                }
                parcel2.writeStrongBinder(iBinder);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
