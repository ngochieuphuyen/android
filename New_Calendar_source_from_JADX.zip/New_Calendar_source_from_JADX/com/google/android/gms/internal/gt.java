package com.google.android.gms.internal;

import android.util.Log;

public abstract class gt<TListener> {
    private TListener f2736a;
    private boolean f2737b;
    private /* synthetic */ gq f2738c;

    public gt(gq gqVar, TListener tListener) {
        this.f2738c = gqVar;
        this.f2736a = tListener;
        this.f2737b = false;
    }

    public final void m3304a() {
        synchronized (this) {
            Object obj = this.f2736a;
            if (this.f2737b) {
                Log.w("GmsClient", "Callback proxy " + this + " being reused. This is not safe.");
            }
        }
        if (obj != null) {
            try {
                m3305a(obj);
            } catch (RuntimeException e) {
                throw e;
            }
        }
        synchronized (this) {
            this.f2737b = true;
        }
        m3306b();
    }

    protected abstract void m3305a(TListener tListener);

    public final void m3306b() {
        m3307c();
        synchronized (this.f2738c.f1970e) {
            this.f2738c.f1970e.remove(this);
        }
    }

    public final void m3307c() {
        synchronized (this) {
            this.f2736a = null;
        }
    }
}
