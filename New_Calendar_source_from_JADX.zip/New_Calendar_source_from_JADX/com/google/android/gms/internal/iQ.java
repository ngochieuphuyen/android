package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.result.DataReadResult;

final class iQ extends hT<DataReadResult> {
    private /* synthetic */ DataReadRequest f2850a;

    iQ(iN iNVar, GoogleApiClient googleApiClient, DataReadRequest dataReadRequest) {
        this.f2850a = dataReadRequest;
        super(googleApiClient);
    }

    protected final /* synthetic */ Result m3378a(Status status) {
        return DataReadResult.m1798a(status, this.f2850a);
    }

    protected final /* synthetic */ void m3379a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3398a(this.f2850a, new iR(this, (byte) 0), luVar.getContext().getPackageName());
    }
}
