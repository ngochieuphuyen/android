package com.google.android.gms.internal;

import android.content.Context;
import android.support.v4.p000a.Security;
import com.google.android.gms.internal.fc.C0482a;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@ey
public final class dW extends eF {
    private final C0482a f2208a;
    private final fj f2209b;
    private final ex f2210c;
    private final fn f2211d;
    private final Object f2212e;
    private Future<ew> f2213f;

    public dW(Context context, la laVar, C0438B c0438b, ex exVar, C0482a c0482a) {
        this(exVar, c0482a, new fn(context, laVar, c0438b, new gn(), exVar));
    }

    private dW(ex exVar, C0482a c0482a, fn fnVar) {
        this.f2212e = new Object();
        this.f2210c = exVar;
        this.f2209b = exVar.f2449b;
        this.f2208a = c0482a;
        this.f2211d = fnVar;
    }

    public final void m2714a() {
        ew ewVar;
        int i = -2;
        try {
            synchronized (this.f2212e) {
                this.f2213f = eH.m2811a(this.f2211d);
            }
            ewVar = (ew) this.f2213f.get(60000, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            Security.m38W("Timed out waiting for native ad.");
            i = 2;
            ewVar = null;
        } catch (ExecutionException e2) {
            i = 0;
            ewVar = null;
        } catch (InterruptedException e3) {
            i = -1;
            ewVar = null;
        } catch (CancellationException e4) {
            i = -1;
            ewVar = null;
        }
        if (ewVar == null) {
            ewVar = new ew(this.f2210c.f2448a.f2603c, null, null, i, null, null, this.f2209b.f2630l, this.f2209b.f2629k, this.f2210c.f2448a.f2609i, false, null, null, null, null, null, this.f2209b.f2627i, this.f2210c.f2451d, this.f2209b.f2625g, this.f2210c.f2453f, this.f2209b.f2632n, this.f2209b.f2633o, this.f2210c.f2455h, null);
        }
        eW.f2340a.post(new dX(this, ewVar));
    }

    public final void m2715b() {
        synchronized (this.f2212e) {
            if (this.f2213f != null) {
                this.f2213f.cancel(true);
            }
        }
    }
}
