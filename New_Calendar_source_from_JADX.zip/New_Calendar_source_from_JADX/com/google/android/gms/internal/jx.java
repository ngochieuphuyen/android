package com.google.android.gms.internal;

import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.fitness.result.SessionStopResult;

final class jx extends ip {
    private final BaseImplementation$b<SessionStopResult> f2927a;

    private jx(BaseImplementation$b<SessionStopResult> baseImplementation$b) {
        this.f2927a = baseImplementation$b;
    }

    public final void m3623a(SessionStopResult sessionStopResult) {
        this.f2927a.m988b(sessionStopResult);
    }
}
