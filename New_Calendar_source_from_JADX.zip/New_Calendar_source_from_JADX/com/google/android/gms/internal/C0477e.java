package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import com.google.ads.C0051b;
import com.google.ads.C0052c;
import com.google.ads.C0053d;
import com.google.android.gms.ads.C0064c;
import com.google.android.gms.games.appcontent.AppContentUtils;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.io.UnsupportedEncodingException;
import java.lang.Character.UnicodeBlock;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

@ey
/* renamed from: com.google.android.gms.internal.e */
public class C0477e {
    private final C0487i f2264a;
    private final Runnable f2265b;
    private av f2266c;
    private boolean f2267d;
    private boolean f2268e;
    private long f2269f;

    public C0477e(la laVar) {
        this(laVar, new C0487i(eW.f2340a));
    }

    private C0477e(la laVar, C0487i c0487i) {
        this.f2267d = false;
        this.f2268e = false;
        this.f2269f = 0;
        this.f2264a = c0487i;
        this.f2265b = new C0484h(this, laVar);
    }

    public static int m2749a(C0051b c0051b) {
        switch (ca.f2070a[c0051b.ordinal()]) {
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                return 1;
            case Error.BAD_CVC /*3*/:
                return 2;
            case Error.BAD_CARD /*4*/:
                return 3;
            default:
                return 0;
        }
    }

    public static int m2750a(String str) {
        byte[] bytes;
        try {
            bytes = str.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            bytes = str.getBytes();
        }
        return Security.m42a(bytes, 0, bytes.length, 0);
    }

    static long m2751a(long j, int i) {
        return i == 0 ? 1 : i != 1 ? i % 2 == 0 ? C0477e.m2751a((j * j) % 1073807359, i / 2) % 1073807359 : ((C0477e.m2751a((j * j) % 1073807359, i / 2) % 1073807359) * j) % 1073807359 : j;
    }

    public static C0053d m2752a(ay ayVar) {
        int i = 0;
        C0053d[] c0053dArr = new C0053d[]{C0053d.f305a, C0053d.f306b, C0053d.f307c, C0053d.f308d, C0053d.f309e, C0053d.f310f};
        while (i < c0053dArr.length) {
            if (c0053dArr[i].m847a() == ayVar.f1885f && c0053dArr[i].m848b() == ayVar.f1882c) {
                return c0053dArr[i];
            }
            i++;
        }
        return new C0053d(C0064c.m893a(ayVar.f1885f, ayVar.f1882c, ayVar.f1881b));
    }

    public static gM m2754a(Object obj) {
        return new gM((byte) 0);
    }

    static String m2755a(String[] strArr, int i, int i2) {
        if (strArr.length < i + i2) {
            Security.m32T("Unable to construct shingle");
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        for (int i3 = i; i3 < (i + i2) - 1; i3++) {
            stringBuffer.append(strArr[i3]);
            stringBuffer.append(' ');
        }
        stringBuffer.append(strArr[(i + i2) - 1]);
        return stringBuffer.toString();
    }

    static void m2756a(int i, long j, String str, PriorityQueue<C0459U> priorityQueue) {
        C0459U c0459u = new C0459U(j, str);
        if ((priorityQueue.size() != i || ((C0459U) priorityQueue.peek()).f1616a <= c0459u.f1616a) && !priorityQueue.contains(c0459u)) {
            priorityQueue.add(c0459u);
            if (priorityQueue.size() > i) {
                priorityQueue.poll();
            }
        }
    }

    public static void m2757a(String[] strArr, int i, int i2, PriorityQueue<C0459U> priorityQueue) {
        int i3;
        long a = (((long) C0477e.m2750a(strArr[0])) + 2147483647L) % 1073807359;
        for (i3 = 1; i3 < i2 + 0; i3++) {
            a = (((a * 16785407) % 1073807359) + ((((long) C0477e.m2750a(strArr[i3])) + 2147483647L) % 1073807359)) % 1073807359;
        }
        C0477e.m2756a(i, a, C0477e.m2755a(strArr, 0, i2), (PriorityQueue) priorityQueue);
        long a2 = C0477e.m2751a(16785407, i2 - 1);
        for (i3 = 1; i3 < (strArr.length - i2) + 1; i3++) {
            a += 1073807359;
            a = (((((a - ((((((long) C0477e.m2750a(strArr[i3 - 1])) + 2147483647L) % 1073807359) * a2) % 1073807359)) % 1073807359) * 16785407) % 1073807359) + ((((long) C0477e.m2750a(strArr[(i3 + i2) - 1])) + 2147483647L) % 1073807359)) % 1073807359;
            C0477e.m2756a(i, a, C0477e.m2755a(strArr, i3, i2), (PriorityQueue) priorityQueue);
        }
    }

    public static boolean m2759a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    public static AppContentUtils m2760b(av avVar) {
        C0052c c0052c;
        Set hashSet = avVar.f1868e != null ? new HashSet(avVar.f1868e) : null;
        Date date = new Date(avVar.f1865b);
        switch (avVar.f1867d) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                c0052c = C0052c.MALE;
                break;
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                c0052c = C0052c.FEMALE;
                break;
            default:
                c0052c = C0052c.UNKNOWN;
                break;
        }
        return new AppContentUtils(date, c0052c, hashSet, avVar.f1869f, avVar.f1874k);
    }

    public static String[] m2761b(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        char[] toCharArray = str.toCharArray();
        int length = str.length();
        Object obj = null;
        int i = 0;
        int i2 = 0;
        while (i2 < length) {
            Object obj2;
            int i3;
            Object obj3;
            Object obj4;
            int codePointAt = Character.codePointAt(toCharArray, i2);
            int charCount = Character.charCount(codePointAt);
            if (Character.isLetter(codePointAt)) {
                UnicodeBlock of = UnicodeBlock.of(codePointAt);
                obj2 = (of == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || of == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || of == UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B || of == UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION || of == UnicodeBlock.CJK_RADICALS_SUPPLEMENT || of == UnicodeBlock.CJK_COMPATIBILITY || of == UnicodeBlock.CJK_COMPATIBILITY_FORMS || of == UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS || of == UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT || of == UnicodeBlock.BOPOMOFO || of == UnicodeBlock.HIRAGANA || of == UnicodeBlock.KATAKANA || of == UnicodeBlock.HANGUL_SYLLABLES || of == UnicodeBlock.HANGUL_JAMO) ? 1 : null;
                if (obj2 != null) {
                    obj2 = 1;
                    if (obj2 != null) {
                        if (obj != null) {
                            arrayList.add(new String(toCharArray, i, i2 - i));
                        }
                        arrayList.add(new String(toCharArray, i2, charCount));
                        i3 = i;
                        obj3 = null;
                    } else if (Character.isLetterOrDigit(codePointAt)) {
                        if (obj == null) {
                            i = i2;
                        }
                        i3 = i;
                        i = 1;
                    } else if (obj == null) {
                        arrayList.add(new String(toCharArray, i, i2 - i));
                        i3 = i;
                        obj3 = null;
                    } else {
                        obj4 = obj;
                        i3 = i;
                        obj3 = obj4;
                    }
                    i2 += charCount;
                    obj4 = obj3;
                    i = i3;
                    obj = obj4;
                }
            }
            obj2 = null;
            if (obj2 != null) {
                if (obj != null) {
                    arrayList.add(new String(toCharArray, i, i2 - i));
                }
                arrayList.add(new String(toCharArray, i2, charCount));
                i3 = i;
                obj3 = null;
            } else if (Character.isLetterOrDigit(codePointAt)) {
                if (obj == null) {
                    i = i2;
                }
                i3 = i;
                i = 1;
            } else if (obj == null) {
                obj4 = obj;
                i3 = i;
                obj3 = obj4;
            } else {
                arrayList.add(new String(toCharArray, i, i2 - i));
                i3 = i;
                obj3 = null;
            }
            i2 += charCount;
            obj4 = obj3;
            i = i3;
            obj = obj4;
        }
        if (obj != null) {
            arrayList.add(new String(toCharArray, i, i2 - i));
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    public final void m2762a() {
        this.f2267d = false;
        this.f2264a.m3356a(this.f2265b);
    }

    public final void m2763a(av avVar) {
        m2764a(avVar, 60000);
    }

    public final void m2764a(av avVar, long j) {
        if (this.f2267d) {
            Security.m38W("An ad refresh is already scheduled.");
            return;
        }
        this.f2266c = avVar;
        this.f2267d = true;
        this.f2269f = j;
        if (!this.f2268e) {
            Security.m34U("Scheduling ad refresh " + j + " milliseconds from now.");
            this.f2264a.m3357a(this.f2265b, j);
        }
    }

    public final void m2765b() {
        this.f2268e = true;
        if (this.f2267d) {
            this.f2264a.m3356a(this.f2265b);
        }
    }

    public final void m2766c() {
        this.f2268e = false;
        if (this.f2267d) {
            this.f2267d = false;
            m2764a(this.f2266c, this.f2269f);
        }
    }

    public final boolean m2767d() {
        return this.f2267d;
    }
}
