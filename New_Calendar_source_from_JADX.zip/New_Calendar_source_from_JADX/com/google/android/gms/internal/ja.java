package com.google.android.gms.internal;

import com.google.android.gms.fitness.data.C0331s;
import com.google.android.gms.fitness.request.OnDataPointListener;
import com.google.android.gms.internal.mm.C0492b;

final class ja implements C0492b {
    private /* synthetic */ OnDataPointListener f2894a;

    ja(mm mmVar, OnDataPointListener onDataPointListener) {
        this.f2894a = onDataPointListener;
    }

    public final void jO() {
        C0331s.m1643a().m1646c(this.f2894a);
    }
}
