package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class hf implements SafeParcelable {
    public static final fv CREATOR;
    final int f2803a;
    final String f2804b;
    final String f2805c;
    final String f2806d;

    static {
        CREATOR = new fv();
    }

    hf(int i, String str, String str2, String str3) {
        this.f2803a = i;
        this.f2804b = str;
        this.f2805c = str2;
        this.f2806d = str3;
    }

    public int describeContents() {
        fv fvVar = CREATOR;
        return 0;
    }

    public String toString() {
        return String.format("DocumentId[packageName=%s, corpusName=%s, uri=%s]", new Object[]{this.f2804b, this.f2805c, this.f2806d});
    }

    public void writeToParcel(Parcel parcel, int i) {
        fv fvVar = CREATOR;
        fv.m3133a(this, parcel);
    }
}
