package com.google.android.gms.internal;

import org.json.JSONObject;

/* renamed from: com.google.android.gms.internal.F */
final class C0443F implements Runnable {
    private /* synthetic */ String f1564a;
    private /* synthetic */ JSONObject f1565b;
    private /* synthetic */ C0442E f1566c;

    C0443F(C0442E c0442e, String str, JSONObject jSONObject) {
        this.f1566c = c0442e;
        this.f1564a = str;
        this.f1565b = jSONObject;
    }

    public final void run() {
        this.f1566c.f1563a.m2879a(this.f1564a, this.f1565b);
    }
}
