package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.request.C0376v;

final class iO extends hV {
    private /* synthetic */ DataSet f2848a;

    iO(iN iNVar, GoogleApiClient googleApiClient, DataSet dataSet) {
        this.f2848a = dataSet;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3376a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3410a(new C0376v().m1787a(this.f2848a).m1786a(), new hU(this), luVar.getContext().getPackageName());
    }
}
