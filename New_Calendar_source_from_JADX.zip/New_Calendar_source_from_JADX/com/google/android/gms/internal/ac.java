package com.google.android.gms.internal;

public interface ac {
    void m2370a(C0503l c0503l, boolean z);
}
