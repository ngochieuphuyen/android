package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.internal.pi.C0517h;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.HashSet;
import java.util.Set;

public final class kA implements Creator<C0517h> {
    static void m3632a(C0517h c0517h, Parcel parcel) {
        int H = Security.m15H(parcel);
        Set set = c0517h.f3271a;
        if (set.contains(Integer.valueOf(1))) {
            Security.m118c(parcel, 1, c0517h.f3272b);
        }
        if (set.contains(Integer.valueOf(3))) {
            Security.m118c(parcel, 3, C0517h.m3953d());
        }
        if (set.contains(Integer.valueOf(4))) {
            Security.m69a(parcel, 4, c0517h.f3275e, true);
        }
        if (set.contains(Integer.valueOf(5))) {
            Security.m69a(parcel, 5, c0517h.f3273c, true);
        }
        if (set.contains(Integer.valueOf(6))) {
            Security.m118c(parcel, 6, c0517h.f3274d);
        }
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        String str = null;
        int i = 0;
        int G = Security.m12G(parcel);
        Set hashSet = new HashSet();
        String str2 = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Error.BAD_CVC /*3*/:
                    Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case Error.BAD_CARD /*4*/:
                    str = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(4));
                    break;
                case Error.DECLINED /*5*/:
                    str2 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    i = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(6));
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new C0517h(hashSet, i2, str2, i, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0517h[i];
    }
}
