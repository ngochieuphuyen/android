package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface kd {
    PendingResult<Status> m3262c(GoogleApiClient googleApiClient);
}
