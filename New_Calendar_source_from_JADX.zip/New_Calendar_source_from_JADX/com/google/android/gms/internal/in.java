package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.fitness.result.SessionReadResult;

final class in implements mb {
    private IBinder f2870a;

    in(IBinder iBinder) {
        this.f2870a = iBinder;
    }

    public final void m3453a(SessionReadResult sessionReadResult) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.ISessionReadCallback");
            if (sessionReadResult != null) {
                obtain.writeInt(1);
                sessionReadResult.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f2870a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f2870a;
    }
}
