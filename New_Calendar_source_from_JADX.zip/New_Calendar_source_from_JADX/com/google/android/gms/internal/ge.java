package com.google.android.gms.internal;

import org.json.JSONObject;

public final class ge {
    private static final gb f2709c;
    private static Object f2710d;
    private long f2711a;
    private iv f2712b;

    static {
        f2709c = new gb("RequestTracker");
        f2710d = new Object();
    }

    public final boolean m3278a() {
        boolean z;
        synchronized (f2710d) {
            z = this.f2711a != -1;
        }
        return z;
    }

    public final boolean m3279a(long j) {
        boolean z;
        synchronized (f2710d) {
            z = this.f2711a != -1 && this.f2711a == j;
        }
        return z;
    }

    public final boolean m3280a(long j, int i) {
        return m3281a(j, 0, null);
    }

    public final boolean m3281a(long j, int i, JSONObject jSONObject) {
        boolean z = true;
        synchronized (f2710d) {
            if (this.f2711a == -1 || this.f2711a != j) {
                z = false;
            } else {
                f2709c.m3271a("request %d completed", Long.valueOf(this.f2711a));
                this.f2711a = -1;
                this.f2712b = null;
            }
        }
        return z;
    }
}
