package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.data.BleDevice;
import com.google.android.gms.fitness.request.C0357b;

final class iE extends hV {
    private /* synthetic */ BleDevice f2842a;

    iE(iA iAVar, GoogleApiClient googleApiClient, BleDevice bleDevice) {
        this.f2842a = bleDevice;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3361a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3409a(new C0357b(this.f2842a), new hU(this), luVar.getContext().getPackageName());
    }
}
