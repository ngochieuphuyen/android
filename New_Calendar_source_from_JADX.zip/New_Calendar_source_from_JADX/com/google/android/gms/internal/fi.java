package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.webkit.JsPromptResult;
import android.widget.EditText;

final class fi implements OnClickListener {
    private /* synthetic */ JsPromptResult f2617a;
    private /* synthetic */ EditText f2618b;

    fi(JsPromptResult jsPromptResult, EditText editText) {
        this.f2617a = jsPromptResult;
        this.f2618b = editText;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f2617a.confirm(this.f2618b.getText().toString());
    }
}
