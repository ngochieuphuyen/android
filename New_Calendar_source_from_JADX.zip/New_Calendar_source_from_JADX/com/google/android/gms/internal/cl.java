package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import org.json.JSONObject;

final class cl implements OnClickListener {
    private /* synthetic */ cj f2097a;

    cl(cj cjVar) {
        this.f2097a = cjVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f2097a.f2091a.m2882b("onStorePictureCanceled", new JSONObject());
    }
}
