package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.C0126a;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.internal.fe.C0474a;

@ey
public final class dP extends dN implements ConnectionCallbacks, OnConnectionFailedListener {
    private final C0474a f2189a;
    private final dQ f2190b;
    private final Object f2191c;

    public dP(Context context, fh fhVar, C0474a c0474a) {
        super(fhVar, c0474a);
        this.f2191c = new Object();
        this.f2189a = c0474a;
        this.f2190b = new dQ(context, this, this, fhVar.f2611k.f2734d);
        this.f2190b.connect();
    }

    public final void m2699c() {
        synchronized (this.f2191c) {
            if (this.f2190b.isConnected() || this.f2190b.m2534k()) {
                this.f2190b.disconnect();
            }
        }
    }

    public final fl m2700d() {
        fl c;
        synchronized (this.f2191c) {
            try {
                c = this.f2190b.m2705c();
            } catch (IllegalStateException e) {
                c = null;
                return c;
            } catch (DeadObjectException e2) {
                c = null;
                return c;
            }
        }
        return c;
    }

    public final void onConnected(Bundle bundle) {
        m2593e();
    }

    public final void onConnectionFailed(C0126a c0126a) {
        this.f2189a.m2660a(new fj(0));
    }

    public final void onConnectionSuspended(int i) {
        Security.m30S("Disconnected from remote ad request service.");
    }
}
