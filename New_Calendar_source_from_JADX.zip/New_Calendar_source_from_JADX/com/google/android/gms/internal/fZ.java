package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.cast.LaunchOptions;

final class fZ implements iq {
    private IBinder f2593a;

    fZ(IBinder iBinder) {
        this.f2593a = iBinder;
    }

    public final void m3092a(double d, double d2, boolean z) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeDouble(d);
            obtain.writeDouble(d2);
            if (!z) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f2593a.transact(7, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3093a(String str, LaunchOptions launchOptions) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            if (launchOptions != null) {
                obtain.writeInt(1);
                launchOptions.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f2593a.transact(13, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3094a(String str, String str2, long j) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            obtain.writeLong(j);
            this.f2593a.transact(9, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3095a(String str, byte[] bArr, long j) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeByteArray(bArr);
            obtain.writeLong(j);
            this.f2593a.transact(10, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3096a(boolean z, double d, boolean z2) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeInt(z ? 1 : 0);
            obtain.writeDouble(d);
            if (!z2) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f2593a.transact(8, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void aH(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f2593a.transact(5, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void aI(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f2593a.transact(11, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void aJ(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f2593a.transact(12, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f2593a;
    }

    public final void disconnect() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f2593a.transact(1, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void fY() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f2593a.transact(6, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3097g(String str, boolean z) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            if (!z) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f2593a.transact(2, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void gl() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f2593a.transact(4, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m3098k(String str, String str2) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            this.f2593a.transact(3, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }
}
