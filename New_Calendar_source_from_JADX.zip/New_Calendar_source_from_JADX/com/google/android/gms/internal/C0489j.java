package com.google.android.gms.internal;

import org.json.JSONObject;

@ey
/* renamed from: com.google.android.gms.internal.j */
public final class C0489j {
    private final String f2881a;
    private final JSONObject f2882b;
    private final String f2883c;
    private final String f2884d;

    public C0489j(String str, gs gsVar, String str2, JSONObject jSONObject) {
        this.f2884d = gsVar.f2732b;
        this.f2882b = jSONObject;
        this.f2883c = str;
        this.f2881a = str2;
    }

    public final String m3471a() {
        return this.f2881a;
    }

    public final String m3472b() {
        return this.f2884d;
    }

    public final JSONObject m3473c() {
        return this.f2882b;
    }

    public final String m3474d() {
        return this.f2883c;
    }
}
