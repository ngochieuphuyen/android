package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;

@ey
public final class bM implements MediationBannerListener, MediationInterstitialListener {
    private final da f1927a;

    public bM(da daVar) {
        this.f1927a = daVar;
    }

    public final void onAdClicked(MediationBannerAdapter mediationBannerAdapter) {
        LunarUtil.m190b("onAdClicked must be called on the main UI thread.");
        Security.m30S("Adapter called onAdClicked.");
        try {
            this.f1927a.onAdClicked();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdClicked.", e);
        }
    }

    public final void onAdClicked(MediationInterstitialAdapter mediationInterstitialAdapter) {
        LunarUtil.m190b("onAdClicked must be called on the main UI thread.");
        Security.m30S("Adapter called onAdClicked.");
        try {
            this.f1927a.onAdClicked();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdClicked.", e);
        }
    }

    public final void onAdClosed(MediationBannerAdapter mediationBannerAdapter) {
        LunarUtil.m190b("onAdClosed must be called on the main UI thread.");
        Security.m30S("Adapter called onAdClosed.");
        try {
            this.f1927a.onAdClosed();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdClosed.", e);
        }
    }

    public final void onAdClosed(MediationInterstitialAdapter mediationInterstitialAdapter) {
        LunarUtil.m190b("onAdClosed must be called on the main UI thread.");
        Security.m30S("Adapter called onAdClosed.");
        try {
            this.f1927a.onAdClosed();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdClosed.", e);
        }
    }

    public final void onAdFailedToLoad(MediationBannerAdapter mediationBannerAdapter, int i) {
        LunarUtil.m190b("onAdFailedToLoad must be called on the main UI thread.");
        Security.m30S("Adapter called onAdFailedToLoad with error. " + i);
        try {
            this.f1927a.onAdFailedToLoad(i);
        } catch (Throwable e) {
            Security.m126d("Could not call onAdFailedToLoad.", e);
        }
    }

    public final void onAdFailedToLoad(MediationInterstitialAdapter mediationInterstitialAdapter, int i) {
        LunarUtil.m190b("onAdFailedToLoad must be called on the main UI thread.");
        Security.m30S("Adapter called onAdFailedToLoad with error " + i + ".");
        try {
            this.f1927a.onAdFailedToLoad(i);
        } catch (Throwable e) {
            Security.m126d("Could not call onAdFailedToLoad.", e);
        }
    }

    public final void onAdLeftApplication(MediationBannerAdapter mediationBannerAdapter) {
        LunarUtil.m190b("onAdLeftApplication must be called on the main UI thread.");
        Security.m30S("Adapter called onAdLeftApplication.");
        try {
            this.f1927a.onAdLeftApplication();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdLeftApplication.", e);
        }
    }

    public final void onAdLeftApplication(MediationInterstitialAdapter mediationInterstitialAdapter) {
        LunarUtil.m190b("onAdLeftApplication must be called on the main UI thread.");
        Security.m30S("Adapter called onAdLeftApplication.");
        try {
            this.f1927a.onAdLeftApplication();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdLeftApplication.", e);
        }
    }

    public final void onAdLoaded(MediationBannerAdapter mediationBannerAdapter) {
        LunarUtil.m190b("onAdLoaded must be called on the main UI thread.");
        Security.m30S("Adapter called onAdLoaded.");
        try {
            this.f1927a.onAdLoaded();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdLoaded.", e);
        }
    }

    public final void onAdLoaded(MediationInterstitialAdapter mediationInterstitialAdapter) {
        LunarUtil.m190b("onAdLoaded must be called on the main UI thread.");
        Security.m30S("Adapter called onAdLoaded.");
        try {
            this.f1927a.onAdLoaded();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdLoaded.", e);
        }
    }

    public final void onAdOpened(MediationBannerAdapter mediationBannerAdapter) {
        LunarUtil.m190b("onAdOpened must be called on the main UI thread.");
        Security.m30S("Adapter called onAdOpened.");
        try {
            this.f1927a.onAdOpened();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdOpened.", e);
        }
    }

    public final void onAdOpened(MediationInterstitialAdapter mediationInterstitialAdapter) {
        LunarUtil.m190b("onAdOpened must be called on the main UI thread.");
        Security.m30S("Adapter called onAdOpened.");
        try {
            this.f1927a.onAdOpened();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdOpened.", e);
        }
    }
}
