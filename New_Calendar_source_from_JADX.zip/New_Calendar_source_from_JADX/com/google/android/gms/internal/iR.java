package com.google.android.gms.internal;

import android.util.Log;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.fitness.result.DataReadResult;

final class iR extends hX {
    private final BaseImplementation$b<DataReadResult> f2851a;
    private int f2852b;
    private DataReadResult f2853c;

    private iR(BaseImplementation$b<DataReadResult> baseImplementation$b) {
        this.f2852b = 0;
        this.f2853c = null;
        this.f2851a = baseImplementation$b;
    }

    public final void m3380a(DataReadResult dataReadResult) {
        synchronized (this) {
            Log.v("Fitness", "Received batch result");
            if (this.f2853c == null) {
                this.f2853c = dataReadResult;
            } else {
                this.f2853c.m1801a(dataReadResult);
            }
            this.f2852b++;
            if (this.f2852b == this.f2853c.m1800a()) {
                this.f2851a.m988b(this.f2853c);
            }
        }
    }
}
