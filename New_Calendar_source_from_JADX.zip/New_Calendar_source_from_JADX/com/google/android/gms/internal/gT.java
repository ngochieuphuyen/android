package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;

final class gT extends gW {
    gT(gS gSVar, GoogleApiClient googleApiClient) {
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3265a(C0127a c0127a) {
        ((ki) ((gX) c0127a).m2536m()).m3328a(new gU(this));
    }
}
