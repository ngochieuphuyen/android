package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.SearchableOrderedMetadataField;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.metadata.internal.C0237e;
import java.util.Date;

public final class hP extends C0237e implements SearchableOrderedMetadataField<Date>, SortableMetadataField<Date> {
    public hP(String str, int i) {
        super(str, 4100000);
    }
}
