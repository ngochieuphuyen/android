package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

public final class fD implements Creator<hp> {
    static void m2956a(hp hpVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m69a(parcel, 1, hpVar.f2822b, false);
        Security.m118c(parcel, 1000, hpVar.f2821a);
        Security.m69a(parcel, 2, hpVar.f2823c, false);
        Security.m73a(parcel, 3, hpVar.f2824d);
        Security.m118c(parcel, 4, hpVar.f2825e);
        Security.m73a(parcel, 5, hpVar.f2826f);
        Security.m69a(parcel, 6, hpVar.f2827g, false);
        Security.m76a(parcel, 7, hpVar.f2828h, i, false);
        Security.m75a(parcel, 8, hpVar.f2829i, false);
        Security.m69a(parcel, 11, hpVar.f2830j, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        boolean z = false;
        String str = null;
        int G = Security.m12G(parcel);
        int i = 1;
        int[] iArr = null;
        hj[] hjVarArr = null;
        String str2 = null;
        boolean z2 = false;
        String str3 = null;
        String str4 = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    z2 = Security.m121c(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    z = Security.m121c(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    hjVarArr = (hj[]) Security.m114b(parcel, readInt, hj.CREATOR);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    iArr = Security.m156u(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_checkable /*11*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case 1000:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new hp(i2, str4, str3, z2, i, z, str2, hjVarArr, iArr, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new hp[i];
    }
}
