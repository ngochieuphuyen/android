package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.HashSet;
import java.util.Set;

public final class kg implements Creator<pf> {
    public static pf m3742a(Parcel parcel) {
        String str = null;
        int G = Security.m12G(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        pd pdVar = null;
        String str2 = null;
        pd pdVar2 = null;
        String str3 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            pd pdVar3;
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str3 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CARD /*4*/:
                    pdVar3 = (pd) Security.m47a(parcel, readInt, pd.CREATOR);
                    hashSet.add(Integer.valueOf(4));
                    pdVar2 = pdVar3;
                    break;
                case Error.DECLINED /*5*/:
                    str2 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    pdVar3 = (pd) Security.m47a(parcel, readInt, pd.CREATOR);
                    hashSet.add(Integer.valueOf(6));
                    pdVar = pdVar3;
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(7));
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pf(hashSet, i, str3, pdVar2, str2, pdVar, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    static void m3743a(pf pfVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Set set = pfVar.f3211a;
        if (set.contains(Integer.valueOf(1))) {
            Security.m118c(parcel, 1, pfVar.f3212b);
        }
        if (set.contains(Integer.valueOf(2))) {
            Security.m69a(parcel, 2, pfVar.f3213c, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            Security.m65a(parcel, 4, pfVar.f3214d, i, true);
        }
        if (set.contains(Integer.valueOf(5))) {
            Security.m69a(parcel, 5, pfVar.f3215e, true);
        }
        if (set.contains(Integer.valueOf(6))) {
            Security.m65a(parcel, 6, pfVar.f3216f, i, true);
        }
        if (set.contains(Integer.valueOf(7))) {
            Security.m69a(parcel, 7, pfVar.f3217g, true);
        }
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3742a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new pf[i];
    }
}
