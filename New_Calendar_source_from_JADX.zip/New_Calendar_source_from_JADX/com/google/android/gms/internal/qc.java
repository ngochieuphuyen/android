package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.wallet.C0707d;
import com.google.android.gms.wallet.FullWalletRequest;
import com.google.android.gms.wallet.MaskedWalletRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest;

public interface qc extends IInterface {
    void m3963a(Bundle bundle, qf qfVar);

    void m3964a(pw pwVar, Bundle bundle, qf qfVar);

    void m3965a(FullWalletRequest fullWalletRequest, Bundle bundle, qf qfVar);

    void m3966a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, qe qeVar);

    void m3967a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, qf qfVar);

    void m3968a(NotifyTransactionStatusRequest notifyTransactionStatusRequest, Bundle bundle);

    void m3969a(C0707d c0707d, Bundle bundle, qf qfVar);

    void m3970a(String str, String str2, Bundle bundle, qf qfVar);

    void m3971r(Bundle bundle);

    void m3972s(Bundle bundle);
}
