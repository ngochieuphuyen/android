package com.google.android.gms.internal;

public abstract class fO {
    protected final gb f2549a;

    public void m3018a(String str) {
    }
}
