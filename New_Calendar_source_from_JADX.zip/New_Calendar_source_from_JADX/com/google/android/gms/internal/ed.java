package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import android.support.v4.p000a.Security;
import android.text.TextUtils;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@ey
public final class ed extends dU {
    private static final Object f2360a;
    private static ed f2361b;
    private final Context f2362c;
    private final fw f2363d;
    private final cn f2364e;
    private final at f2365f;

    static {
        f2360a = new Object();
    }

    private ed(Context context, at atVar, cn cnVar, fw fwVar) {
        this.f2362c = context;
        this.f2363d = fwVar;
        this.f2364e = cnVar;
        this.f2365f = atVar;
    }

    public static ed m2903a(Context context, at atVar, cn cnVar, fw fwVar) {
        ed edVar;
        synchronized (f2360a) {
            if (f2361b == null) {
                f2361b = new ed(context.getApplicationContext(), atVar, cnVar, fwVar);
            }
            edVar = f2361b;
        }
        return edVar;
    }

    private static fj m2904a(Context context, at atVar, cn cnVar, fw fwVar, fh fhVar) {
        Security.m30S("Starting ad request from service.");
        cnVar.init();
        eu euVar = new eu(context);
        if (euVar.f2415l == -1) {
            Security.m30S("Device is offline.");
            return new fj(2);
        }
        String string;
        ei eiVar = new ei(fhVar.f2606f.packageName);
        if (fhVar.f2603c.f1866c != null) {
            string = fhVar.f2603c.f1866c.getString("_ad");
            if (string != null) {
                return eh.m2909a(context, fhVar, string);
            }
        }
        cnVar.m2543a(250);
        String a = atVar.m2439a();
        String a2 = eh.m2912a(fhVar, euVar, atVar.m2440b(), atVar.m2441c(), atVar.m2442d());
        if (a2 == null) {
            return new fj(0);
        }
        eW.f2340a.post(new ee(context, fhVar, eiVar, new eg(a2), a));
        fj fjVar;
        try {
            et etVar = (et) eiVar.m2916a().get(10, TimeUnit.SECONDS);
            if (etVar == null) {
                fjVar = new fj(0);
                return fjVar;
            } else if (etVar.m2929a() != -2) {
                fj fjVar2 = new fj(etVar.m2929a());
                eW.f2340a.post(new ef(eiVar));
                return fjVar2;
            } else {
                string = null;
                if (etVar.m2935f()) {
                    string = fwVar.m2938K(fhVar.f2607g.packageName);
                }
                fjVar = m2905a(context, fhVar.f2611k.f2732b, etVar.m2933d(), string, etVar);
                eW.f2340a.post(new ef(eiVar));
                return fjVar;
            }
        } catch (Exception e) {
            fjVar = new fj(0);
            return fjVar;
        } finally {
            eW.f2340a.post(new ef(eiVar));
        }
    }

    public static fj m2905a(Context context, String str, String str2, String str3, et etVar) {
        HttpURLConnection httpURLConnection;
        try {
            int responseCode;
            fj fjVar;
            es esVar = new es();
            Security.m30S("AdRequestServiceImpl: Sending request: " + str2);
            URL url = new URL(str2);
            long elapsedRealtime = SystemClock.elapsedRealtime();
            URL url2 = url;
            int i = 0;
            while (true) {
                httpURLConnection = (HttpURLConnection) url2.openConnection();
                eL.m2823a(context, str, false, httpURLConnection);
                if (!TextUtils.isEmpty(str3)) {
                    httpURLConnection.addRequestProperty("x-afma-drt-cookie", str3);
                }
                if (!(etVar == null || TextUtils.isEmpty(etVar.m2932c()))) {
                    httpURLConnection.setDoOutput(true);
                    byte[] bytes = etVar.m2932c().getBytes();
                    httpURLConnection.setFixedLengthStreamingMode(bytes.length);
                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
                    bufferedOutputStream.write(bytes);
                    bufferedOutputStream.close();
                }
                responseCode = httpURLConnection.getResponseCode();
                Map headerFields = httpURLConnection.getHeaderFields();
                if (responseCode < 200 || responseCode >= 300) {
                    m2906a(url2.toString(), headerFields, null, responseCode);
                    if (responseCode < 300 || responseCode >= 400) {
                        break;
                    }
                    Object headerField = httpURLConnection.getHeaderField("Location");
                    if (TextUtils.isEmpty(headerField)) {
                        Security.m38W("No location header to follow redirect.");
                        fjVar = new fj(0);
                        httpURLConnection.disconnect();
                        return fjVar;
                    }
                    url2 = new URL(headerField);
                    i++;
                    if (i > 5) {
                        Security.m38W("Too many redirects.");
                        fjVar = new fj(0);
                        httpURLConnection.disconnect();
                        return fjVar;
                    }
                    esVar.m2927a(headerFields);
                    httpURLConnection.disconnect();
                } else {
                    String url3 = url2.toString();
                    String a = eL.m2813a(new InputStreamReader(httpURLConnection.getInputStream()));
                    m2906a(url3, headerFields, a, responseCode);
                    esVar.m2926a(url3, headerFields, a);
                    fjVar = esVar.m2925a(elapsedRealtime);
                    httpURLConnection.disconnect();
                    return fjVar;
                }
            }
            Security.m38W("Received error HTTP response code: " + responseCode);
            fjVar = new fj(0);
            httpURLConnection.disconnect();
            return fjVar;
        } catch (IOException e) {
            Security.m38W("Error while connecting to ad server: " + e.getMessage());
            return new fj(2);
        } catch (Throwable th) {
            httpURLConnection.disconnect();
        }
    }

    private static void m2906a(String str, Map<String, List<String>> map, String str2, int i) {
        if (Security.m157v(2)) {
            Security.m36V("Http Response: {\n  URL:\n    " + str + "\n  Headers:");
            if (map != null) {
                for (String str3 : map.keySet()) {
                    Security.m36V("    " + str3 + ":");
                    for (String str32 : (List) map.get(str32)) {
                        Security.m36V("      " + str32);
                    }
                }
            }
            Security.m36V("  Body:");
            if (str2 != null) {
                for (int i2 = 0; i2 < Math.min(str2.length(), 100000); i2 += 1000) {
                    Security.m36V(str2.substring(i2, Math.min(str2.length(), i2 + 1000)));
                }
            } else {
                Security.m36V("    null");
            }
            Security.m36V("  Response Code:\n    " + i + "\n}");
        }
    }

    public final fj m2907b(fh fhVar) {
        return m2904a(this.f2362c, this.f2365f, this.f2364e, this.f2363d, fhVar);
    }
}
