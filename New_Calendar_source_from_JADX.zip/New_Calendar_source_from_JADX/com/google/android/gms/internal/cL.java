package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.dynamic.C0295d;

final class cL implements dy {
    private IBinder f2026a;

    cL(IBinder iBinder) {
        this.f2026a = iBinder;
    }

    public final IBinder asBinder() {
        return this.f2026a;
    }

    public final IBinder m2579b(C0295d c0295d) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
            obtain.writeStrongBinder(c0295d != null ? c0295d.asBinder() : null);
            this.f2026a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            IBinder readStrongBinder = obtain2.readStrongBinder();
            return readStrongBinder;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
