package com.google.android.gms.internal;

final class dI implements Runnable {
    private /* synthetic */ dH f2179a;

    dI(dH dHVar) {
        this.f2179a = dHVar;
    }

    public final void run() {
        this.f2179a.m2690b();
    }
}
