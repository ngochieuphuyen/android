package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.internal.if */
public class C0488if implements SafeParcelable {
    public static final fM CREATOR;
    final int f2862a;
    final int f2863b;
    final Bundle f2864c;
    final byte[] f2865d;

    static {
        CREATOR = new fM();
    }

    public C0488if(int i, int i2, Bundle bundle, byte[] bArr) {
        this.f2862a = i;
        this.f2863b = i2;
        this.f2864c = bundle;
        this.f2865d = bArr;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        fM.m3016a(this, parcel);
    }
}
