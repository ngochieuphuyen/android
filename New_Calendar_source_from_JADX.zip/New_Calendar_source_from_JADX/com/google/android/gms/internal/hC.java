package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;

public final class hC extends hK implements SearchableMetadataField<AppVisibleCustomProperties> {
    public hC(int i) {
        super(5000000);
    }
}
