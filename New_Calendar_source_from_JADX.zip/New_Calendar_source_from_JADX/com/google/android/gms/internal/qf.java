package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wallet.FullWallet;
import com.google.android.gms.wallet.MaskedWallet;

public interface qf extends IInterface {
    void m3974a(int i, FullWallet fullWallet, Bundle bundle);

    void m3975a(int i, MaskedWallet maskedWallet, Bundle bundle);

    void m3976a(int i, boolean z, Bundle bundle);

    void m3977a(Status status, py pyVar, Bundle bundle);

    void m3978i(int i, Bundle bundle);
}
