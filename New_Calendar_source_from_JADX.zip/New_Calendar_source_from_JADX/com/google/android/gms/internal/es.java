package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@ey
public final class es {
    private String f2382a;
    private String f2383b;
    private String f2384c;
    private List<String> f2385d;
    private String f2386e;
    private String f2387f;
    private List<String> f2388g;
    private long f2389h;
    private boolean f2390i;
    private List<String> f2391j;
    private long f2392k;
    private int f2393l;
    private boolean f2394m;
    private boolean f2395n;
    private boolean f2396o;
    private boolean f2397p;

    public es() {
        this.f2389h = -1;
        this.f2390i = false;
        this.f2392k = -1;
        this.f2393l = -1;
        this.f2394m = false;
        this.f2395n = false;
        this.f2396o = false;
        this.f2397p = true;
    }

    private static String m2921a(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty()) ? null : (String) list.get(0);
    }

    private static long m2922b(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (!(list == null || list.isEmpty())) {
            String str2 = (String) list.get(0);
            try {
                return (long) (Float.parseFloat(str2) * 1000.0f);
            } catch (NumberFormatException e) {
                Security.m38W("Could not parse float from " + str + " header: " + str2);
            }
        }
        return -1;
    }

    private static List<String> m2923c(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (!(list == null || list.isEmpty())) {
            String str2 = (String) list.get(0);
            if (str2 != null) {
                return Arrays.asList(str2.trim().split("\\s+"));
            }
        }
        return null;
    }

    private static boolean m2924d(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty() || !Boolean.valueOf((String) list.get(0)).booleanValue()) ? false : true;
    }

    public final fj m2925a(long j) {
        return new fj(this.f2383b, this.f2384c, this.f2385d, this.f2388g, this.f2389h, this.f2390i, -1, this.f2391j, this.f2392k, this.f2393l, this.f2382a, j, this.f2386e, this.f2387f, this.f2394m, this.f2395n, this.f2396o, this.f2397p);
    }

    public final void m2926a(String str, Map<String, List<String>> map, String str2) {
        this.f2383b = str;
        this.f2384c = str2;
        m2927a((Map) map);
    }

    public final void m2927a(Map<String, List<String>> map) {
        this.f2382a = m2921a(map, "X-Afma-Ad-Size");
        List c = m2923c(map, "X-Afma-Click-Tracking-Urls");
        if (c != null) {
            this.f2385d = c;
        }
        c = (List) map.get("X-Afma-Debug-Dialog");
        if (!(c == null || c.isEmpty())) {
            this.f2386e = (String) c.get(0);
        }
        c = m2923c(map, "X-Afma-Tracking-Urls");
        if (c != null) {
            this.f2388g = c;
        }
        long b = m2922b(map, "X-Afma-Interstitial-Timeout");
        if (b != -1) {
            this.f2389h = b;
        }
        this.f2390i |= m2924d(map, "X-Afma-Mediation");
        c = m2923c(map, "X-Afma-Manual-Tracking-Urls");
        if (c != null) {
            this.f2391j = c;
        }
        b = m2922b(map, "X-Afma-Refresh-Rate");
        if (b != -1) {
            this.f2392k = b;
        }
        c = (List) map.get("X-Afma-Orientation");
        if (!(c == null || c.isEmpty())) {
            String str = (String) c.get(0);
            if ("portrait".equalsIgnoreCase(str)) {
                this.f2393l = eL.m2838c();
            } else if ("landscape".equalsIgnoreCase(str)) {
                this.f2393l = eL.m2834b();
            }
        }
        this.f2387f = m2921a(map, "X-Afma-ActiveView");
        c = (List) map.get("X-Afma-Use-HTTPS");
        if (!(c == null || c.isEmpty())) {
            this.f2396o = Boolean.valueOf((String) c.get(0)).booleanValue();
        }
        this.f2394m |= m2924d(map, "X-Afma-Custom-Rendering-Allowed");
        this.f2395n |= m2924d(map, "X-Afma-Native");
        c = (List) map.get("X-Afma-Content-Url-Opted-Out");
        if (c != null && !c.isEmpty()) {
            this.f2397p = Boolean.valueOf((String) c.get(0)).booleanValue();
        }
    }
}
