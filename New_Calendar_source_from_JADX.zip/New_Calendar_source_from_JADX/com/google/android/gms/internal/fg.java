package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.webkit.JsPromptResult;

final class fg implements OnClickListener {
    private /* synthetic */ JsPromptResult f2600a;

    fg(JsPromptResult jsPromptResult) {
        this.f2600a = jsPromptResult;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f2600a.cancel();
    }
}
