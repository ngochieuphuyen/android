package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.p014a.C0054a;
import com.google.android.gms.ads.p016b.C0062a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@ey
/* renamed from: com.google.android.gms.internal.Y */
public final class C0463Y {
    private static C0463Y f1620a;

    static {
        f1620a = new C0463Y();
    }

    private C0463Y() {
    }

    public static C0463Y m2311a() {
        return f1620a;
    }

    public static av m2312a(Context context, an anVar) {
        Date a = anVar.m2392a();
        long time = a != null ? a.getTime() : -1;
        String b = anVar.m2394b();
        int c = anVar.m2395c();
        Collection d = anVar.m2396d();
        List unmodifiableList = !d.isEmpty() ? Collections.unmodifiableList(new ArrayList(d)) : null;
        boolean a2 = anVar.m2393a(context);
        int k = anVar.m2403k();
        Location e = anVar.m2397e();
        Bundle a3 = anVar.m2391a(C0054a.class);
        boolean f = anVar.m2398f();
        String g = anVar.m2399g();
        C0062a h = anVar.m2400h();
        return new av(4, time, a3, c, unmodifiableList, a2, k, f, g, h != null ? new bj(h) : null, e, b, anVar.m2402j());
    }
}
