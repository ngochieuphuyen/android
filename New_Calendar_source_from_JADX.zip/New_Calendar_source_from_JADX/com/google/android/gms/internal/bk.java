package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;

@ey
public final class bk extends gq<cm> {
    private int f1976b;

    public bk(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, int i) {
        super(context, context.getMainLooper(), connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.f1976b = 6587000;
    }

    protected final /* synthetic */ IInterface m2537a(IBinder iBinder) {
        return bl.m2542a(iBinder);
    }

    protected final String m2538a() {
        return "com.google.android.gms.ads.gservice.START";
    }

    protected final void m2539a(jt jtVar, gw gwVar) {
        jtVar.m3189g(gwVar, this.f1976b, getContext().getPackageName(), new Bundle());
    }

    protected final String m2540b() {
        return "com.google.android.gms.ads.internal.gservice.IGservicesValueService";
    }

    public final cm m2541c() {
        return (cm) super.m2536m();
    }
}
