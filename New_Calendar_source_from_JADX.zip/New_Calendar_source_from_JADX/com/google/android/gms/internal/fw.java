package com.google.android.gms.internal;

public interface fw {
    String m2938K(String str);
}
