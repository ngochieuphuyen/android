package com.google.android.gms.internal;

import java.lang.ref.WeakReference;

final class cE implements Runnable {
    private final WeakReference<cC> f2019a;
    private /* synthetic */ cC f2020b;
    private /* synthetic */ cD f2021c;

    cE(cD cDVar, cC cCVar) {
        this.f2021c = cDVar;
        this.f2020b = cCVar;
        this.f2019a = new WeakReference(this.f2020b);
    }

    public final void run() {
        cC cCVar = (cC) this.f2019a.get();
        if (!this.f2021c.f2018b && cCVar != null) {
            cCVar.m2566e();
            this.f2021c.m2569b();
        }
    }
}
