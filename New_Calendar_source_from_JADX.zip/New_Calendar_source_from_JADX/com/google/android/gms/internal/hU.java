package com.google.android.gms.internal;

import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.Status;

public final class hU extends it {
    private final BaseImplementation$b<Status> f2791a;

    public hU(BaseImplementation$b<Status> baseImplementation$b) {
        this.f2791a = baseImplementation$b;
    }

    public final void m3317j(Status status) {
        this.f2791a.m988b(status);
    }
}
