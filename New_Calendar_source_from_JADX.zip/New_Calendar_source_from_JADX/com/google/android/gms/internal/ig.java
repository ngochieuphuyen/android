package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.fitness.request.C0357b;
import com.google.android.gms.fitness.request.C0360e;
import com.google.android.gms.fitness.request.C0365j;
import com.google.android.gms.fitness.request.C0367m;
import com.google.android.gms.fitness.request.C0369o;
import com.google.android.gms.fitness.request.C0371q;
import com.google.android.gms.fitness.request.C0375u;
import com.google.android.gms.fitness.request.C0377w;
import com.google.android.gms.fitness.request.C0379y;
import com.google.android.gms.fitness.request.DataDeleteRequest;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.request.DataSourcesRequest;
import com.google.android.gms.fitness.request.DataTypeCreateRequest;
import com.google.android.gms.fitness.request.SessionInsertRequest;
import com.google.android.gms.fitness.request.SessionReadRequest;
import com.google.android.gms.fitness.request.StartBleScanRequest;
import com.google.android.gms.fitness.request.aa;
import com.google.android.gms.fitness.request.ad;
import com.google.android.gms.fitness.request.af;
import com.google.android.gms.fitness.request.ah;
import com.google.android.gms.fitness.request.aj;
import com.google.android.gms.games.Notifications;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

public abstract class ig extends Binder implements lz {
    public static lz m3421a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof lz)) ? new ii(iBinder) : (lz) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        aa aaVar = null;
        switch (i) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                DataSourcesRequest dataSourcesRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    dataSourcesRequest = (DataSourcesRequest) DataSourcesRequest.CREATOR.createFromParcel(parcel);
                }
                m3399a(dataSourcesRequest, hZ.m3327a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                C0369o c0369o;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0369o = (C0369o) C0369o.CREATOR.createFromParcel(parcel);
                }
                m3413a(c0369o, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Error.BAD_CVC /*3*/:
                C0371q c0371q;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0371q = (C0371q) C0371q.CREATOR.createFromParcel(parcel);
                }
                m3414a(c0371q, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Error.BAD_CARD /*4*/:
                af afVar;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    afVar = (af) af.CREATOR.createFromParcel(parcel);
                }
                m3406a(afVar, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Error.DECLINED /*5*/:
                aj ajVar;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    ajVar = (aj) aj.CREATOR.createFromParcel(parcel);
                }
                m3408a(ajVar, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                C0367m c0367m;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0367m = (C0367m) C0367m.CREATOR.createFromParcel(parcel);
                }
                m3412a(c0367m, ik.m3389a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Error.AVS_DECLINE /*7*/:
                C0360e c0360e;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0360e = (C0360e) C0360e.CREATOR.createFromParcel(parcel);
                }
                m3410a(c0360e, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Error.FRAUD_DECLINE /*8*/:
                DataReadRequest dataReadRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    dataReadRequest = (DataReadRequest) DataReadRequest.CREATOR.createFromParcel(parcel);
                }
                m3398a(dataReadRequest, hX.m3324a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                SessionInsertRequest sessionInsertRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    sessionInsertRequest = (SessionInsertRequest) SessionInsertRequest.CREATOR.createFromParcel(parcel);
                }
                m3401a(sessionInsertRequest, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                SessionReadRequest sessionReadRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    sessionReadRequest = (SessionReadRequest) SessionReadRequest.CREATOR.createFromParcel(parcel);
                }
                m3402a(sessionReadRequest, im.m3452a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_android_checkable /*11*/:
                C0377w c0377w;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0377w = (C0377w) C0377w.CREATOR.createFromParcel(parcel);
                }
                m3416a(c0377w, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_android_onClick /*12*/:
                C0379y c0379y;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0379y = (C0379y) C0379y.CREATOR.createFromParcel(parcel);
                }
                m3417a(c0379y, ip.m3461a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_showAsAction /*13*/:
                DataTypeCreateRequest dataTypeCreateRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    dataTypeCreateRequest = (DataTypeCreateRequest) DataTypeCreateRequest.CREATOR.createFromParcel(parcel);
                }
                m3400a(dataTypeCreateRequest, ib.m3374a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_actionLayout /*14*/:
                C0365j c0365j;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0365j = (C0365j) C0365j.CREATOR.createFromParcel(parcel);
                }
                m3411a(c0365j, ib.m3374a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.MenuItem_actionViewClass /*15*/:
                StartBleScanRequest startBleScanRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    startBleScanRequest = (StartBleScanRequest) StartBleScanRequest.CREATOR.createFromParcel(parcel);
                }
                m3403a(startBleScanRequest, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                ad adVar;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    adVar = (ad) ad.CREATOR.createFromParcel(parcel);
                }
                m3405a(adVar, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.ActionBar_progressBarPadding /*17*/:
                C0357b c0357b;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0357b = (C0357b) C0357b.CREATOR.createFromParcel(parcel);
                }
                m3409a(c0357b, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case C0015R.styleable.ActionBar_itemPadding /*18*/:
                ah ahVar;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    ahVar = (ah) ah.CREATOR.createFromParcel(parcel);
                }
                m3407a(ahVar, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 19:
                DataDeleteRequest dataDeleteRequest;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    dataDeleteRequest = (DataDeleteRequest) DataDeleteRequest.CREATOR.createFromParcel(parcel);
                }
                m3397a(dataDeleteRequest, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                parcel2.writeNoException();
                return true;
            case 20:
                C0375u c0375u;
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    c0375u = (C0375u) C0375u.CREATOR.createFromParcel(parcel);
                }
                m3415a(c0375u, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 21:
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                if (parcel.readInt() != 0) {
                    aaVar = (aa) aa.CREATOR.createFromParcel(parcel);
                }
                m3404a(aaVar, it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 22:
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                m3418a(it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 23:
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                m3420b(it.m3316a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 24:
                parcel.enforceInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                m3419a(jz.m3366a(parcel.readStrongBinder()), parcel.readString());
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
