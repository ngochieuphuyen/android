package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.cast.ApplicationMetadata;

public interface ir extends IInterface {
    void m3063a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z);

    void m3064a(String str, double d, boolean z);

    void m3065a(String str, long j);

    void m3066a(String str, long j, int i);

    void ad(int i);

    void ae(int i);

    void af(int i);

    void ag(int i);

    void m3067b(ij ijVar);

    void m3068b(io ioVar);

    void m3069b(String str, byte[] bArr);

    void m3070j(String str, String str2);

    void onApplicationDisconnected(int i);
}
