package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import com.google.android.gms.internal.fe.C0474a;

@ey
public abstract class dN extends eF {
    private final fh f2186a;
    private final C0474a f2187b;

    public dN(fh fhVar, C0474a c0474a) {
        this.f2186a = fhVar;
        this.f2187b = c0474a;
    }

    private static fj m2692a(fl flVar, fh fhVar) {
        fj fjVar = null;
        try {
            fjVar = flVar.m2710b(fhVar);
        } catch (Throwable e) {
            Security.m126d("Could not fetch ad response from ad request service.", e);
        } catch (Throwable e2) {
            Security.m126d("Could not fetch ad response from ad request service due to an Exception.", e2);
        } catch (Throwable e22) {
            Security.m126d("Could not fetch ad response from ad request service due to an Exception.", e22);
        } catch (Throwable e222) {
            eB.m2778a(e222);
        }
        return fjVar;
    }

    public final void m2693a() {
        try {
            fj fjVar;
            fl d = m2696d();
            if (d == null) {
                fjVar = new fj(0);
            } else {
                fjVar = m2692a(d, this.f2186a);
                if (fjVar == null) {
                    fjVar = new fj(0);
                }
            }
            m2695c();
            this.f2187b.m2660a(fjVar);
        } catch (Throwable th) {
            m2695c();
        }
    }

    public final void m2694b() {
        m2695c();
    }

    public abstract void m2695c();

    public abstract fl m2696d();
}
