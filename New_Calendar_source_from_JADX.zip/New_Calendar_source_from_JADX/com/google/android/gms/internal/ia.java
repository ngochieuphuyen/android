package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.fitness.result.DataSourcesResult;

final class ia implements lx {
    private IBinder f2860a;

    ia(IBinder iBinder) {
        this.f2860a = iBinder;
    }

    public final void m3395a(DataSourcesResult dataSourcesResult) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IDataSourcesCallback");
            if (dataSourcesResult != null) {
                obtain.writeInt(1);
                dataSourcesResult.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f2860a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f2860a;
    }
}
