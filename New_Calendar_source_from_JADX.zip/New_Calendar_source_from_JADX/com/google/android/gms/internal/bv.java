package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import org.json.JSONObject;

@ey
public final class bv {
    private la f2005a;
    private ah f2006b;
    private JSONObject f2007c;

    /* renamed from: com.google.android.gms.internal.bv.a */
    public interface C0466a {
        void m2319a(bv bvVar);
    }

    public bv(la laVar, ah ahVar, JSONObject jSONObject) {
        this.f2005a = laVar;
        this.f2006b = ahVar;
        this.f2007c = jSONObject;
    }

    public final void m2550a() {
        this.f2005a.an();
    }

    public final void m2551a(String str, int i) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("asset", i);
            jSONObject.put("template", str);
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("ad", this.f2007c);
            jSONObject2.put("click", jSONObject);
            this.f2006b.m2260a("google.afma.nativeAds.handleClick", jSONObject2);
        } catch (Throwable e) {
            Security.m112b("Unable to create click JSON.", e);
        }
    }
}
