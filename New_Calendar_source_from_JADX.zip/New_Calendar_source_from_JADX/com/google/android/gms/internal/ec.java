package com.google.android.gms.internal;

import android.graphics.drawable.Drawable;
import com.google.android.gms.internal.bv.C0466a;
import com.google.android.gms.internal.fn.C0478a;
import org.json.JSONObject;

@ey
public final class ec implements C0478a<aD> {
    public final /* synthetic */ C0466a m2902a(fn fnVar, JSONObject jSONObject) {
        return new aD(jSONObject.getString("headline"), (Drawable) fnVar.m3123a(jSONObject, "image", true).get(), jSONObject.getString("body"), (Drawable) fnVar.m3123a(jSONObject, "secondary_image", false).get(), jSONObject.getString("call_to_action"), jSONObject.getString("attribution"));
    }
}
