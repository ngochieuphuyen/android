package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.support.v4.p000a.Security;
import android.support.v4.p003c.LunarUtil;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.internal.kr.C0500a;
import com.google.android.gms.wallet.LineItem.Role;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class ky extends kr implements SafeParcelable {
    public static final hs CREATOR;
    private final int f3002a;
    private final Parcel f3003b;
    private final int f3004c;
    private final kv f3005d;
    private final String f3006e;
    private int f3007f;
    private int f3008g;

    static {
        CREATOR = new hs();
    }

    ky(int i, Parcel parcel, kv kvVar) {
        this.f3002a = i;
        this.f3003b = (Parcel) LunarUtil.m182a((Object) parcel);
        this.f3004c = 2;
        this.f3005d = kvVar;
        if (this.f3005d == null) {
            this.f3006e = null;
        } else {
            this.f3006e = this.f3005d.m3800c();
        }
        this.f3007f = 2;
    }

    private static HashMap<String, String> m3803a(Bundle bundle) {
        HashMap<String, String> hashMap = new HashMap();
        for (String str : bundle.keySet()) {
            hashMap.put(str, bundle.getString(str));
        }
        return hashMap;
    }

    private static void m3804a(StringBuilder stringBuilder, int i, Object obj) {
        switch (i) {
            case Role.REGULAR /*0*/:
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
            case Error.BAD_CVC /*3*/:
            case Error.BAD_CARD /*4*/:
            case Error.DECLINED /*5*/:
            case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                stringBuilder.append(obj);
            case Error.AVS_DECLINE /*7*/:
                stringBuilder.append("\"").append(hz.m3354a(obj.toString())).append("\"");
            case Error.FRAUD_DECLINE /*8*/:
                stringBuilder.append("\"").append(Security.m124d((byte[]) obj)).append("\"");
            case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                stringBuilder.append("\"").append(Security.m131e((byte[]) obj));
                stringBuilder.append("\"");
            case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                Security.m85a(stringBuilder, (HashMap) obj);
            case C0015R.styleable.MenuItem_android_checkable /*11*/:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown type = " + i);
        }
    }

    private void m3805a(StringBuilder stringBuilder, C0500a<?, ?> c0500a, Parcel parcel, int i) {
        boolean[] zArr = null;
        int i2 = 0;
        int length;
        if (c0500a.m3773e()) {
            stringBuilder.append("[");
            int dataPosition;
            switch (c0500a.m3772d()) {
                case Role.REGULAR /*0*/:
                    int[] u = Security.m156u(parcel, i);
                    length = u.length;
                    while (i2 < length) {
                        if (i2 != 0) {
                            stringBuilder.append(",");
                        }
                        stringBuilder.append(Integer.toString(u[i2]));
                        i2++;
                    }
                    break;
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    Object[] objArr;
                    length = Security.m40a(parcel, i);
                    dataPosition = parcel.dataPosition();
                    if (length != 0) {
                        int readInt = parcel.readInt();
                        objArr = new BigInteger[readInt];
                        while (i2 < readInt) {
                            objArr[i2] = new BigInteger(parcel.createByteArray());
                            i2++;
                        }
                        parcel.setDataPosition(length + dataPosition);
                    }
                    Security.m90a(stringBuilder, objArr);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    long[] createLongArray;
                    length = Security.m40a(parcel, i);
                    i2 = parcel.dataPosition();
                    if (length != 0) {
                        createLongArray = parcel.createLongArray();
                        parcel.setDataPosition(length + i2);
                    }
                    Security.m89a(stringBuilder, createLongArray);
                    break;
                case Error.BAD_CVC /*3*/:
                    float[] createFloatArray;
                    length = Security.m40a(parcel, i);
                    i2 = parcel.dataPosition();
                    if (length != 0) {
                        createFloatArray = parcel.createFloatArray();
                        parcel.setDataPosition(length + i2);
                    }
                    Security.m87a(stringBuilder, createFloatArray);
                    break;
                case Error.BAD_CARD /*4*/:
                    double[] createDoubleArray;
                    length = Security.m40a(parcel, i);
                    i2 = parcel.dataPosition();
                    if (length != 0) {
                        createDoubleArray = parcel.createDoubleArray();
                        parcel.setDataPosition(length + i2);
                    }
                    Security.m86a(stringBuilder, createDoubleArray);
                    break;
                case Error.DECLINED /*5*/:
                    Security.m90a(stringBuilder, Security.m162z(parcel, i));
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    length = Security.m40a(parcel, i);
                    i2 = parcel.dataPosition();
                    if (length != 0) {
                        zArr = parcel.createBooleanArray();
                        parcel.setDataPosition(length + i2);
                    }
                    Security.m92a(stringBuilder, zArr);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    Security.m91a(stringBuilder, Security.m0A(parcel, i));
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
                case C0015R.styleable.MenuItem_android_checkable /*11*/:
                    Parcel[] E = Security.m7E(parcel, i);
                    dataPosition = E.length;
                    for (int i3 = 0; i3 < dataPosition; i3++) {
                        if (i3 > 0) {
                            stringBuilder.append(",");
                        }
                        E[i3].setDataPosition(0);
                        m3807a(stringBuilder, c0500a.m3780l(), E[i3]);
                    }
                    break;
                default:
                    throw new IllegalStateException("Unknown field type out.");
            }
            stringBuilder.append("]");
            return;
        }
        switch (c0500a.m3772d()) {
            case Role.REGULAR /*0*/:
                stringBuilder.append(Security.m136g(parcel, i));
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                stringBuilder.append(Security.m143k(parcel, i));
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                stringBuilder.append(Security.m139i(parcel, i));
            case Error.BAD_CVC /*3*/:
                stringBuilder.append(Security.m144l(parcel, i));
            case Error.BAD_CARD /*4*/:
                stringBuilder.append(Security.m145m(parcel, i));
            case Error.DECLINED /*5*/:
                stringBuilder.append(Security.m147n(parcel, i));
            case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                stringBuilder.append(Security.m121c(parcel, i));
            case Error.AVS_DECLINE /*7*/:
                stringBuilder.append("\"").append(hz.m3354a(Security.m148o(parcel, i))).append("\"");
            case Error.FRAUD_DECLINE /*8*/:
                stringBuilder.append("\"").append(Security.m124d(Security.m153r(parcel, i))).append("\"");
            case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                stringBuilder.append("\"").append(Security.m131e(Security.m153r(parcel, i)));
                stringBuilder.append("\"");
            case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                Bundle q = Security.m152q(parcel, i);
                Set<String> keySet = q.keySet();
                keySet.size();
                stringBuilder.append("{");
                length = 1;
                for (String str : keySet) {
                    if (length == 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append("\"").append(str).append("\"");
                    stringBuilder.append(":");
                    stringBuilder.append("\"").append(hz.m3354a(q.getString(str))).append("\"");
                    length = 0;
                }
                stringBuilder.append("}");
            case C0015R.styleable.MenuItem_android_checkable /*11*/:
                Parcel D = Security.m3D(parcel, i);
                D.setDataPosition(0);
                m3807a(stringBuilder, c0500a.m3780l(), D);
            default:
                throw new IllegalStateException("Unknown field type out");
        }
    }

    private void m3806a(StringBuilder stringBuilder, C0500a<?, ?> c0500a, Object obj) {
        if (c0500a.m3771c()) {
            ArrayList arrayList = (ArrayList) obj;
            stringBuilder.append("[");
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (i != 0) {
                    stringBuilder.append(",");
                }
                m3804a(stringBuilder, c0500a.m3770b(), arrayList.get(i));
            }
            stringBuilder.append("]");
            return;
        }
        m3804a(stringBuilder, c0500a.m3770b(), obj);
    }

    private void m3807a(StringBuilder stringBuilder, HashMap<String, C0500a<?, ?>> hashMap, Parcel parcel) {
        Entry entry;
        HashMap hashMap2 = new HashMap();
        for (Entry entry2 : hashMap.entrySet()) {
            hashMap2.put(Integer.valueOf(((C0500a) entry2.getValue()).m3775g()), entry2);
        }
        stringBuilder.append('{');
        int G = Security.m12G(parcel);
        Object obj = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            entry2 = (Entry) hashMap2.get(Integer.valueOf(GameRequest.TYPE_ALL & readInt));
            if (entry2 != null) {
                if (obj != null) {
                    stringBuilder.append(",");
                }
                String str = (String) entry2.getKey();
                C0500a c0500a = (C0500a) entry2.getValue();
                stringBuilder.append("\"").append(str).append("\":");
                if (c0500a.m3778j()) {
                    switch (c0500a.m3772d()) {
                        case Role.REGULAR /*0*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Integer.valueOf(Security.m136g(parcel, readInt))));
                            break;
                        case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Security.m143k(parcel, readInt)));
                            break;
                        case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Long.valueOf(Security.m139i(parcel, readInt))));
                            break;
                        case Error.BAD_CVC /*3*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Float.valueOf(Security.m144l(parcel, readInt))));
                            break;
                        case Error.BAD_CARD /*4*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Double.valueOf(Security.m145m(parcel, readInt))));
                            break;
                        case Error.DECLINED /*5*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Security.m147n(parcel, readInt)));
                            break;
                        case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Boolean.valueOf(Security.m121c(parcel, readInt))));
                            break;
                        case Error.AVS_DECLINE /*7*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Security.m148o(parcel, readInt)));
                            break;
                        case Error.FRAUD_DECLINE /*8*/:
                        case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, Security.m153r(parcel, readInt)));
                            break;
                        case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                            m3806a(stringBuilder, c0500a, kr.m3781a(c0500a, m3803a(Security.m152q(parcel, readInt))));
                            break;
                        case C0015R.styleable.MenuItem_android_checkable /*11*/:
                            throw new IllegalArgumentException("Method does not accept concrete type.");
                        default:
                            throw new IllegalArgumentException("Unknown field out type = " + c0500a.m3772d());
                    }
                }
                m3805a(stringBuilder, c0500a, parcel, readInt);
                obj = 1;
            }
        }
        if (parcel.dataPosition() != G) {
            throw new CacheLoader("Overread allowed size end=" + G, parcel);
        }
        stringBuilder.append('}');
    }

    public final HashMap<String, C0500a<?, ?>> m3808a() {
        return this.f3005d == null ? null : this.f3005d.m3798a(this.f3006e);
    }

    protected final Object m3809b() {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    protected final boolean m3810c() {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    public final int m3811d() {
        return this.f3002a;
    }

    public int describeContents() {
        hs hsVar = CREATOR;
        return 0;
    }

    public final Parcel m3812e() {
        switch (this.f3007f) {
            case Role.REGULAR /*0*/:
                this.f3008g = Security.m15H(this.f3003b);
                break;
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                break;
        }
        Security.m17H(this.f3003b, this.f3008g);
        this.f3007f = 2;
        return this.f3003b;
    }

    final kv m3813f() {
        return this.f3005d;
    }

    public String toString() {
        LunarUtil.m183a(this.f3005d, (Object) "Cannot convert to JSON on client side.");
        Parcel e = m3812e();
        e.setDataPosition(0);
        StringBuilder stringBuilder = new StringBuilder(100);
        m3807a(stringBuilder, this.f3005d.m3798a(this.f3006e), e);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        hs hsVar = CREATOR;
        hs.m3341a(this, parcel, i);
    }
}
