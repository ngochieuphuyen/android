package com.google.android.gms.internal;

import android.support.v4.p000a.Security;

final class bU implements Runnable {
    private /* synthetic */ bO f1937a;

    bU(bO bOVar) {
        this.f1937a = bOVar;
    }

    public final void run() {
        try {
            this.f1937a.f1930a.onAdClosed();
        } catch (Throwable e) {
            Security.m126d("Could not call onAdClosed.", e);
        }
    }
}
