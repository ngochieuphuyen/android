package com.google.android.gms.internal;

import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.net.Uri.Builder;
import android.text.TextUtils;
import android.view.MotionEvent;
import java.util.Map;

@ey
public final class eQ {
    private final Context f2325a;
    private String f2326b;
    private final float f2327c;
    private float f2328d;
    private float f2329e;
    private float f2330f;
    private int f2331g;

    public eQ(Context context) {
        this.f2331g = 0;
        this.f2325a = context;
        this.f2327c = context.getResources().getDisplayMetrics().density;
    }

    public eQ(Context context, String str) {
        this(context);
        this.f2326b = str;
    }

    private void m2851a(int i, float f, float f2) {
        if (i == 0) {
            this.f2331g = 0;
            this.f2328d = f;
            this.f2329e = f2;
            this.f2330f = f2;
        } else if (this.f2331g == -1) {
        } else {
            if (i == 2) {
                if (f2 > this.f2329e) {
                    this.f2329e = f2;
                } else if (f2 < this.f2330f) {
                    this.f2330f = f2;
                }
                if (this.f2329e - this.f2330f > 30.0f * this.f2327c) {
                    this.f2331g = -1;
                    return;
                }
                if (this.f2331g == 0 || this.f2331g == 2) {
                    if (f - this.f2328d >= 50.0f * this.f2327c) {
                        this.f2328d = f;
                        this.f2331g++;
                    }
                } else if ((this.f2331g == 1 || this.f2331g == 3) && f - this.f2328d <= -50.0f * this.f2327c) {
                    this.f2328d = f;
                    this.f2331g++;
                }
                if (this.f2331g == 1 || this.f2331g == 3) {
                    if (f > this.f2328d) {
                        this.f2328d = f;
                    }
                } else if (this.f2331g == 2 && f < this.f2328d) {
                    this.f2328d = f;
                }
            } else if (i == 1 && this.f2331g == 4) {
                Object obj;
                if (TextUtils.isEmpty(this.f2326b)) {
                    obj = "No debug information";
                } else {
                    Uri build = new Builder().encodedQuery(this.f2326b).build();
                    StringBuilder stringBuilder = new StringBuilder();
                    Map a = eL.m2815a(build);
                    for (String str : a.keySet()) {
                        stringBuilder.append(str).append(" = ").append((String) a.get(str)).append("\n\n");
                    }
                    obj = stringBuilder.toString().trim();
                    if (TextUtils.isEmpty(obj)) {
                        obj = "No debug information";
                    }
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(this.f2325a);
                builder.setMessage(obj);
                builder.setTitle("Ad Information");
                builder.setPositiveButton("Share", new eR(this, obj));
                builder.setNegativeButton("Close", new eS(this));
                builder.create().show();
            }
        }
    }

    public final void m2852a(MotionEvent motionEvent) {
        int historySize = motionEvent.getHistorySize();
        for (int i = 0; i < historySize; i++) {
            m2851a(motionEvent.getActionMasked(), motionEvent.getHistoricalX(0, i), motionEvent.getHistoricalY(0, i));
        }
        m2851a(motionEvent.getActionMasked(), motionEvent.getX(), motionEvent.getY());
    }

    public final void m2853a(String str) {
        this.f2326b = str;
    }
}
