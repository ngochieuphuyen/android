package com.google.android.gms.internal;

final class dD implements Runnable {
    private /* synthetic */ ex f2152a;
    private /* synthetic */ dB f2153b;

    dD(dB dBVar, ex exVar) {
        this.f2153b = dBVar;
        this.f2152a = exVar;
    }

    public final void run() {
        synchronized (this.f2153b.f2145d) {
            this.f2153b.f2142a.m2940a(this.f2152a);
        }
    }
}
