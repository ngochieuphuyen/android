package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class hd implements SafeParcelable {
    public static final fu CREATOR;
    final int f2797a;
    final hh[] f2798b;
    public final String f2799c;
    public final boolean f2800d;
    public final Account f2801e;

    static {
        CREATOR = new fu();
    }

    hd(int i, hh[] hhVarArr, String str, boolean z, Account account) {
        this.f2797a = i;
        this.f2798b = hhVarArr;
        this.f2799c = str;
        this.f2800d = z;
        this.f2801e = account;
    }

    public int describeContents() {
        fu fuVar = CREATOR;
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        fu fuVar = CREATOR;
        fu.m3132a(this, parcel, i);
    }
}
