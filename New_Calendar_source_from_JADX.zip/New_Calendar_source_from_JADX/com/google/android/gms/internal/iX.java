package com.google.android.gms.internal;

import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.fitness.result.ListSubscriptionsResult;

final class iX extends ik {
    private final BaseImplementation$b<ListSubscriptionsResult> f2857a;

    private iX(BaseImplementation$b<ListSubscriptionsResult> baseImplementation$b) {
        this.f2857a = baseImplementation$b;
    }

    public final void m3390a(ListSubscriptionsResult listSubscriptionsResult) {
        this.f2857a.m988b(listSubscriptionsResult);
    }
}
