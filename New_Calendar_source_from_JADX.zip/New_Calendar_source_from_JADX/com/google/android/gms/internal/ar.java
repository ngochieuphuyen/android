package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;

public final class ar implements Creator<bj> {
    static void m2433a(bj bjVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, bjVar.f1951a);
        Security.m118c(parcel, 2, bjVar.f1952b);
        Security.m118c(parcel, 3, bjVar.f1953c);
        Security.m118c(parcel, 4, bjVar.f1954d);
        Security.m118c(parcel, 5, bjVar.f1955e);
        Security.m118c(parcel, 6, bjVar.f1956f);
        Security.m118c(parcel, 7, bjVar.f1957g);
        Security.m118c(parcel, 8, bjVar.f1958h);
        Security.m118c(parcel, 9, bjVar.f1959i);
        Security.m69a(parcel, 10, bjVar.f1960j, false);
        Security.m118c(parcel, 11, bjVar.f1961k);
        Security.m69a(parcel, 12, bjVar.f1962l, false);
        Security.m118c(parcel, 13, bjVar.f1963m);
        Security.m118c(parcel, 14, bjVar.f1964n);
        Security.m69a(parcel, 15, bjVar.f1965o, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        String str = null;
        int i10 = 0;
        String str2 = null;
        int i11 = 0;
        int i12 = 0;
        String str3 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    i4 = Security.m136g(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    i5 = Security.m136g(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    i6 = Security.m136g(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i7 = Security.m136g(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    i8 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    i9 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_checkable /*11*/:
                    i10 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_onClick /*12*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_showAsAction /*13*/:
                    i11 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_actionLayout /*14*/:
                    i12 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_actionViewClass /*15*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new bj(i, i2, i3, i4, i5, i6, i7, i8, i9, str, i10, str2, i11, i12, str3);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new bj[i];
    }
}
