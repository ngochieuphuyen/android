package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageButton;

@ey
public final class cF extends FrameLayout implements OnClickListener {
    private final Activity f2022a;
    private final ImageButton f2023b;

    public cF(Activity activity, int i) {
        super(activity);
        this.f2022a = activity;
        setOnClickListener(this);
        this.f2023b = new ImageButton(activity);
        this.f2023b.setImageResource(17301527);
        this.f2023b.setBackgroundColor(0);
        this.f2023b.setOnClickListener(this);
        this.f2023b.setPadding(0, 0, 0, 0);
        this.f2023b.setContentDescription("Interstitial close button");
        int a = eW.m2857a((Context) activity, i);
        addView(this.f2023b, new LayoutParams(a, a, 17));
    }

    public final void m2570a(boolean z) {
        this.f2023b.setVisibility(z ? 4 : 0);
    }

    public final void onClick(View view) {
        this.f2022a.finish();
    }
}
