package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.data.Session;
import com.google.android.gms.fitness.request.C0352M;

final class jk extends hV {
    private /* synthetic */ Session f2913a;

    jk(jh jhVar, GoogleApiClient googleApiClient, Session session) {
        this.f2913a = session;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3601a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3416a(new C0352M().m1696a(this.f2913a).m1697a(), new hU(this), luVar.getContext().getPackageName());
    }
}
