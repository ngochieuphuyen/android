package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.Notifications;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.internal.pi.C0509a;
import com.google.android.gms.internal.pi.C0512b;
import com.google.android.gms.internal.pi.C0513c;
import com.google.android.gms.internal.pi.C0514d;
import com.google.android.gms.internal.pi.C0515f;
import com.google.android.gms.internal.pi.C0516g;
import com.google.android.gms.internal.pi.C0517h;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class kl implements Creator<pi> {
    public static pi m3745a(Parcel parcel) {
        int G = Security.m12G(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        String str = null;
        C0509a c0509a = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        C0512b c0512b = null;
        String str4 = null;
        String str5 = null;
        int i3 = 0;
        String str6 = null;
        C0513c c0513c = null;
        boolean z = false;
        String str7 = null;
        C0514d c0514d = null;
        String str8 = null;
        int i4 = 0;
        List list = null;
        List list2 = null;
        int i5 = 0;
        int i6 = 0;
        String str9 = null;
        String str10 = null;
        List list3 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CVC /*3*/:
                    C0509a c0509a2 = (C0509a) Security.m47a(parcel, readInt, C0509a.CREATOR);
                    hashSet.add(Integer.valueOf(3));
                    c0509a = c0509a2;
                    break;
                case Error.BAD_CARD /*4*/:
                    str2 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(4));
                    break;
                case Error.DECLINED /*5*/:
                    str3 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    i2 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(6));
                    break;
                case Error.AVS_DECLINE /*7*/:
                    C0512b c0512b2 = (C0512b) Security.m47a(parcel, readInt, C0512b.CREATOR);
                    hashSet.add(Integer.valueOf(7));
                    c0512b = c0512b2;
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    str4 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(8));
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    str5 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(9));
                    break;
                case C0015R.styleable.MenuItem_android_onClick /*12*/:
                    i3 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(12));
                    break;
                case C0015R.styleable.MenuItem_actionLayout /*14*/:
                    str6 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(14));
                    break;
                case C0015R.styleable.MenuItem_actionViewClass /*15*/:
                    C0513c c0513c2 = (C0513c) Security.m47a(parcel, readInt, C0513c.CREATOR);
                    hashSet.add(Integer.valueOf(15));
                    c0513c = c0513c2;
                    break;
                case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                    z = Security.m121c(parcel, readInt);
                    hashSet.add(Integer.valueOf(16));
                    break;
                case C0015R.styleable.ActionBar_itemPadding /*18*/:
                    str7 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(18));
                    break;
                case 19:
                    C0514d c0514d2 = (C0514d) Security.m47a(parcel, readInt, C0514d.CREATOR);
                    hashSet.add(Integer.valueOf(19));
                    c0514d = c0514d2;
                    break;
                case 20:
                    str8 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(20));
                    break;
                case 21:
                    i4 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(21));
                    break;
                case 22:
                    list = Security.m117c(parcel, readInt, C0515f.CREATOR);
                    hashSet.add(Integer.valueOf(22));
                    break;
                case 23:
                    list2 = Security.m117c(parcel, readInt, C0516g.CREATOR);
                    hashSet.add(Integer.valueOf(23));
                    break;
                case 24:
                    i5 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(24));
                    break;
                case 25:
                    i6 = Security.m136g(parcel, readInt);
                    hashSet.add(Integer.valueOf(25));
                    break;
                case 26:
                    str9 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(26));
                    break;
                case 27:
                    str10 = Security.m148o(parcel, readInt);
                    hashSet.add(Integer.valueOf(27));
                    break;
                case 28:
                    list3 = Security.m117c(parcel, readInt, C0517h.CREATOR);
                    hashSet.add(Integer.valueOf(28));
                    break;
                case 29:
                    z2 = Security.m121c(parcel, readInt);
                    hashSet.add(Integer.valueOf(29));
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi(hashSet, i, str, c0509a, str2, str3, i2, c0512b, str4, str5, i3, str6, c0513c, z, str7, c0514d, str8, i4, list, list2, i5, i6, str9, str10, list3, z2);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    static void m3746a(pi piVar, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Set set = piVar.f3277a;
        if (set.contains(Integer.valueOf(1))) {
            Security.m118c(parcel, 1, piVar.f3278b);
        }
        if (set.contains(Integer.valueOf(2))) {
            Security.m69a(parcel, 2, piVar.f3279c, true);
        }
        if (set.contains(Integer.valueOf(3))) {
            Security.m65a(parcel, 3, piVar.f3280d, i, true);
        }
        if (set.contains(Integer.valueOf(4))) {
            Security.m69a(parcel, 4, piVar.f3281e, true);
        }
        if (set.contains(Integer.valueOf(5))) {
            Security.m69a(parcel, 5, piVar.f3282f, true);
        }
        if (set.contains(Integer.valueOf(6))) {
            Security.m118c(parcel, 6, piVar.f3283g);
        }
        if (set.contains(Integer.valueOf(7))) {
            Security.m65a(parcel, 7, piVar.f3284h, i, true);
        }
        if (set.contains(Integer.valueOf(8))) {
            Security.m69a(parcel, 8, piVar.f3285i, true);
        }
        if (set.contains(Integer.valueOf(9))) {
            Security.m69a(parcel, 9, piVar.f3286j, true);
        }
        if (set.contains(Integer.valueOf(12))) {
            Security.m118c(parcel, 12, piVar.f3287k);
        }
        if (set.contains(Integer.valueOf(14))) {
            Security.m69a(parcel, 14, piVar.f3288l, true);
        }
        if (set.contains(Integer.valueOf(15))) {
            Security.m65a(parcel, 15, piVar.f3289m, i, true);
        }
        if (set.contains(Integer.valueOf(16))) {
            Security.m73a(parcel, 16, piVar.f3290n);
        }
        if (set.contains(Integer.valueOf(19))) {
            Security.m65a(parcel, 19, piVar.f3292p, i, true);
        }
        if (set.contains(Integer.valueOf(18))) {
            Security.m69a(parcel, 18, piVar.f3291o, true);
        }
        if (set.contains(Integer.valueOf(21))) {
            Security.m118c(parcel, 21, piVar.f3294r);
        }
        if (set.contains(Integer.valueOf(20))) {
            Security.m69a(parcel, 20, piVar.f3293q, true);
        }
        if (set.contains(Integer.valueOf(23))) {
            Security.m119c(parcel, 23, piVar.f3296t, true);
        }
        if (set.contains(Integer.valueOf(22))) {
            Security.m119c(parcel, 22, piVar.f3295s, true);
        }
        if (set.contains(Integer.valueOf(25))) {
            Security.m118c(parcel, 25, piVar.f3298v);
        }
        if (set.contains(Integer.valueOf(24))) {
            Security.m118c(parcel, 24, piVar.f3297u);
        }
        if (set.contains(Integer.valueOf(27))) {
            Security.m69a(parcel, 27, piVar.f3300x, true);
        }
        if (set.contains(Integer.valueOf(26))) {
            Security.m69a(parcel, 26, piVar.f3299w, true);
        }
        if (set.contains(Integer.valueOf(29))) {
            Security.m73a(parcel, 29, piVar.f3302z);
        }
        if (set.contains(Integer.valueOf(28))) {
            Security.m119c(parcel, 28, piVar.f3301y, true);
        }
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3745a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new pi[i];
    }
}
