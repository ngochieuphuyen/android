package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.metadata.internal.C0240h;

public final class hG extends C0240h implements SortableMetadataField<Long> {
    public hG(String str, int i) {
        super(str, 4300000);
    }
}
