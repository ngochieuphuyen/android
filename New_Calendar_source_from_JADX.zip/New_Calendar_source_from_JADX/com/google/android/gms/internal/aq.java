package com.google.android.gms.internal;

import android.content.Context;
import android.support.v4.p000a.Security;
import com.google.android.gms.ads.C0055a;

public final class aq {
    private final bC f1846a;
    private final Context f1847b;
    private final C0463Y f1848c;
    private C0055a f1849d;
    private bd f1850e;
    private String f1851f;

    public aq(Context context) {
        this(context, C0463Y.m2311a(), null);
    }

    private aq(Context context, C0463Y c0463y, Security security) {
        this.f1846a = new bC();
        this.f1847b = context;
        this.f1848c = c0463y;
    }

    private void m2428b(String str) {
        if (this.f1850e == null) {
            throw new IllegalStateException("The ad unit ID must be set on InterstitialAd before " + str + " is called.");
        }
    }

    public final void m2429a() {
        try {
            m2428b("show");
            this.f1850e.showInterstitial();
        } catch (Throwable e) {
            Security.m126d("Failed to show interstitial.", e);
        }
    }

    public final void m2430a(C0055a c0055a) {
        try {
            this.f1849d = c0055a;
            if (this.f1850e != null) {
                this.f1850e.m2372a(c0055a != null ? new C0460V(c0055a) : null);
            }
        } catch (Throwable e) {
            Security.m126d("Failed to set the AdListener.", e);
        }
    }

    public final void m2431a(an anVar) {
        try {
            if (this.f1850e == null) {
                String str = "loadAd";
                if (this.f1851f == null) {
                    m2428b(str);
                }
                this.f1850e = C0461W.m2306a(this.f1847b, new ay(), this.f1851f, this.f1846a);
                if (this.f1849d != null) {
                    this.f1850e.m2372a(new C0460V(this.f1849d));
                }
            }
            bd bdVar = this.f1850e;
            C0463Y c0463y = this.f1848c;
            if (bdVar.m2377a(C0463Y.m2312a(this.f1847b, anVar))) {
                this.f1846a.m2473a(anVar.m2401i());
            }
        } catch (Throwable e) {
            Security.m126d("Failed to load ad.", e);
        }
    }

    public final void m2432a(String str) {
        if (this.f1851f != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on InterstitialAd.");
        }
        this.f1851f = str;
    }
}
