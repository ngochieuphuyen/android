package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.fitness.request.ah;

final class iF extends hV {
    private /* synthetic */ String f2843a;

    iF(iA iAVar, GoogleApiClient googleApiClient, String str) {
        this.f2843a = str;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m3362a(C0127a c0127a) {
        lu luVar = (lu) c0127a;
        luVar.jM().m3407a(new ah(this.f2843a), new hU(this), luVar.getContext().getPackageName());
    }
}
