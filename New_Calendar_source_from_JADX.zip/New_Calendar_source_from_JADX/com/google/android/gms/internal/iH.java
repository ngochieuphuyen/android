package com.google.android.gms.internal;

import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.fitness.result.BleDevicesResult;

final class iH extends jz {
    private final BaseImplementation$b<BleDevicesResult> f2844a;

    private iH(BaseImplementation$b<BleDevicesResult> baseImplementation$b) {
        this.f2844a = baseImplementation$b;
    }

    public final void m3367a(BleDevicesResult bleDevicesResult) {
        this.f2844a.m988b(bleDevicesResult);
    }
}
