package com.google.android.gms.internal;

import android.support.v4.p000a.Security;
import com.google.android.gms.fitness.data.DataSource;

public final class iz {
    private static final ThreadLocal<String> f2880a;

    static {
        f2880a = new ThreadLocal();
    }

    public static DataSource m3468a(DataSource dataSource) {
        if (!dataSource.m1565h()) {
            return dataSource;
        }
        return (m3470a() || ((String) f2880a.get()).equals(dataSource.m1561d())) ? dataSource : dataSource.m1567j();
    }

    public static String m3469a(String str) {
        String str2 = (String) f2880a.get();
        if (str == null || str2 == null) {
            return str;
        }
        byte[] bArr = new byte[(str.length() + str2.length())];
        System.arraycopy(str.getBytes(), 0, bArr, 0, str.length());
        System.arraycopy(str2.getBytes(), 0, bArr, str.length(), str2.length());
        return Integer.toHexString(Security.m42a(bArr, 0, bArr.length, 0));
    }

    public static boolean m3470a() {
        String str = (String) f2880a.get();
        return str == null || str.startsWith("com.google");
    }
}
