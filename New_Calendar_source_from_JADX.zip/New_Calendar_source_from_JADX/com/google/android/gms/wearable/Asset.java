package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.C0477e;
import java.util.Arrays;

public class Asset implements SafeParcelable {
    public static final Creator<Asset> CREATOR;
    final int f3804a;
    public ParcelFileDescriptor f3805b;
    public Uri f3806c;
    private byte[] f3807d;
    private String f3808e;

    static {
        CREATOR = new C0750d();
    }

    Asset(int i, byte[] bArr, String str, ParcelFileDescriptor parcelFileDescriptor, Uri uri) {
        this.f3804a = i;
        this.f3807d = bArr;
        this.f3808e = str;
        this.f3805b = parcelFileDescriptor;
        this.f3806c = uri;
    }

    public final byte[] m4551a() {
        return this.f3807d;
    }

    public final String m4552b() {
        return this.f3808e;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Asset)) {
            return false;
        }
        Asset asset = (Asset) obj;
        return C0477e.m2759a(this.f3807d, asset.f3807d) && C0477e.m2759a(this.f3808e, asset.f3808e) && C0477e.m2759a(this.f3805b, asset.f3805b) && C0477e.m2759a(this.f3806c, asset.f3806c);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f3807d, this.f3808e, this.f3805b, this.f3806c});
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Asset[@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.f3808e == null) {
            stringBuilder.append(", nodigest");
        } else {
            stringBuilder.append(", ");
            stringBuilder.append(this.f3808e);
        }
        if (this.f3807d != null) {
            stringBuilder.append(", size=");
            stringBuilder.append(this.f3807d.length);
        }
        if (this.f3805b != null) {
            stringBuilder.append(", fd=");
            stringBuilder.append(this.f3805b);
        }
        if (this.f3806c != null) {
            stringBuilder.append(", uri=");
            stringBuilder.append(this.f3806c);
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0750d.m4565a(this, parcel, i | 1);
    }
}
