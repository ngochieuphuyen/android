package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.C0749c;

@Deprecated
/* renamed from: com.google.android.gms.wearable.internal.r */
public class C0778r implements SafeParcelable {
    public static final Creator<C0778r> CREATOR;
    public final int f3867a;
    public final int f3868b;
    public final C0749c f3869c;

    static {
        CREATOR = new C0757D();
    }

    C0778r(int i, int i2, C0749c c0749c) {
        this.f3867a = i;
        this.f3868b = i2;
        this.f3869c = c0749c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0757D.m4570a(this, parcel, i);
    }
}
