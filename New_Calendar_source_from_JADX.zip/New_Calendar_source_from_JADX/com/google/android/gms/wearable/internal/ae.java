package com.google.android.gms.wearable.internal;

import android.os.IInterface;
import com.google.android.gms.common.data.DataHolder;

public interface ae extends IInterface {
    void m4586a(ai aiVar);

    void m4587a(al alVar);

    void aa(DataHolder dataHolder);

    void m4588b(al alVar);
}
