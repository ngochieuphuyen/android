package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.h */
public final class C0768h implements Creator<an> {
    static void m4622a(an anVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, anVar.f3837a);
        Security.m69a(parcel, 2, anVar.f3838b, false);
        Security.m69a(parcel, 3, anVar.f3839c, false);
        Security.m61a(parcel, 4, anVar.f3840d);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        String str = null;
        int G = Security.m12G(parcel);
        int i = 0;
        long j = 0;
        String str2 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    j = Security.m139i(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new an(i, str2, str, j);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new an[i];
    }
}
