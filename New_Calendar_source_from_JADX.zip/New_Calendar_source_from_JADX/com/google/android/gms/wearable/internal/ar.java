package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ar implements SafeParcelable {
    public static final Creator<ar> CREATOR;
    final int f3844a;
    private ae f3845b;

    static {
        CREATOR = new C0770j();
    }

    ar(int i, IBinder iBinder) {
        this.f3844a = i;
        if (iBinder != null) {
            this.f3845b = C0764d.m4616a(iBinder);
        } else {
            this.f3845b = null;
        }
    }

    final IBinder m4613a() {
        return this.f3845b == null ? null : this.f3845b.asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0770j.m4624a(this, parcel);
    }
}
