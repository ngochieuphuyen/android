package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.wearable.internal.m */
public class C0773m implements SafeParcelable, DataItem {
    public static final Creator<C0773m> CREATOR;
    final int f3857a;
    private final Uri f3858b;
    private final Map<String, DataItemAsset> f3859c;
    private byte[] f3860d;

    static {
        CREATOR = new C0754A();
    }

    C0773m(int i, Uri uri, Bundle bundle, byte[] bArr) {
        this.f3857a = i;
        this.f3858b = uri;
        Map hashMap = new HashMap();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (String str : bundle.keySet()) {
            hashMap.put(str, (DataItemAssetParcelable) bundle.getParcelable(str));
        }
        this.f3859c = hashMap;
        this.f3860d = bArr;
    }

    public final Bundle m4627a() {
        Bundle bundle = new Bundle();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (Entry entry : this.f3859c.entrySet()) {
            bundle.putParcelable((String) entry.getKey(), new DataItemAssetParcelable((DataItemAsset) entry.getValue()));
        }
        return bundle;
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return this;
    }

    public Map<String, DataItemAsset> getAssets() {
        return this.f3859c;
    }

    public byte[] getData() {
        return this.f3860d;
    }

    public Uri getUri() {
        return this.f3858b;
    }

    public boolean isDataValid() {
        return true;
    }

    public /* synthetic */ DataItem setData(byte[] bArr) {
        this.f3860d = bArr;
        return this;
    }

    public String toString() {
        boolean isLoggable = Log.isLoggable("DataItem", 3);
        StringBuilder stringBuilder = new StringBuilder("DataItemParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        stringBuilder.append(",dataSz=" + (this.f3860d == null ? "null" : Integer.valueOf(this.f3860d.length)));
        stringBuilder.append(", numAssets=" + this.f3859c.size());
        stringBuilder.append(", uri=" + this.f3858b);
        if (isLoggable) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.f3859c.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.f3859c.get(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0754A.m4568a(this, parcel, i);
    }
}
