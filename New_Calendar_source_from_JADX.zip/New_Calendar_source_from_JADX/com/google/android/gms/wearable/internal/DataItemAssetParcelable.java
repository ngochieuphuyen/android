package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.DataItemAsset;

public class DataItemAssetParcelable implements SafeParcelable, DataItemAsset {
    public static final Creator<DataItemAssetParcelable> CREATOR;
    final int f3823a;
    private final String f3824b;
    private final String f3825c;

    static {
        CREATOR = new C0781u();
    }

    DataItemAssetParcelable(int i, String str, String str2) {
        this.f3823a = i;
        this.f3824b = str;
        this.f3825c = str2;
    }

    public DataItemAssetParcelable(DataItemAsset dataItemAsset) {
        this.f3823a = 1;
        this.f3824b = (String) LunarUtil.m182a(dataItemAsset.getId());
        this.f3825c = (String) LunarUtil.m182a(dataItemAsset.getDataItemKey());
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return this;
    }

    public String getDataItemKey() {
        return this.f3825c;
    }

    public String getId() {
        return this.f3824b;
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.f3824b == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.f3824b);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.f3825c);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0781u.m4629a(this, parcel);
    }
}
