package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.f */
public final class C0766f implements Creator<ai> {
    static void m4620a(ai aiVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, aiVar.f3829a);
        Security.m118c(parcel, 2, aiVar.getRequestId());
        Security.m69a(parcel, 3, aiVar.getPath(), false);
        Security.m74a(parcel, 4, aiVar.getData(), false);
        Security.m69a(parcel, 5, aiVar.getSourceNodeId(), false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        String str = null;
        int G = Security.m12G(parcel);
        byte[] bArr = null;
        String str2 = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    bArr = Security.m153r(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ai(i2, i, str2, bArr, str);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ai[i];
    }
}
