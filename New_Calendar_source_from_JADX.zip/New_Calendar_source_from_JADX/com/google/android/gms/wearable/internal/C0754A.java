package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.A */
public final class C0754A implements Creator<C0773m> {
    static void m4568a(C0773m c0773m, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, c0773m.f3857a);
        Security.m65a(parcel, 2, c0773m.getUri(), i, false);
        Security.m62a(parcel, 4, c0773m.m4627a(), false);
        Security.m74a(parcel, 5, c0773m.getData(), false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int G = Security.m12G(parcel);
        Bundle bundle = null;
        Uri uri = null;
        int i = 0;
        byte[] bArr = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    uri = (Uri) Security.m47a(parcel, readInt, Uri.CREATOR);
                    break;
                case Error.BAD_CARD /*4*/:
                    bundle = Security.m152q(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    bArr = Security.m153r(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new C0773m(i, uri, bundle, bArr);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0773m[i];
    }
}
