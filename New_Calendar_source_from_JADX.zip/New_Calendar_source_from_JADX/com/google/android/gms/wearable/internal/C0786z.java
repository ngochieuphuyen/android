package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.z */
public class C0786z implements SafeParcelable {
    public static final Creator<C0786z> CREATOR;
    public final int f3884a;
    public final int f3885b;
    public final ParcelFileDescriptor f3886c;

    static {
        CREATOR = new C0761a();
    }

    C0786z(int i, int i2, ParcelFileDescriptor parcelFileDescriptor) {
        this.f3884a = i;
        this.f3885b = i2;
        this.f3886c = parcelFileDescriptor;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0761a.m4574a(this, parcel, i | 1);
    }
}
