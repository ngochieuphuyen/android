package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.data.DataHolder;

/* renamed from: com.google.android.gms.wearable.internal.e */
final class C0765e implements ae {
    private IBinder f3856a;

    C0765e(IBinder iBinder) {
        this.f3856a = iBinder;
    }

    public final void m4617a(ai aiVar) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
            if (aiVar != null) {
                obtain.writeInt(1);
                aiVar.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f3856a.transact(2, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void m4618a(al alVar) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
            if (alVar != null) {
                obtain.writeInt(1);
                alVar.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f3856a.transact(3, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final void aa(DataHolder dataHolder) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
            if (dataHolder != null) {
                obtain.writeInt(1);
                dataHolder.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f3856a.transact(1, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public final IBinder asBinder() {
        return this.f3856a;
    }

    public final void m4619b(al alVar) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
            if (alVar != null) {
                obtain.writeInt(1);
                alVar.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f3856a.transact(4, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }
}
