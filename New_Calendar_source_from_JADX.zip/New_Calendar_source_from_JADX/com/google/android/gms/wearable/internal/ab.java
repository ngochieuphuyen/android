package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ab implements SafeParcelable {
    public static final Creator<ab> CREATOR;
    public final int f3826a;
    public final int f3827b;
    public final al f3828c;

    static {
        CREATOR = new C0763c();
    }

    ab(int i, int i2, al alVar) {
        this.f3826a = i;
        this.f3827b = i2;
        this.f3828c = alVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0763c.m4615a(this, parcel, i);
    }
}
