package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.k */
public final class C0771k implements Creator<at> {
    static void m4625a(at atVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, atVar.f3846a);
        Security.m118c(parcel, 2, atVar.f3847b);
        Security.m118c(parcel, 3, atVar.f3848c);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new at(i3, i2, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new at[i];
    }
}
