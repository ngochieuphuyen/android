package com.google.android.gms.wearable.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

public interface ad extends IInterface {
    void m4575a(Status status);

    void m4576a(ab abVar);

    void m4577a(ap apVar);

    void m4578a(at atVar);

    void m4579a(aw awVar);

    void m4580a(C0776p c0776p);

    void m4581a(C0778r c0778r);

    void m4582a(C0780t c0780t);

    void m4583a(C0782v c0782v);

    void m4584a(C0784x c0784x);

    void m4585a(C0786z c0786z);

    void ab(DataHolder dataHolder);
}
