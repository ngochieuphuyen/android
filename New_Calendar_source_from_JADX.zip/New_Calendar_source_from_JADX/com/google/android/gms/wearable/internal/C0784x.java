package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.x */
public class C0784x implements SafeParcelable {
    public static final Creator<C0784x> CREATOR;
    public final int f3878a;
    public final int f3879b;
    public final C0773m f3880c;

    static {
        CREATOR = new C0760G();
    }

    C0784x(int i, int i2, C0773m c0773m) {
        this.f3878a = i;
        this.f3879b = i2;
        this.f3880c = c0773m;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0760G.m4573a(this, parcel, i);
    }
}
