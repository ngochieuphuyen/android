package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.IInterface;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.C0749c;
import com.google.android.gms.wearable.PutDataRequest;

public interface af extends IInterface {
    void m4589a(ad adVar);

    void m4590a(ad adVar, Uri uri);

    void m4591a(ad adVar, Asset asset);

    void m4592a(ad adVar, PutDataRequest putDataRequest);

    void m4593a(ad adVar, C0749c c0749c);

    void m4594a(ad adVar, ar arVar);

    void m4595a(ad adVar, C0762b c0762b);

    void m4596a(ad adVar, String str);

    void m4597a(ad adVar, String str, String str2, byte[] bArr);

    void m4598b(ad adVar);

    void m4599b(ad adVar, Uri uri);

    void m4600b(ad adVar, C0749c c0749c);

    void m4601b(ad adVar, String str);

    void m4602c(ad adVar);

    void m4603c(ad adVar, Uri uri);

    void m4604c(ad adVar, String str);

    void m4605d(ad adVar);

    void m4606e(ad adVar);

    void m4607f(ad adVar);

    void m4608g(ad adVar);

    void m4609h(ad adVar);

    void m4610i(ad adVar);

    void m4611j(ad adVar);

    void m4612k(ad adVar);
}
