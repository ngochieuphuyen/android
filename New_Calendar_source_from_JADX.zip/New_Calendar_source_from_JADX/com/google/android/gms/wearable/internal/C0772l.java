package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.util.List;

/* renamed from: com.google.android.gms.wearable.internal.l */
public final class C0772l implements Creator<aw> {
    static void m4626a(aw awVar, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, awVar.f3849a);
        Security.m118c(parcel, 2, awVar.f3850b);
        Security.m61a(parcel, 3, awVar.f3851c);
        Security.m119c(parcel, 4, awVar.f3852d, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        long j = 0;
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    j = Security.m139i(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    list = Security.m117c(parcel, readInt, an.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new aw(i2, i, j, list);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new aw[i];
    }
}
