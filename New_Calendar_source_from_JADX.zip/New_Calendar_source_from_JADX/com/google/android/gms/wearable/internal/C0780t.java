package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.C0749c;

/* renamed from: com.google.android.gms.wearable.internal.t */
public class C0780t implements SafeParcelable {
    public static final Creator<C0780t> CREATOR;
    public final int f3872a;
    public final int f3873b;
    public final C0749c[] f3874c;

    static {
        CREATOR = new C0758E();
    }

    C0780t(int i, int i2, C0749c[] c0749cArr) {
        this.f3872a = i;
        this.f3873b = i2;
        this.f3874c = c0749cArr;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0758E.m4571a(this, parcel, i);
    }
}
