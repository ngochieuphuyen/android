package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.b */
public class C0762b implements SafeParcelable {
    public static final Creator<C0762b> CREATOR;
    final int f3853a;
    public final IntentFilter[] f3854b;
    private ae f3855c;

    static {
        CREATOR = new C0774n();
    }

    C0762b(int i, IBinder iBinder, IntentFilter[] intentFilterArr) {
        this.f3853a = i;
        if (iBinder != null) {
            this.f3855c = C0764d.m4616a(iBinder);
        } else {
            this.f3855c = null;
        }
        this.f3854b = intentFilterArr;
    }

    final IBinder m4614a() {
        return this.f3855c == null ? null : this.f3855c.asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0774n.m4628a(this, parcel, i);
    }
}
