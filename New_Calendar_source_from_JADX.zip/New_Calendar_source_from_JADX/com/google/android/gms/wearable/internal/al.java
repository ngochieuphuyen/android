package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.Node;

public class al implements SafeParcelable, Node {
    public static final Creator<al> CREATOR;
    final int f3834a;
    private final String f3835b;
    private final String f3836c;

    static {
        CREATOR = new C0767g();
    }

    al(int i, String str, String str2) {
        this.f3834a = i;
        this.f3835b = str;
        this.f3836c = str2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof al)) {
            return false;
        }
        al alVar = (al) obj;
        return alVar.f3835b.equals(this.f3835b) && alVar.f3836c.equals(this.f3836c);
    }

    public String getDisplayName() {
        return this.f3836c;
    }

    public String getId() {
        return this.f3835b;
    }

    public int hashCode() {
        return ((this.f3835b.hashCode() + 629) * 37) + this.f3836c.hashCode();
    }

    public String toString() {
        return "NodeParcelable{" + this.f3835b + "," + this.f3836c + "}";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0767g.m4621a(this, parcel);
    }
}
