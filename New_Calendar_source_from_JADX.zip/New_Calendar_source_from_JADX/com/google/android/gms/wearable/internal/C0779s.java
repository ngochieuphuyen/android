package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataItemAsset;

/* renamed from: com.google.android.gms.wearable.internal.s */
public final class C0779s implements DataItemAsset {
    private final String f3870a;
    private final String f3871b;

    public C0779s(DataItemAsset dataItemAsset) {
        this.f3870a = dataItemAsset.getId();
        this.f3871b = dataItemAsset.getDataItemKey();
    }

    public final /* synthetic */ Object freeze() {
        return this;
    }

    public final String getDataItemKey() {
        return this.f3871b;
    }

    public final String getId() {
        return this.f3870a;
    }

    public final boolean isDataValid() {
        return true;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.f3870a == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.f3870a);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.f3871b);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
