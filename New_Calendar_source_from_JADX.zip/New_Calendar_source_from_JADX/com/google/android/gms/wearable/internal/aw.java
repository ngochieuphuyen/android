package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class aw implements SafeParcelable {
    public static final Creator<aw> CREATOR;
    public final int f3849a;
    public final int f3850b;
    public final long f3851c;
    public final List<an> f3852d;

    static {
        CREATOR = new C0772l();
    }

    aw(int i, int i2, long j, List<an> list) {
        this.f3849a = i;
        this.f3850b = i2;
        this.f3851c = j;
        this.f3852d = list;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0772l.m4626a(this, parcel);
    }
}
