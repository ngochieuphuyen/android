package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class an implements SafeParcelable {
    public static final Creator<an> CREATOR;
    public final int f3837a;
    public final String f3838b;
    public final String f3839c;
    public final long f3840d;

    static {
        CREATOR = new C0768h();
    }

    an(int i, String str, String str2, long j) {
        this.f3837a = i;
        this.f3838b = str;
        this.f3839c = str2;
        this.f3840d = j;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0768h.m4622a(this, parcel);
    }
}
