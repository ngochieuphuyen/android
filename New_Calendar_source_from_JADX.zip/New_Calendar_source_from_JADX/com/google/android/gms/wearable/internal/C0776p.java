package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.p */
public class C0776p implements SafeParcelable {
    public static final Creator<C0776p> CREATOR;
    public final int f3863a;
    public final int f3864b;
    public final int f3865c;

    static {
        CREATOR = new C0756C();
    }

    C0776p(int i, int i2, int i3) {
        this.f3863a = i;
        this.f3864b = i2;
        this.f3865c = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0756C.m4569a(this, parcel);
    }
}
