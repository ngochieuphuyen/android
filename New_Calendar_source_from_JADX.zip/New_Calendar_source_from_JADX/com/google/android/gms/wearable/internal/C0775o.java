package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

/* renamed from: com.google.android.gms.wearable.internal.o */
public final class C0775o implements DataEvent {
    private int f3861a;
    private DataItem f3862b;

    public C0775o(DataEvent dataEvent) {
        this.f3861a = dataEvent.getType();
        this.f3862b = (DataItem) dataEvent.getDataItem().freeze();
    }

    public final /* synthetic */ Object freeze() {
        return this;
    }

    public final DataItem getDataItem() {
        return this.f3862b;
    }

    public final int getType() {
        return this.f3861a;
    }

    public final boolean isDataValid() {
        return true;
    }
}
