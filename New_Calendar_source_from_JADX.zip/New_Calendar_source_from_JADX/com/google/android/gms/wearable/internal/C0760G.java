package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.G */
public final class C0760G implements Creator<C0784x> {
    static void m4573a(C0784x c0784x, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, c0784x.f3878a);
        Security.m118c(parcel, 2, c0784x.f3879b);
        Security.m65a(parcel, 3, c0784x.f3880c, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        C0773m c0773m = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    c0773m = (C0773m) Security.m47a(parcel, readInt, C0773m.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new C0784x(i2, i, c0773m);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0784x[i];
    }
}
