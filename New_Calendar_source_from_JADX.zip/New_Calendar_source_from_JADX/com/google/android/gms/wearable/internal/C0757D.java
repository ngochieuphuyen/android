package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.android.gms.wearable.C0749c;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.D */
public final class C0757D implements Creator<C0778r> {
    static void m4570a(C0778r c0778r, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, c0778r.f3867a);
        Security.m118c(parcel, 2, c0778r.f3868b);
        Security.m65a(parcel, 3, c0778r.f3869c, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        int G = Security.m12G(parcel);
        C0749c c0749c = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    c0749c = (C0749c) Security.m47a(parcel, readInt, C0749c.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new C0778r(i2, i, c0749c);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0778r[i];
    }
}
