package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.util.Log;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.wearable.internal.y */
public final class C0785y implements DataItem {
    private Uri f3881a;
    private byte[] f3882b;
    private Map<String, DataItemAsset> f3883c;

    public C0785y(DataItem dataItem) {
        this.f3881a = dataItem.getUri();
        this.f3882b = dataItem.getData();
        Map hashMap = new HashMap();
        for (Entry entry : dataItem.getAssets().entrySet()) {
            if (entry.getKey() != null) {
                hashMap.put(entry.getKey(), ((DataItemAsset) entry.getValue()).freeze());
            }
        }
        this.f3883c = Collections.unmodifiableMap(hashMap);
    }

    public final /* synthetic */ Object freeze() {
        return this;
    }

    public final Map<String, DataItemAsset> getAssets() {
        return this.f3883c;
    }

    public final byte[] getData() {
        return this.f3882b;
    }

    public final Uri getUri() {
        return this.f3881a;
    }

    public final boolean isDataValid() {
        return true;
    }

    public final DataItem setData(byte[] bArr) {
        throw new UnsupportedOperationException();
    }

    public final String toString() {
        boolean isLoggable = Log.isLoggable("DataItem", 3);
        StringBuilder stringBuilder = new StringBuilder("DataItemEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        stringBuilder.append(",dataSz=" + (this.f3882b == null ? "null" : Integer.valueOf(this.f3882b.length)));
        stringBuilder.append(", numAssets=" + this.f3883c.size());
        stringBuilder.append(", uri=" + this.f3881a);
        if (isLoggable) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.f3883c.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.f3883c.get(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
