package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

/* renamed from: com.google.android.gms.wearable.internal.v */
public class C0782v implements SafeParcelable {
    public static final Creator<C0782v> CREATOR;
    public final int f3875a;
    public final int f3876b;
    public final List<al> f3877c;

    static {
        CREATOR = new C0759F();
    }

    C0782v(int i, int i2, List<al> list) {
        this.f3875a = i;
        this.f3876b = i2;
        this.f3877c = list;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0759F.m4572a(this, parcel);
    }
}
