package com.google.android.gms.wearable.internal;

import android.net.Uri;
import com.google.android.gms.common.data.C0092g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.wearable.internal.B */
public final class C0755B extends C0092g implements DataItem {
    private final int f3822c;

    public C0755B(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.f3822c = i2;
    }

    public final /* synthetic */ Object freeze() {
        return new C0785y(this);
    }

    public final Map<String, DataItemAsset> getAssets() {
        Map<String, DataItemAsset> hashMap = new HashMap(this.f3822c);
        for (int i = 0; i < this.f3822c; i++) {
            C0783w c0783w = new C0783w(this.a, this.b + i);
            if (c0783w.getDataItemKey() != null) {
                hashMap.put(c0783w.getDataItemKey(), c0783w);
            }
        }
        return hashMap;
    }

    public final byte[] getData() {
        return m961g("data");
    }

    public final Uri getUri() {
        return Uri.parse(m959e("path"));
    }

    public final DataItem setData(byte[] bArr) {
        throw new UnsupportedOperationException();
    }
}
