package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ap implements SafeParcelable {
    public static final Creator<ap> CREATOR;
    public final int f3841a;
    public final int f3842b;
    public final C0773m f3843c;

    static {
        CREATOR = new C0769i();
    }

    ap(int i, int i2, C0773m c0773m) {
        this.f3841a = i;
        this.f3842b = i2;
        this.f3843c = c0773m;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0769i.m4623a(this, parcel, i);
    }
}
