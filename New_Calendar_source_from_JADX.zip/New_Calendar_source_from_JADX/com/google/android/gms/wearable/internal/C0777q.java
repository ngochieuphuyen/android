package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.data.C0092g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

/* renamed from: com.google.android.gms.wearable.internal.q */
public final class C0777q extends C0092g implements DataEvent {
    private final int f3866c;

    public C0777q(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.f3866c = i2;
    }

    public final /* synthetic */ Object freeze() {
        return new C0775o(this);
    }

    public final DataItem getDataItem() {
        return new C0755B(this.a, this.b, this.f3866c);
    }

    public final int getType() {
        return m957c("event_type");
    }
}
