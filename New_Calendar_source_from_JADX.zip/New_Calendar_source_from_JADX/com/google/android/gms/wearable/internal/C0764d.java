package com.google.android.gms.wearable.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.common.data.C0163i;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.internal.d */
public abstract class C0764d extends Binder implements ae {
    public static ae m4616a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableListener");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof ae)) ? new C0765e(iBinder) : (ae) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        al alVar = null;
        switch (i) {
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                DataHolder a;
                parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                if (parcel.readInt() != 0) {
                    C0163i c0163i = DataHolder.CREATOR;
                    a = C0163i.m1144a(parcel);
                }
                aa(a);
                return true;
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                ai aiVar;
                parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                if (parcel.readInt() != 0) {
                    aiVar = (ai) ai.CREATOR.createFromParcel(parcel);
                }
                m4586a(aiVar);
                return true;
            case Error.BAD_CVC /*3*/:
                parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                if (parcel.readInt() != 0) {
                    alVar = (al) al.CREATOR.createFromParcel(parcel);
                }
                m4587a(alVar);
                return true;
            case Error.BAD_CARD /*4*/:
                parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                if (parcel.readInt() != 0) {
                    alVar = (al) al.CREATOR.createFromParcel(parcel);
                }
                m4588b(alVar);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.wearable.internal.IWearableListener");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
