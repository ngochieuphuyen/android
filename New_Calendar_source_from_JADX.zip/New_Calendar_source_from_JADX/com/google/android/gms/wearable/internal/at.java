package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class at implements SafeParcelable {
    public static final Creator<at> CREATOR;
    public final int f3846a;
    public final int f3847b;
    public final int f3848c;

    static {
        CREATOR = new C0771k();
    }

    at(int i, int i2, int i3) {
        this.f3846a = i;
        this.f3847b = i2;
        this.f3848c = i3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0771k.m4625a(this, parcel);
    }
}
