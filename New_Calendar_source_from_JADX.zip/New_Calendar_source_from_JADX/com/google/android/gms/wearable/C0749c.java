package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.C0477e;
import java.util.Arrays;

/* renamed from: com.google.android.gms.wearable.c */
public class C0749c implements SafeParcelable {
    public static final Creator<C0749c> CREATOR;
    final int f3814a;
    private final String f3815b;
    private final String f3816c;
    private final int f3817d;
    private final int f3818e;
    private final boolean f3819f;
    private boolean f3820g;
    private String f3821h;

    static {
        CREATOR = new C0751e();
    }

    C0749c(int i, String str, String str2, int i2, int i3, boolean z, boolean z2, String str3) {
        this.f3814a = i;
        this.f3815b = str;
        this.f3816c = str2;
        this.f3817d = i2;
        this.f3818e = i3;
        this.f3819f = z;
        this.f3820g = z2;
        this.f3821h = str3;
    }

    public final String m4558a() {
        return this.f3815b;
    }

    public final String m4559b() {
        return this.f3816c;
    }

    public final int m4560c() {
        return this.f3817d;
    }

    public final int m4561d() {
        return this.f3818e;
    }

    public int describeContents() {
        return 0;
    }

    public final boolean m4562e() {
        return this.f3820g;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0749c)) {
            return false;
        }
        C0749c c0749c = (C0749c) obj;
        return C0477e.m2759a(Integer.valueOf(this.f3814a), Integer.valueOf(c0749c.f3814a)) && C0477e.m2759a(this.f3815b, c0749c.f3815b) && C0477e.m2759a(this.f3816c, c0749c.f3816c) && C0477e.m2759a(Integer.valueOf(this.f3817d), Integer.valueOf(c0749c.f3817d)) && C0477e.m2759a(Integer.valueOf(this.f3818e), Integer.valueOf(c0749c.f3818e)) && C0477e.m2759a(Boolean.valueOf(this.f3819f), Boolean.valueOf(c0749c.f3819f));
    }

    public final String m4563f() {
        return this.f3821h;
    }

    public final boolean m4564g() {
        return this.f3819f;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f3814a), this.f3815b, this.f3816c, Integer.valueOf(this.f3817d), Integer.valueOf(this.f3818e), Boolean.valueOf(this.f3819f)});
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("ConnectionConfiguration[ ");
        stringBuilder.append("mName=" + this.f3815b);
        stringBuilder.append(", mAddress=" + this.f3816c);
        stringBuilder.append(", mType=" + this.f3817d);
        stringBuilder.append(", mRole=" + this.f3818e);
        stringBuilder.append(", mEnabled=" + this.f3819f);
        stringBuilder.append(", mIsConnected=" + this.f3820g);
        stringBuilder.append(", mEnabled=" + this.f3821h);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0751e.m4566a(this, parcel);
    }
}
