package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.C0164j;
import com.google.android.gms.wearable.internal.C0777q;

/* renamed from: com.google.android.gms.wearable.a */
public final class C0747a extends C0164j<DataEvent> implements Result {
    private final Status f3813b;

    protected final /* synthetic */ Object m4556a(int i, int i2) {
        return new C0777q(this.a, i, i2);
    }

    protected final String m4557b() {
        return "path";
    }

    public final Status getStatus() {
        return this.f3813b;
    }
}
