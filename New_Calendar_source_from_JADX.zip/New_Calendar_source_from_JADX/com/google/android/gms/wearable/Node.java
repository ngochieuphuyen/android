package com.google.android.gms.wearable;

public interface Node {
    String getDisplayName();

    String getId();
}
