package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.DataItemAssetParcelable;
import java.security.SecureRandom;

public class PutDataRequest implements SafeParcelable {
    public static final Creator<PutDataRequest> CREATOR;
    final int f3809a;
    private final Uri f3810b;
    private final Bundle f3811c;
    private byte[] f3812d;

    static {
        CREATOR = new C0753g();
        SecureRandom secureRandom = new SecureRandom();
    }

    PutDataRequest(int i, Uri uri, Bundle bundle, byte[] bArr) {
        this.f3809a = i;
        this.f3810b = uri;
        this.f3811c = bundle;
        this.f3811c.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        this.f3812d = bArr;
    }

    public final Uri m4553a() {
        return this.f3810b;
    }

    public final byte[] m4554b() {
        return this.f3812d;
    }

    public final Bundle m4555c() {
        return this.f3811c;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        boolean isLoggable = Log.isLoggable("DataMap", 3);
        StringBuilder stringBuilder = new StringBuilder("PutDataRequest[");
        stringBuilder.append("dataSz=" + (this.f3812d == null ? "null" : Integer.valueOf(this.f3812d.length)));
        stringBuilder.append(", numAssets=" + this.f3811c.size());
        stringBuilder.append(", uri=" + this.f3810b);
        if (isLoggable) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.f3811c.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.f3811c.getParcelable(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0753g.m4567a(this, parcel, i);
    }
}
