package com.google.android.gms.wearable;

/* renamed from: com.google.android.gms.wearable.f */
public interface C0752f {
}
