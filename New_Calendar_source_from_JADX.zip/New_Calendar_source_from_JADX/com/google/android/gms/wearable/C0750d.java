package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;

/* renamed from: com.google.android.gms.wearable.d */
public final class C0750d implements Creator<Asset> {
    static void m4565a(Asset asset, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, asset.f3804a);
        Security.m74a(parcel, 2, asset.m4551a(), false);
        Security.m69a(parcel, 3, asset.m4552b(), false);
        Security.m65a(parcel, 4, asset.f3805b, i, false);
        Security.m65a(parcel, 5, asset.f3806c, i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Uri uri = null;
        int G = Security.m12G(parcel);
        int i = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        String str = null;
        byte[] bArr = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    bArr = Security.m153r(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) Security.m47a(parcel, readInt, ParcelFileDescriptor.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    uri = (Uri) Security.m47a(parcel, readInt, Uri.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new Asset(i, bArr, str, parcelFileDescriptor, uri);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new Asset[i];
    }
}
