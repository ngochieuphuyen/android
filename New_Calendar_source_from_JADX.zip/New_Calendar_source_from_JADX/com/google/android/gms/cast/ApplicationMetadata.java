package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ApplicationMetadata implements SafeParcelable {
    public static final Creator<ApplicationMetadata> CREATOR;
    List<String> f402a;
    private final int f403b;
    private String f404c;
    private String f405d;
    private List<WebImage> f406e;
    private String f407f;
    private Uri f408g;

    static {
        CREATOR = new C0123x();
    }

    private ApplicationMetadata() {
        this.f403b = 1;
        this.f406e = new ArrayList();
        this.f402a = new ArrayList();
    }

    ApplicationMetadata(int i, String str, String str2, List<WebImage> list, List<String> list2, String str3, Uri uri) {
        this.f403b = i;
        this.f404c = str;
        this.f405d = str2;
        this.f406e = list;
        this.f402a = list2;
        this.f407f = str3;
        this.f408g = uri;
    }

    final int m967a() {
        return this.f403b;
    }

    public final String m968b() {
        return this.f404c;
    }

    public final String m969c() {
        return this.f405d;
    }

    public final String m970d() {
        return this.f407f;
    }

    public final int describeContents() {
        return 0;
    }

    public final Uri m971e() {
        return this.f408g;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationMetadata)) {
            return false;
        }
        ApplicationMetadata applicationMetadata = (ApplicationMetadata) obj;
        return Security.m96a(this.f404c, applicationMetadata.f404c) && Security.m96a(this.f406e, applicationMetadata.f406e) && Security.m96a(this.f405d, applicationMetadata.f405d) && Security.m96a(this.f402a, applicationMetadata.f402a) && Security.m96a(this.f407f, applicationMetadata.f407f) && Security.m96a(this.f408g, applicationMetadata.f408g);
    }

    public final List<WebImage> m972f() {
        return this.f406e;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f403b), this.f404c, this.f405d, this.f406e, this.f402a, this.f407f, this.f408g});
    }

    public final String toString() {
        return this.f405d;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0123x.m1037a(this, parcel, i);
    }
}
