package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.List;

/* renamed from: com.google.android.gms.cast.x */
public final class C0123x implements Creator<ApplicationMetadata> {
    static void m1037a(ApplicationMetadata applicationMetadata, Parcel parcel, int i) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, applicationMetadata.m967a());
        Security.m69a(parcel, 2, applicationMetadata.m968b(), false);
        Security.m69a(parcel, 3, applicationMetadata.m969c(), false);
        Security.m119c(parcel, 4, applicationMetadata.m972f(), false);
        Security.m108b(parcel, 5, applicationMetadata.f402a, false);
        Security.m69a(parcel, 6, applicationMetadata.m970d(), false);
        Security.m65a(parcel, 7, applicationMetadata.m971e(), i, false);
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Uri uri = null;
        int G = Security.m12G(parcel);
        int i = 0;
        String str = null;
        List list = null;
        List list2 = null;
        String str2 = null;
        String str3 = null;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    list2 = Security.m117c(parcel, readInt, WebImage.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    list = Security.m2C(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    uri = (Uri) Security.m47a(parcel, readInt, Uri.CREATOR);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new ApplicationMetadata(i, str3, str2, list2, list, str, uri);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ApplicationMetadata[i];
    }
}
