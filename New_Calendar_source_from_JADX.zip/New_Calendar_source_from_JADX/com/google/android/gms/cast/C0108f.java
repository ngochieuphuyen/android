package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.f */
final class C0108f extends C0105o {
    private /* synthetic */ String f444a;
    private /* synthetic */ String f445b;

    C0108f(C0098b c0098b, GoogleApiClient googleApiClient, String str, String str2) {
        this.f444a = str;
        this.f445b = str2;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m1018a(C0127a c0127a) {
        try {
            ((fP) c0127a).m3057b(this.f444a, this.f445b, this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
