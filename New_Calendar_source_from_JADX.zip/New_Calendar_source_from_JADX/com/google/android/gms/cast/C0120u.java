package com.google.android.gms.cast;

import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.u */
public final class C0120u {
    private long f467a;
    private double f468b;
    private int f469c;
    private int f470d;
    private long f471e;
    private long f472f;
    private double f473g;
    private boolean f474h;
    private long[] f475i;

    public C0120u(JSONObject jSONObject) {
        m1033a(jSONObject, 0);
    }

    public final int m1033a(JSONObject jSONObject, int i) {
        int i2;
        double d;
        long j;
        long[] jArr;
        int i3 = 2;
        Object obj = null;
        Object obj2 = 1;
        long j2 = jSONObject.getLong("mediaSessionId");
        if (j2 != this.f467a) {
            this.f467a = j2;
            i2 = 1;
        } else {
            i2 = 0;
        }
        if (jSONObject.has("playerState")) {
            String string = jSONObject.getString("playerState");
            int i4 = string.equals("IDLE") ? 1 : string.equals("PLAYING") ? 2 : string.equals("PAUSED") ? 3 : string.equals("BUFFERING") ? 4 : 0;
            if (i4 != this.f469c) {
                this.f469c = i4;
                i2 |= 2;
            }
            if (i4 == 1 && jSONObject.has("idleReason")) {
                string = jSONObject.getString("idleReason");
                if (!string.equals("CANCELLED")) {
                    i3 = string.equals("INTERRUPTED") ? 3 : string.equals("FINISHED") ? 1 : string.equals("ERROR") ? 4 : 0;
                }
                if (i3 != this.f470d) {
                    this.f470d = i3;
                    i2 |= 2;
                }
            }
        }
        if (jSONObject.has("playbackRate")) {
            d = jSONObject.getDouble("playbackRate");
            if (this.f468b != d) {
                this.f468b = d;
                i2 |= 2;
            }
        }
        if (jSONObject.has("currentTime") && (i & 2) == 0) {
            j = (long) (jSONObject.getDouble("currentTime") * 1000.0d);
            if (j != this.f471e) {
                this.f471e = j;
                i2 |= 2;
            }
        }
        if (jSONObject.has("supportedMediaCommands")) {
            j = jSONObject.getLong("supportedMediaCommands");
            if (j != this.f472f) {
                this.f472f = j;
                i2 |= 2;
            }
        }
        if (jSONObject.has("volume") && (i & 1) == 0) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("volume");
            d = jSONObject2.getDouble("level");
            if (d != this.f473g) {
                this.f473g = d;
                i2 |= 2;
            }
            boolean z = jSONObject2.getBoolean("muted");
            if (z != this.f474h) {
                this.f474h = z;
                i2 |= 2;
            }
        }
        if (jSONObject.has("activeTrackIds")) {
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            long[] jArr2 = new long[length];
            for (i3 = 0; i3 < length; i3++) {
                jArr2[i3] = jSONArray.getLong(i3);
            }
            if (this.f475i != null && this.f475i.length == length) {
                for (i3 = 0; i3 < length; i3++) {
                    if (this.f475i[i3] != jArr2[i3]) {
                        break;
                    }
                }
                obj2 = null;
            }
            if (obj2 != null) {
                this.f475i = jArr2;
            }
            obj = obj2;
            jArr = jArr2;
        } else if (this.f475i != null) {
            int i5 = 1;
            jArr = null;
        } else {
            jArr = null;
        }
        if (obj != null) {
            this.f475i = jArr;
            i2 |= 2;
        }
        if (jSONObject.has("customData")) {
            jSONObject.getJSONObject("customData");
            i2 |= 2;
        }
        if (!jSONObject.has("media")) {
            return i2;
        }
        JSONObject jSONObject3 = jSONObject.getJSONObject("media");
        C0117r c0117r = new C0117r(jSONObject3);
        i2 |= 2;
        return jSONObject3.has("metadata") ? i2 | 4 : i2;
    }
}
