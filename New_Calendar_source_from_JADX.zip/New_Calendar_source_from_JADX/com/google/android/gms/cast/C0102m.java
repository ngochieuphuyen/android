package com.google.android.gms.cast;

import com.google.android.gms.common.api.C0101e;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.m */
public abstract class C0102m<R extends Result> extends C0101e<R, fP> {
    public C0102m(GoogleApiClient googleApiClient) {
        super(Cast.f409a, googleApiClient);
    }

    public final void m1011a(int i) {
        m999a(m996a(new Status(2001)));
    }

    public final void m1012a(int i, String str) {
        m999a(m996a(new Status(2001, str, null)));
    }
}
