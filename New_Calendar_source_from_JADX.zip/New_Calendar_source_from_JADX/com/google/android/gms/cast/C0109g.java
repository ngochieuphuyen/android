package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.g */
final class C0109g extends C0105o {
    private /* synthetic */ String f446a;

    C0109g(C0098b c0098b, GoogleApiClient googleApiClient, String str) {
        this.f446a = str;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m1019a(C0127a c0127a) {
        try {
            ((fP) c0127a).m3057b(this.f446a, null, this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
