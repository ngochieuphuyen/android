package com.google.android.gms.cast;

import android.support.v4.p000a.Security;
import com.google.android.gms.internal.hz;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.r */
public final class C0117r {
    private final String f453a;
    private int f454b;
    private String f455c;
    private C0118s f456d;
    private long f457e;
    private List<C0121v> f458f;
    private JSONObject f459g;

    C0117r(JSONObject jSONObject) {
        int i = 0;
        this.f453a = jSONObject.getString("contentId");
        String string = jSONObject.getString("streamType");
        if ("NONE".equals(string)) {
            this.f454b = 0;
        } else if ("BUFFERED".equals(string)) {
            this.f454b = 1;
        } else if ("LIVE".equals(string)) {
            this.f454b = 2;
        } else {
            this.f454b = -1;
        }
        this.f455c = jSONObject.getString("contentType");
        if (jSONObject.has("metadata")) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("metadata");
            this.f456d = new C0118s(jSONObject2.getInt("metadataType"));
            this.f456d.m1029a(jSONObject2);
        }
        this.f457e = -1;
        if (jSONObject.has("duration") && !jSONObject.isNull("duration")) {
            double optDouble = jSONObject.optDouble("duration", 0.0d);
            if (!(Double.isNaN(optDouble) || Double.isInfinite(optDouble))) {
                this.f457e = (long) (optDouble * 1000.0d);
            }
        }
        if (jSONObject.has("tracks")) {
            this.f458f = new ArrayList();
            JSONArray jSONArray = jSONObject.getJSONArray("tracks");
            while (i < jSONArray.length()) {
                this.f458f.add(new C0121v(jSONArray.getJSONObject(i)));
                i++;
            }
        } else {
            this.f458f = null;
        }
        if (jSONObject.has("textTrackStyle")) {
            new C0122w().m1036a(jSONObject.getJSONObject("textTrackStyle"));
        }
        this.f459g = jSONObject.optJSONObject("customData");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0117r)) {
            return false;
        }
        C0117r c0117r = (C0117r) obj;
        return (this.f459g == null) == (c0117r.f459g == null) ? (this.f459g == null || c0117r.f459g == null || hz.m3355a(this.f459g, c0117r.f459g)) && Security.m96a(this.f453a, c0117r.f453a) && this.f454b == c0117r.f454b && Security.m96a(this.f455c, c0117r.f455c) && Security.m96a(this.f456d, c0117r.f456d) && this.f457e == c0117r.f457e : false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f453a, Integer.valueOf(this.f454b), this.f455c, this.f456d, Long.valueOf(this.f457e), String.valueOf(this.f459g)});
    }
}
