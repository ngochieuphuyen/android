package com.google.android.gms.cast;

import android.support.v4.p000a.Security;
import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;

/* renamed from: com.google.android.gms.cast.l */
public final class C0114l implements HasOptions {
    final CastDevice f448a;
    final Security f449b;
    private final int f450c;
}
