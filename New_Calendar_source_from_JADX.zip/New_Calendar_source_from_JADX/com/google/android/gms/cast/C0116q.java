package com.google.android.gms.cast;

/* renamed from: com.google.android.gms.cast.q */
public final class C0116q {
    private LaunchOptions f452a;

    public C0116q() {
        this.f452a = new LaunchOptions();
    }

    public final LaunchOptions m1025a() {
        return this.f452a;
    }

    public final C0116q m1026a(boolean z) {
        this.f452a.m984a(z);
        return this;
    }
}
