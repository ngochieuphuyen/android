package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.h */
final class C0110h extends C0105o {
    C0110h(C0098b c0098b, GoogleApiClient googleApiClient) {
        super(googleApiClient);
    }

    protected final /* synthetic */ void m1020a(C0127a c0127a) {
        try {
            ((fP) c0127a).m3057b(null, null, this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
