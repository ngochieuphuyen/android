package com.google.android.gms.cast;

import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.cast.t */
final class C0119t {
    private final Map<String, String> f464a;
    private final Map<String, String> f465b;
    private final Map<String, Integer> f466c;

    public C0119t() {
        this.f464a = new HashMap();
        this.f465b = new HashMap();
        this.f466c = new HashMap();
    }

    public final C0119t m1030a(String str, String str2, int i) {
        this.f464a.put(str, str2);
        this.f465b.put(str2, str);
        this.f466c.put(str, Integer.valueOf(i));
        return this;
    }

    public final String m1031a(String str) {
        return (String) this.f465b.get(str);
    }

    public final int m1032b(String str) {
        Integer num = (Integer) this.f466c.get(str);
        return num != null ? num.intValue() : 0;
    }
}
