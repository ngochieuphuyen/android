package com.google.android.gms.cast;

import android.os.RemoteException;
import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.cast.Cast.CastApi;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.fP;
import java.io.IOException;

/* renamed from: com.google.android.gms.cast.b */
public final class C0098b implements CastApi {
    public final ApplicationMetadata getApplicationMetadata(GoogleApiClient googleApiClient) {
        return ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3061f();
    }

    public final String getApplicationStatus(GoogleApiClient googleApiClient) {
        return ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3062g();
    }

    public final double getVolume(GoogleApiClient googleApiClient) {
        return ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3059d();
    }

    public final boolean isMute(GoogleApiClient googleApiClient) {
        return ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3060e();
    }

    public final PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient) {
        return googleApiClient.m1051b(new C0110h(this, googleApiClient));
    }

    public final PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str) {
        return googleApiClient.m1051b(new C0109g(this, googleApiClient, str));
    }

    public final PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str, String str2) {
        return googleApiClient.m1051b(new C0108f(this, googleApiClient, str, str2));
    }

    public final PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str) {
        return googleApiClient.m1051b(new C0106d(this, googleApiClient, str));
    }

    public final PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, LaunchOptions launchOptions) {
        return googleApiClient.m1051b(new C0107e(this, googleApiClient, str, launchOptions));
    }

    @Deprecated
    public final PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, boolean z) {
        return launchApplication(googleApiClient, str, new C0116q().m1026a(z).m1025a());
    }

    public final PendingResult<Status> leaveApplication(GoogleApiClient googleApiClient) {
        return googleApiClient.m1051b(new C0111i(this, googleApiClient));
    }

    public final void removeMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str) {
        try {
            ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3049a(str);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    public final void requestStatus(GoogleApiClient googleApiClient) {
        try {
            ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3058c();
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    public final PendingResult<Status> sendMessage(GoogleApiClient googleApiClient, String str, String str2) {
        return googleApiClient.m1051b(new C0104c(this, googleApiClient, str, str2));
    }

    public final void setMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str, MessageReceivedCallback messageReceivedCallback) {
        try {
            ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3050a(str, messageReceivedCallback);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    public final void setMute(GoogleApiClient googleApiClient, boolean z) {
        try {
            ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3055a(z);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    public final void setVolume(GoogleApiClient googleApiClient, double d) {
        try {
            ((fP) googleApiClient.a$653aaecb(Cast.f409a)).m3045a(d);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    public final PendingResult<Status> stopApplication(GoogleApiClient googleApiClient) {
        return googleApiClient.m1051b(new C0112j(this, googleApiClient));
    }

    public final PendingResult<Status> stopApplication(GoogleApiClient googleApiClient, String str) {
        return googleApiClient.m1051b(new C0113k(this, googleApiClient, str));
    }
}
