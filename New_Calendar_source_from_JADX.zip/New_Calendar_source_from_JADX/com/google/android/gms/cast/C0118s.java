package com.google.android.gms.cast;

import android.os.Bundle;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.internal.gf;
import com.google.android.gms.wallet.LineItem.Role;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.s */
public final class C0118s {
    private static final C0119t f460a;
    private final List<WebImage> f461b;
    private final Bundle f462c;
    private int f463d;

    static {
        String[] strArr = new String[]{null, "String", "int", "double", "ISO-8601 date String"};
        f460a = new C0119t().m1030a("com.google.android.gms.cast.metadata.CREATION_DATE", "creationDateTime", 4).m1030a("com.google.android.gms.cast.metadata.RELEASE_DATE", "releaseDate", 4).m1030a("com.google.android.gms.cast.metadata.BROADCAST_DATE", "originalAirdate", 4).m1030a("com.google.android.gms.cast.metadata.TITLE", "title", 1).m1030a("com.google.android.gms.cast.metadata.SUBTITLE", "subtitle", 1).m1030a("com.google.android.gms.cast.metadata.ARTIST", "artist", 1).m1030a("com.google.android.gms.cast.metadata.ALBUM_ARTIST", "albumArtist", 1).m1030a("com.google.android.gms.cast.metadata.ALBUM_TITLE", "albumName", 1).m1030a("com.google.android.gms.cast.metadata.COMPOSER", "composer", 1).m1030a("com.google.android.gms.cast.metadata.DISC_NUMBER", "discNumber", 2).m1030a("com.google.android.gms.cast.metadata.TRACK_NUMBER", "trackNumber", 2).m1030a("com.google.android.gms.cast.metadata.SEASON_NUMBER", "season", 2).m1030a("com.google.android.gms.cast.metadata.EPISODE_NUMBER", "episode", 2).m1030a("com.google.android.gms.cast.metadata.SERIES_TITLE", "seriesTitle", 1).m1030a("com.google.android.gms.cast.metadata.STUDIO", "studio", 1).m1030a("com.google.android.gms.cast.metadata.WIDTH", "width", 2).m1030a("com.google.android.gms.cast.metadata.HEIGHT", "height", 2).m1030a("com.google.android.gms.cast.metadata.LOCATION_NAME", "location", 1).m1030a("com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "latitude", 3).m1030a("com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "longitude", 3);
    }

    public C0118s() {
        this(0);
    }

    public C0118s(int i) {
        this.f461b = new ArrayList();
        this.f462c = new Bundle();
        this.f463d = i;
    }

    private void m1027a(JSONObject jSONObject, String... strArr) {
        Set hashSet = new HashSet(Arrays.asList(strArr));
        try {
            Iterator keys = jSONObject.keys();
            while (keys.hasNext()) {
                String str = (String) keys.next();
                if (!"metadataType".equals(str)) {
                    String a = f460a.m1031a(str);
                    if (a == null) {
                        Object obj = jSONObject.get(str);
                        if (obj instanceof String) {
                            this.f462c.putString(str, (String) obj);
                        } else if (obj instanceof Integer) {
                            this.f462c.putInt(str, ((Integer) obj).intValue());
                        } else if (obj instanceof Double) {
                            this.f462c.putDouble(str, ((Double) obj).doubleValue());
                        }
                    } else if (hashSet.contains(a)) {
                        try {
                            Object obj2 = jSONObject.get(str);
                            if (obj2 != null) {
                                switch (f460a.m1032b(a)) {
                                    case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                                        if (!(obj2 instanceof String)) {
                                            break;
                                        }
                                        this.f462c.putString(a, (String) obj2);
                                        break;
                                    case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                                        if (!(obj2 instanceof Integer)) {
                                            break;
                                        }
                                        this.f462c.putInt(a, ((Integer) obj2).intValue());
                                        break;
                                    case Error.BAD_CVC /*3*/:
                                        if (!(obj2 instanceof Double)) {
                                            break;
                                        }
                                        this.f462c.putDouble(a, ((Double) obj2).doubleValue());
                                        break;
                                    case Error.BAD_CARD /*4*/:
                                        if (!(obj2 instanceof String)) {
                                            break;
                                        }
                                        if (gf.m3282a((String) obj2) == null) {
                                            break;
                                        }
                                        this.f462c.putString(a, (String) obj2);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        } catch (JSONException e) {
                        }
                    }
                }
            }
        } catch (JSONException e2) {
        }
    }

    private boolean m1028a(Bundle bundle, Bundle bundle2) {
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            Object obj2 = bundle2.get(str);
            if ((obj instanceof Bundle) && (obj2 instanceof Bundle) && !m1028a((Bundle) obj, (Bundle) obj2)) {
                return false;
            }
            if (obj == null) {
                if (obj2 != null || !bundle2.containsKey(str)) {
                    return false;
                }
            } else if (!obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    public final void m1029a(JSONObject jSONObject) {
        this.f462c.clear();
        this.f461b.clear();
        this.f463d = 0;
        try {
            this.f463d = jSONObject.getInt("metadataType");
        } catch (JSONException e) {
        }
        gf.m3283a(this.f461b, jSONObject);
        switch (this.f463d) {
            case Role.REGULAR /*0*/:
                m1027a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
            case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                m1027a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
            case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                m1027a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE");
            case Error.BAD_CVC /*3*/:
                m1027a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE");
            case Error.BAD_CARD /*4*/:
                m1027a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE");
            default:
                m1027a(jSONObject, new String[0]);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0118s)) {
            return false;
        }
        C0118s c0118s = (C0118s) obj;
        return m1028a(this.f462c, c0118s.f462c) && this.f461b.equals(c0118s.f461b);
    }

    public final int hashCode() {
        int i = 17;
        for (String str : this.f462c.keySet()) {
            i *= 31;
            i = this.f462c.get(str).hashCode() + i;
        }
        return (i * 31) + this.f461b.hashCode();
    }
}
