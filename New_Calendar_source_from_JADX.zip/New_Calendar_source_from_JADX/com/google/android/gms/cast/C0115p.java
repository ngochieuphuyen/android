package com.google.android.gms.cast;

import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.p */
final class C0115p implements ApplicationConnectionResult {
    private /* synthetic */ Status f451a;

    C0115p(C0105o c0105o, Status status) {
        this.f451a = status;
    }

    public final ApplicationMetadata getApplicationMetadata() {
        return null;
    }

    public final String getApplicationStatus() {
        return null;
    }

    public final String getSessionId() {
        return null;
    }

    public final Status getStatus() {
        return this.f451a;
    }

    public final boolean getWasLaunched() {
        return false;
    }
}
