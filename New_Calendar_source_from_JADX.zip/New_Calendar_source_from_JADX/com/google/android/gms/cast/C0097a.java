package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import android.support.v4.p003c.LunarUtil;
import com.google.android.gms.common.api.Api.C0089b;
import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.internal.fP;
import com.google.android.gms.internal.jg;

/* renamed from: com.google.android.gms.cast.a */
final class C0097a implements C0089b<fP, C0114l> {
    C0097a() {
    }

    public final /* synthetic */ C0127a m987a(Context context, Looper looper, jg jgVar, Object obj, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        obj = (C0114l) obj;
        LunarUtil.m183a(obj, (Object) "Setting the API options is required.");
        return new fP(context, looper, obj.f448a, (long) obj.f450c, obj.f449b, connectionCallbacks, onConnectionFailedListener);
    }

    public final int getPriority() {
        return ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    }
}
