package com.google.android.gms.cast;

import android.support.v4.p000a.Security;
import com.google.android.gms.internal.hz;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.v */
public final class C0121v {
    private long f476a;
    private int f477b;
    private String f478c;
    private String f479d;
    private String f480e;
    private String f481f;
    private int f482g;
    private JSONObject f483h;

    C0121v(JSONObject jSONObject) {
        this.f476a = 0;
        this.f477b = 0;
        this.f478c = null;
        this.f480e = null;
        this.f481f = null;
        this.f482g = -1;
        this.f483h = null;
        this.f476a = jSONObject.getLong("trackId");
        String string = jSONObject.getString("type");
        if ("TEXT".equals(string)) {
            this.f477b = 1;
        } else if ("AUDIO".equals(string)) {
            this.f477b = 2;
        } else if ("VIDEO".equals(string)) {
            this.f477b = 3;
        } else {
            throw new JSONException("invalid type: " + string);
        }
        this.f478c = jSONObject.optString("trackContentId", null);
        this.f479d = jSONObject.optString("trackContentType", null);
        this.f480e = jSONObject.optString("name", null);
        this.f481f = jSONObject.optString("language", null);
        if (jSONObject.has("subtype")) {
            string = jSONObject.getString("subtype");
            if ("SUBTITLES".equals(string)) {
                this.f482g = 1;
            } else if ("CAPTIONS".equals(string)) {
                this.f482g = 2;
            } else if ("DESCRIPTIONS".equals(string)) {
                this.f482g = 3;
            } else if ("CHAPTERS".equals(string)) {
                this.f482g = 4;
            } else if ("METADATA".equals(string)) {
                this.f482g = 5;
            } else {
                throw new JSONException("invalid subtype: " + string);
            }
        }
        this.f482g = 0;
        this.f483h = jSONObject.optJSONObject("customData");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0121v)) {
            return false;
        }
        C0121v c0121v = (C0121v) obj;
        return (this.f483h == null) == (c0121v.f483h == null) ? (this.f483h == null || c0121v.f483h == null || hz.m3355a(this.f483h, c0121v.f483h)) && this.f476a == c0121v.f476a && this.f477b == c0121v.f477b && Security.m96a(this.f478c, c0121v.f478c) && Security.m96a(this.f479d, c0121v.f479d) && Security.m96a(this.f480e, c0121v.f480e) && Security.m96a(this.f481f, c0121v.f481f) && this.f482g == c0121v.f482g : false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f476a), Integer.valueOf(this.f477b), this.f478c, this.f479d, this.f480e, this.f481f, Integer.valueOf(this.f482g), this.f483h});
    }
}
