package com.google.android.gms.cast;

import android.graphics.Color;
import android.support.v4.p000a.Security;
import com.google.android.gms.internal.hz;
import java.util.Arrays;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.w */
public final class C0122w {
    private float f484a;
    private int f485b;
    private int f486c;
    private int f487d;
    private int f488e;
    private int f489f;
    private int f490g;
    private int f491h;
    private String f492i;
    private int f493j;
    private int f494k;
    private JSONObject f495l;

    public C0122w() {
        m1035a();
    }

    private static int m1034a(String str) {
        int i = 0;
        if (str != null && str.length() == 9 && str.charAt(i) == '#') {
            try {
                i = Color.argb(Integer.parseInt(str.substring(7, 9), 16), Integer.parseInt(str.substring(1, 3), 16), Integer.parseInt(str.substring(3, 5), 16), Integer.parseInt(str.substring(5, 7), 16));
            } catch (NumberFormatException e) {
            }
        }
        return i;
    }

    private void m1035a() {
        this.f484a = 1.0f;
        this.f485b = 0;
        this.f486c = 0;
        this.f487d = -1;
        this.f488e = 0;
        this.f489f = -1;
        this.f490g = 0;
        this.f491h = 0;
        this.f492i = null;
        this.f493j = -1;
        this.f494k = -1;
        this.f495l = null;
    }

    public final void m1036a(JSONObject jSONObject) {
        String string;
        m1035a();
        this.f484a = (float) jSONObject.optDouble("fontScale", 1.0d);
        this.f485b = C0122w.m1034a(jSONObject.optString("foregroundColor"));
        this.f486c = C0122w.m1034a(jSONObject.optString("backgroundColor"));
        if (jSONObject.has("edgeType")) {
            string = jSONObject.getString("edgeType");
            if ("NONE".equals(string)) {
                this.f487d = 0;
            } else if ("OUTLINE".equals(string)) {
                this.f487d = 1;
            } else if ("DROP_SHADOW".equals(string)) {
                this.f487d = 2;
            } else if ("RAISED".equals(string)) {
                this.f487d = 3;
            } else if ("DEPRESSED".equals(string)) {
                this.f487d = 4;
            }
        }
        this.f488e = C0122w.m1034a(jSONObject.optString("edgeColor"));
        if (jSONObject.has("windowType")) {
            string = jSONObject.getString("windowType");
            if ("NONE".equals(string)) {
                this.f489f = 0;
            } else if ("NORMAL".equals(string)) {
                this.f489f = 1;
            } else if ("ROUNDED_CORNERS".equals(string)) {
                this.f489f = 2;
            }
        }
        this.f490g = C0122w.m1034a(jSONObject.optString("windowColor"));
        if (this.f489f == 2) {
            this.f491h = jSONObject.optInt("windowRoundedCornerRadius", 0);
        }
        this.f492i = jSONObject.optString("fontFamily", null);
        if (jSONObject.has("fontGenericFamily")) {
            string = jSONObject.getString("fontGenericFamily");
            if ("SANS_SERIF".equals(string)) {
                this.f493j = 0;
            } else if ("MONOSPACED_SANS_SERIF".equals(string)) {
                this.f493j = 1;
            } else if ("SERIF".equals(string)) {
                this.f493j = 2;
            } else if ("MONOSPACED_SERIF".equals(string)) {
                this.f493j = 3;
            } else if ("CASUAL".equals(string)) {
                this.f493j = 4;
            } else if ("CURSIVE".equals(string)) {
                this.f493j = 5;
            } else if ("SMALL_CAPITALS".equals(string)) {
                this.f493j = 6;
            }
        }
        if (jSONObject.has("fontStyle")) {
            string = jSONObject.getString("fontStyle");
            if ("NORMAL".equals(string)) {
                this.f494k = 0;
            } else if ("BOLD".equals(string)) {
                this.f494k = 1;
            } else if ("ITALIC".equals(string)) {
                this.f494k = 2;
            } else if ("BOLD_ITALIC".equals(string)) {
                this.f494k = 3;
            }
        }
        this.f495l = jSONObject.optJSONObject("customData");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0122w)) {
            return false;
        }
        C0122w c0122w = (C0122w) obj;
        return (this.f495l == null) == (c0122w.f495l == null) ? (this.f495l == null || c0122w.f495l == null || hz.m3355a(this.f495l, c0122w.f495l)) && this.f484a == c0122w.f484a && this.f485b == c0122w.f485b && this.f486c == c0122w.f486c && this.f487d == c0122w.f487d && this.f488e == c0122w.f488e && this.f489f == c0122w.f489f && this.f491h == c0122w.f491h && Security.m96a(this.f492i, c0122w.f492i) && this.f493j == c0122w.f493j && this.f494k == c0122w.f494k : false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f484a), Integer.valueOf(this.f485b), Integer.valueOf(this.f486c), Integer.valueOf(this.f487d), Integer.valueOf(this.f488e), Integer.valueOf(this.f489f), Integer.valueOf(this.f490g), Integer.valueOf(this.f491h), this.f492i, Integer.valueOf(this.f493j), Integer.valueOf(this.f494k), this.f495l});
    }
}
