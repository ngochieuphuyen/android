package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.support.v7.appcompat.C0015R;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.CacheLoader;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.code.yadview.EventResource;
import info.kfsoft.calendar.YearActivity;
import java.util.List;

/* renamed from: com.google.android.gms.cast.y */
public final class C0124y implements Creator<CastDevice> {
    static void m1038a(CastDevice castDevice, Parcel parcel) {
        int H = Security.m15H(parcel);
        Security.m118c(parcel, 1, castDevice.m973a());
        Security.m69a(parcel, 2, castDevice.m975b(), false);
        Security.m69a(parcel, 3, castDevice.f411a, false);
        Security.m69a(parcel, 4, castDevice.m976c(), false);
        Security.m69a(parcel, 5, castDevice.m977d(), false);
        Security.m69a(parcel, 6, castDevice.m978e(), false);
        Security.m118c(parcel, 7, castDevice.m979f());
        Security.m119c(parcel, 8, castDevice.m980g(), false);
        Security.m118c(parcel, 9, castDevice.m981h());
        Security.m118c(parcel, 10, castDevice.m982i());
        Security.m17H(parcel, H);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        List list = null;
        int G = Security.m12G(parcel);
        int i2 = 0;
        int i3 = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        int i4 = 0;
        while (parcel.dataPosition() < G) {
            int readInt = parcel.readInt();
            switch (GameRequest.TYPE_ALL & readInt) {
                case EventResource.ACCESS_LEVEL_DELETE /*1*/:
                    i4 = Security.m136g(parcel, readInt);
                    break;
                case EventResource.ACCESS_LEVEL_EDIT /*2*/:
                    str5 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CVC /*3*/:
                    str4 = Security.m148o(parcel, readInt);
                    break;
                case Error.BAD_CARD /*4*/:
                    str3 = Security.m148o(parcel, readInt);
                    break;
                case Error.DECLINED /*5*/:
                    str2 = Security.m148o(parcel, readInt);
                    break;
                case YearActivity.MAX_CAL_BOX_SUPPORTED /*6*/:
                    str = Security.m148o(parcel, readInt);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i3 = Security.m136g(parcel, readInt);
                    break;
                case Error.FRAUD_DECLINE /*8*/:
                    list = Security.m117c(parcel, readInt, WebImage.CREATOR);
                    break;
                case C0015R.styleable.Spinner_disableChildrenWhenDisabled /*9*/:
                    i2 = Security.m136g(parcel, readInt);
                    break;
                case C0015R.styleable.MenuItem_android_numericShortcut /*10*/:
                    i = Security.m136g(parcel, readInt);
                    break;
                default:
                    Security.m106b(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new CastDevice(i4, str5, str4, str3, str2, str, i3, list, i2, i);
        }
        throw new CacheLoader("Overread allowed size end=" + G, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new CastDevice[i];
    }
}
