package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.e */
final class C0107e extends C0105o {
    private /* synthetic */ String f442a;
    private /* synthetic */ LaunchOptions f443b;

    C0107e(C0098b c0098b, GoogleApiClient googleApiClient, String str, LaunchOptions launchOptions) {
        this.f442a = str;
        this.f443b = launchOptions;
        super(googleApiClient);
    }

    protected final /* bridge */ /* synthetic */ void m1017a(C0127a c0127a) {
        try {
            ((fP) c0127a).m3051a(this.f442a, this.f443b, (BaseImplementation$b) this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
