package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastDevice implements SafeParcelable {
    public static final Creator<CastDevice> CREATOR;
    String f411a;
    private final int f412b;
    private String f413c;
    private Inet4Address f414d;
    private String f415e;
    private String f416f;
    private String f417g;
    private int f418h;
    private List<WebImage> f419i;
    private int f420j;
    private int f421k;

    static {
        CREATOR = new C0124y();
    }

    private CastDevice() {
        this(3, null, null, null, null, null, -1, new ArrayList(), 0, -1);
    }

    CastDevice(int i, String str, String str2, String str3, String str4, String str5, int i2, List<WebImage> list, int i3, int i4) {
        this.f412b = i;
        this.f413c = str;
        this.f411a = str2;
        if (this.f411a != null) {
            try {
                InetAddress byName = InetAddress.getByName(this.f411a);
                if (byName instanceof Inet4Address) {
                    this.f414d = (Inet4Address) byName;
                }
            } catch (UnknownHostException e) {
                this.f414d = null;
            }
        }
        this.f415e = str3;
        this.f416f = str4;
        this.f417g = str5;
        this.f418h = i2;
        this.f419i = list;
        this.f420j = i3;
        this.f421k = i4;
    }

    final int m973a() {
        return this.f412b;
    }

    public final void m974a(Bundle bundle) {
        if (bundle != null) {
            bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", this);
        }
    }

    public final String m975b() {
        return this.f413c;
    }

    public final String m976c() {
        return this.f415e;
    }

    public final String m977d() {
        return this.f416f;
    }

    public int describeContents() {
        return 0;
    }

    public final String m978e() {
        return this.f417g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CastDevice)) {
            return false;
        }
        CastDevice castDevice = (CastDevice) obj;
        return this.f413c == null ? castDevice.f413c == null : Security.m96a(this.f413c, castDevice.f413c) && Security.m96a(this.f414d, castDevice.f414d) && Security.m96a(this.f416f, castDevice.f416f) && Security.m96a(this.f415e, castDevice.f415e) && Security.m96a(this.f417g, castDevice.f417g) && this.f418h == castDevice.f418h && Security.m96a(this.f419i, castDevice.f419i) && this.f420j == castDevice.f420j && this.f421k == castDevice.f421k;
    }

    public final int m979f() {
        return this.f418h;
    }

    public final List<WebImage> m980g() {
        return Collections.unmodifiableList(this.f419i);
    }

    public final int m981h() {
        return this.f420j;
    }

    public int hashCode() {
        return this.f413c == null ? 0 : this.f413c.hashCode();
    }

    public final int m982i() {
        return this.f421k;
    }

    public String toString() {
        return String.format("\"%s\" (%s)", new Object[]{this.f415e, this.f413c});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0124y.m1038a(this, parcel);
    }
}
