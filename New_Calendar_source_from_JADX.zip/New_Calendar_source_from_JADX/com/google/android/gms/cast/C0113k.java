package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.k */
final class C0113k extends C0103n {
    private /* synthetic */ String f447a;

    C0113k(C0098b c0098b, GoogleApiClient googleApiClient, String str) {
        this.f447a = str;
        super(googleApiClient);
    }

    protected final /* synthetic */ void m1023a(C0127a c0127a) {
        fP fPVar = (fP) c0127a;
        if (TextUtils.isEmpty(this.f447a)) {
            m1012a(2001, "IllegalArgument: sessionId cannot be null or empty");
            return;
        }
        try {
            fPVar.m3052a(this.f447a, (BaseImplementation$b) this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
