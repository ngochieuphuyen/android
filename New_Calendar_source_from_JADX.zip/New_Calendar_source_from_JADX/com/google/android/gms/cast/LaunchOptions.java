package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.p000a.Security;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Arrays;
import java.util.Locale;

public class LaunchOptions implements SafeParcelable {
    public static final Creator<LaunchOptions> CREATOR;
    private final int f422a;
    private boolean f423b;
    private String f424c;

    static {
        CREATOR = new C0125z();
    }

    public LaunchOptions() {
        Locale locale = Locale.getDefault();
        StringBuilder stringBuilder = new StringBuilder(20);
        stringBuilder.append(locale.getLanguage());
        Object country = locale.getCountry();
        if (!TextUtils.isEmpty(country)) {
            stringBuilder.append('-').append(country);
        }
        Object variant = locale.getVariant();
        if (!TextUtils.isEmpty(variant)) {
            stringBuilder.append('-').append(variant);
        }
        this(1, false, stringBuilder.toString());
    }

    LaunchOptions(int i, boolean z, String str) {
        this.f422a = i;
        this.f423b = z;
        this.f424c = str;
    }

    final int m983a() {
        return this.f422a;
    }

    public final void m984a(boolean z) {
        this.f423b = z;
    }

    public final boolean m985b() {
        return this.f423b;
    }

    public final String m986c() {
        return this.f424c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LaunchOptions)) {
            return false;
        }
        LaunchOptions launchOptions = (LaunchOptions) obj;
        return this.f423b == launchOptions.f423b && Security.m96a(this.f424c, launchOptions.f424c);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Boolean.valueOf(this.f423b), this.f424c});
    }

    public String toString() {
        return String.format("LaunchOptions(relaunchIfRunning=%b, language=%s)", new Object[]{Boolean.valueOf(this.f423b), this.f424c});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0125z.m1039a(this, parcel);
    }
}
