package com.google.android.gms.cast;

import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.internal.gd;
import org.json.JSONObject;

public final class RemoteMediaPlayer implements MessageReceivedCallback {
    private final gd f425a;

    public interface MediaChannelResult extends Result {
        JSONObject getCustomData();
    }

    public interface OnMetadataUpdatedListener {
        void onMetadataUpdated();
    }

    public interface OnStatusUpdatedListener {
        void onStatusUpdated();
    }

    public final void onMessageReceived(CastDevice castDevice, String str, String str2) {
        this.f425a.m3277a(str2);
    }
}
