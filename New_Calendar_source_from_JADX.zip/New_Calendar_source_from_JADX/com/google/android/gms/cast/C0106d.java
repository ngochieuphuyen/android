package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api.C0127a;
import com.google.android.gms.common.api.BaseImplementation$b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.fP;

/* renamed from: com.google.android.gms.cast.d */
final class C0106d extends C0105o {
    private /* synthetic */ String f441a;

    C0106d(C0098b c0098b, GoogleApiClient googleApiClient, String str) {
        this.f441a = str;
        super(googleApiClient);
    }

    protected final /* bridge */ /* synthetic */ void m1016a(C0127a c0127a) {
        try {
            ((fP) c0127a).m3054a(this.f441a, false, (BaseImplementation$b) this);
        } catch (IllegalStateException e) {
            m1011a(2001);
        }
    }
}
